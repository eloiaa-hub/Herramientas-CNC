#!/bin/sh
# Reconstruye calcador.html (y corrector.html) desde el Calcador v73 original con todos los parches, en orden.
# Uso: sh construir_calcador.sh            (desde herramientas_desarrollo; escribe en la carpeta de la suite)
set -e
cd "$(dirname "$0")/fuentes_mecanizar"
cp calcador_v73_original.html ../../calcador.html
python3 integrar_mecanizar.py ../..
python3 quitar_generador.py ../..
python3 multiherramienta.py ../..
python3 dxf_texto.py ../..
python3 recibir_proyecto.py ../..
python3 entregas_aules.py ../..
python3 cuestionario_moodle.py ../..
python3 dxf_exportar.py ../..
python3 orden_corte.py ../..
python3 agrupar.py ../..
python3 herramientas_cad.py ../..
python3 ../construir_corrector.py ../..
