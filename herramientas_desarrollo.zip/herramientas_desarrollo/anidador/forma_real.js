// ════════════════════════════════════════════════════════════════════
//  Anidado por la forma real: las piezas se encajan por su contorno (no por su rectángulo envolvente) y las
//  pequeñas aprovechan los huecos de las grandes. Las comprobaciones de «cabe aquí» (colocar a mano, girar, pasar
//  a otro tablero) usan la geometría exacta; el anidado automático, una rejilla fina que deja siempre al menos la
//  separación de la fresa entre dos piezas (y lo compara con el de rectángulos, para quedarse con el mejor).
// ════════════════════════════════════════════════════════════════════
const modoForma = () => $('tModo') && $('tModo').value === 'forma';
const cacheForma = new Map();
// La pieza girada g, sin colocar: sus contornos de corte cerrados (exteriores y huecos) como polígonos, con la
// esquina inferior izquierda de su caja en 0 0, y sus tramos
function formaPieza(p, g) {
  g = norm90(g);
  const d = geomPieza(p, g), clave = p.id + '|' + escalaDe(p) + '|' + g + '|' + (+d.w).toFixed(4) + '|' + (+d.h).toFixed(4);
  const guardada = cacheForma.get(clave); if (guardada && guardada.src === p.contornos) return guardada;
  let polys = [];
  if (p.tipo !== 'rect') {
    const cs = d.contornos, pol = cs.map(poliContorno), cl = clasesDe(cs, pol);
    polys = cs.map((k, i) => k.cerrado && (cl[i] === 'exterior' || cl[i] === 'interior') ? pol[i].map(q => ({ x: q.x - d.bb.x0, y: q.y - d.bb.y0 })) : null).filter(Boolean);
  }
  if (!polys.length) polys = [[{ x: 0, y: 0 }, { x: d.w, y: 0 }, { x: d.w, y: d.h }, { x: 0, y: d.h }]];
  const segs = [];
  polys.forEach(P => { for (let i = 0; i < P.length; i++) { const a = P[i], b = P[(i + 1) % P.length]; if (Math.hypot(b.x - a.x, b.y - a.y) > 1e-9) segs.push([a.x, a.y, b.x, b.y]); } });
  // superficie real (par-impar: los huecos restan)
  let area = 0; polys.forEach(P => { let a = 0; for (let i = 0, j = P.length - 1; i < P.length; j = i++) a += (P[j].x + P[i].x) * (P[j].y - P[i].y); area += Math.abs(a / 2) * (polys.filter(Q => Q !== P && dentroPar(P[0].x, P[0].y, [Q])).length % 2 ? -1 : 1); });
  const f = { polys, segs, w: d.w, h: d.h, area: Math.max(0, area), src: p.contornos };
  if (cacheForma.size > 600) cacheForma.clear();
  cacheForma.set(clave, f);
  return f;
}
function dentroPar(x, y, polys) {
  let d = false;
  polys.forEach(P => { for (let i = 0, j = P.length - 1; i < P.length; j = i++) { const a = P[i], b = P[j]; if ((a.y > y) !== (b.y > y) && x < (b.x - a.x) * (y - a.y) / (b.y - a.y) + a.x) d = !d; } });
  return d;
}
function distPtoSeg(px, py, x1, y1, x2, y2) {
  const vx = x2 - x1, vy = y2 - y1, L = vx * vx + vy * vy; let t = L ? ((px - x1) * vx + (py - y1) * vy) / L : 0; t = t < 0 ? 0 : t > 1 ? 1 : t;
  return Math.hypot(px - x1 - t * vx, py - y1 - t * vy);
}
function distSegSeg(a, b) {
  const [x1, y1, x2, y2] = a, [x3, y3, x4, y4] = b;
  const d1 = (x4 - x3) * (y1 - y3) - (y4 - y3) * (x1 - x3), d2 = (x4 - x3) * (y2 - y3) - (y4 - y3) * (x2 - x3);
  const d3 = (x2 - x1) * (y3 - y1) - (y2 - y1) * (x3 - x1), d4 = (x2 - x1) * (y4 - y1) - (y2 - y1) * (x4 - x1);
  if (((d1 > 0 && d2 < 0) || (d1 < 0 && d2 > 0)) && ((d3 > 0 && d4 < 0) || (d3 < 0 && d4 > 0))) return 0;
  return Math.min(distPtoSeg(x1, y1, x3, y3, x4, y4), distPtoSeg(x2, y2, x3, y3, x4, y4), distPtoSeg(x3, y3, x1, y1, x2, y2), distPtoSeg(x4, y4, x1, y1, x2, y2));
}
// ¿Las dos piezas (forma fa en ax, ay y fb en bx, by) quedan a la separación sep o más, sin pisarse?
function separadas(fa, ax, ay, fb, bx, by, sep) {
  const e = 1e-6, lim = sep - 1e-4;
  if (ax >= bx + fb.w + lim - e || bx >= ax + fa.w + lim - e || ay >= by + fb.h + lim - e || by >= ay + fa.h + lim - e) return true;
  // una dentro de la otra (en su material): un punto de cada contorno dentro del sólido de la otra
  if (fa.polys.some(P => dentroPar(P[0].x + ax - bx, P[0].y + ay - by, fb.polys))) return false;
  if (fb.polys.some(P => dentroPar(P[0].x + bx - ax, P[0].y + by - ay, fa.polys))) return false;
  // los bordes: a la separación o más (solo los tramos que están cerca de la otra pieza)
  const cerca = (s, ox, oy, x0, y0, x1, y1) => Math.max(s[0], s[2]) + ox >= x0 - lim && Math.min(s[0], s[2]) + ox <= x1 + lim && Math.max(s[1], s[3]) + oy >= y0 - lim && Math.min(s[1], s[3]) + oy <= y1 + lim;
  const A = fa.segs.filter(s => cerca(s, ax, ay, bx, by, bx + fb.w, by + fb.h)).map(s => [s[0] + ax, s[1] + ay, s[2] + ax, s[3] + ay]);
  if (!A.length) return true;
  const B = fb.segs.filter(s => cerca(s, bx, by, ax, ay, ax + fa.w, ay + fa.h)).map(s => [s[0] + bx, s[1] + by, s[2] + bx, s[3] + by]);
  for (const s of A) {
    const sx0 = Math.min(s[0], s[2]) - lim, sx1 = Math.max(s[0], s[2]) + lim, sy0 = Math.min(s[1], s[3]) - lim, sy1 = Math.max(s[1], s[3]) + lim;
    for (const q of B) {
      if (Math.max(q[0], q[2]) < sx0 || Math.min(q[0], q[2]) > sx1 || Math.max(q[1], q[3]) < sy0 || Math.min(q[1], q[3]) > sy1) continue;
      if (distSegSeg(s, q) < lim) return false;
    }
  }
  return true;
}
// ¿Cabe la pieza p, girada g, con su caja en x, y del tablero t? Dentro del margen y separada de las otras ({ t, p, g, x, y })
function cabeForma(T, t, p, g, x, y, otros) {
  const f = formaPieza(p, g), e = 1e-3;
  if (!(t >= 0) || x < T.M - e || y < T.M - e || x + f.w > T.L - T.M + e || y + f.h > T.A - T.M + e) return false;
  return otros.every(o => o.t !== t || separadas(f, x, y, formaPieza(o.p, o.g), o.x, o.y, T.sep));
}
// Las colocadas a mano del tablero i (salvo una), para cabeForma
const fijasFormaDelTablero = (i, salvo) => resultado.tableros[i].col.filter(o => o.fija && o !== salvo).map(o => ({ t: i, p: o.p, g: o.g, x: o.x, y: o.y }));
// ¿Cabe aquí? (por la forma o por el rectángulo, según el modo)
function cabeAqui(T, t, c, g, x, y, salvo) {
  if (modoForma()) return cabeForma(T, t, c.p, g, x, y, fijasFormaDelTablero(t, salvo));
  const d = geomPieza(c.p, g);
  return cabeFija(T, t, x, y, d.w, d.h, fijasDelTablero(t, salvo));
}

// ── Anidado automático por la forma: rejilla (celdas de lado c) y llenado de abajo a la izquierda ──
function anidarForma(items, T, fijos) {
  // items: [{ ref, k, gs }] (gs: giros permitidos); fijos: [{ t, p, g, x, y, it }] (colocadas a mano, ya comprobadas)
  const L = T.L, A = T.A, s = T.sep, c = Math.max(0.5, Math.sqrt(L * A / 160000));
  // engorde de cada pieza en la rejilla: media separación y un poco más. No garantiza por sí solo la separación
  // (para eso haría falta media diagonal de celda, y se perdería tablero): cada sitio que da la rejilla se comprueba
  // después con la geometría exacta, y si no vale se sigue buscando
  const R = s / 2 + c * 0.3;
  const GW = Math.ceil(L / c), GH = Math.ceil(A / c), WW = (GW + 31) >>> 5;
  const nuevo = () => {
    const b = new Uint32Array(GH * WW).fill(0xffffffff);
    // libres: las celdas enteras dentro de [M − s/2, L − M + s/2] × [M − s/2, A − M + s/2]
    const i0 = Math.max(0, Math.ceil((T.M - s / 2) / c - 1e-9)), i1 = Math.min(GW, Math.floor((L - T.M + s / 2) / c + 1e-9)), j0 = i0, j1 = Math.min(GH, Math.floor((A - T.M + s / 2) / c + 1e-9));
    for (let j = j0; j < j1; j++) for (let i = i0; i < i1; i++) b[j * WW + (i >>> 5)] &= ~(1 << (i & 31));
    return { bits: b, col: [], fin: 0, formas: [] };
  };
  // celdas que ocupa la forma f con su caja en (ox, oy) mm, en una rejilla local de gw × gh celdas
  const rasterizar = (f, ox, oy, gw, gh) => {
    const occ = new Uint8Array(gw * gh);
    for (let j = 0; j < gh; j++) {
      const yc = (j + 0.5) * c - oy, xs = [];
      for (const [x1, y1, x2, y2] of f.segs) if ((y1 > yc) !== (y2 > yc)) xs.push(x1 + (yc - y1) * (x2 - x1) / (y2 - y1));
      xs.sort((a, b) => a - b);
      for (let k = 0; k + 1 < xs.length; k += 2) { const a = Math.max(0, Math.ceil((xs[k] + ox) / c - 0.5)), b = Math.min(gw - 1, Math.floor((xs[k + 1] + ox) / c - 0.5)); for (let i = a; i <= b; i++) occ[j * gw + i] = 1; }
    }
    for (const [x1, y1, x2, y2] of f.segs) {
      const ia = Math.max(0, Math.floor((Math.min(x1, x2) + ox - R) / c)), ib = Math.min(gw - 1, Math.floor((Math.max(x1, x2) + ox + R) / c));
      const ja = Math.max(0, Math.floor((Math.min(y1, y2) + oy - R) / c)), jb = Math.min(gh - 1, Math.floor((Math.max(y1, y2) + oy + R) / c));
      for (let j = ja; j <= jb; j++) for (let i = ia; i <= ib; i++) if (!occ[j * gw + i] && distPtoSeg((i + 0.5) * c - ox, (j + 0.5) * c - oy, x1, y1, x2, y2) <= R) occ[j * gw + i] = 1;
    }
    return occ;
  };
  // máscara de la pieza: filas de tramos ocupados [a, b]; la caja de la pieza queda en (pad, pad) de la máscara
  const mascaras = new Map();
  const mascara = (p, g) => {
    const f = formaPieza(p, g), clave = p.id + '|' + g + '|' + f.w.toFixed(4) + '|' + f.h.toFixed(4);
    let m = mascaras.get(clave); if (m) return m;
    const mw = Math.ceil((f.w + 2 * R) / c), mh = Math.ceil((f.h + 2 * R) / c), occ = rasterizar(f, R, R, mw, mh), filas = [];
    for (let j = 0; j < mh; j++) { const r = []; let i = 0; while (i < mw) { if (occ[j * mw + i]) { const a = i; while (i < mw && occ[j * mw + i]) i++; r.push([a, i - 1]); } else i++; } filas.push(r); }
    // orden de prueba de las filas: el centro primero (descarta antes las posiciones que chocan)
    const orden = [...filas.keys()].filter(j => filas[j].length).sort((a, b) => Math.abs(a - mh / 2) - Math.abs(b - mh / 2));
    m = { f, mw, mh, filas, orden }; mascaras.set(clave, m); return m;
  };
  const algun = (b, j, a, z) => {        // ¿alguna celda ocupada en la fila j, de a a z?
    const base = j * WW; let wa = a >>> 5; const wz = z >>> 5;
    if (wa === wz) { const m = (0xffffffff >>> (31 - (z & 31))) & (0xffffffff << (a & 31)); return (b[base + wa] & m) !== 0; }
    if (b[base + wa] & (0xffffffff << (a & 31))) return true;
    for (wa++; wa < wz; wa++) if (b[base + wa]) return true;
    return (b[base + wz] & (0xffffffff >>> (31 - (z & 31)))) !== 0;
  };
  const cabe = (b, m, X, Y) => { for (const j of m.orden) for (const [a, z] of m.filas[j]) if (algun(b, Y + j, X + a, X + z)) return false; return true; };
  const marcar = (b, filas, X, Y, gw) => filas.forEach((r, j) => r.forEach(([a, z]) => { for (let i = a; i <= z; i++) { const ii = X + i, jj = Y + j; if (ii >= 0 && ii < GW && jj >= 0 && jj < GH) b[jj * WW + (ii >>> 5)] |= 1 << (ii & 31); } }));
  const tableros = [], fuera = [];
  // las colocadas a mano, en su sitio exacto
  (fijos || []).forEach(fj => {
    while (tableros.length <= fj.t) tableros.push(nuevo());
    const tb = tableros[fj.t], f = formaPieza(fj.p, fj.g), I0 = Math.floor((fj.x - R) / c) - 1, J0 = Math.floor((fj.y - R) / c) - 1;
    const gw = Math.ceil((f.w + 2 * R) / c) + 3, gh = Math.ceil((f.h + 2 * R) / c) + 3, occ = rasterizar(f, fj.x - I0 * c, fj.y - J0 * c, gw, gh), filas = [];
    for (let j = 0; j < gh; j++) { const r = []; for (let i = 0; i < gw; i++) if (occ[j * gw + i]) r.push([i, i]); filas.push(r); }
    marcar(tb.bits, filas, I0, J0); tb.col.push({ ...fj, fija: true, w: f.w, h: f.h }); tb.fin = Math.max(tb.fin, fj.x + f.w); tb.formas.push({ f, x: fj.x, y: fj.y });
  });
  const mejorEn = (tb, it) => {
    let mejor = null;
    for (const g of it.gs) {
      const m = mascara(it.ref, g); if (m.mw > GW || m.mh > GH) continue;
      for (let X = 0; X + m.mw <= GW; X++) {
        const fin = X * c + R + m.f.w; if (mejor && fin > mejor.fin + 1e-9) break;
        let hecho = false;
        for (let Y = 0; Y + m.mh <= GH; Y++) if (cabe(tb.bits, m, X, Y) && exacto(tb, m.f, X * c + R, Y * c + R)) {
          if (!mejor || fin < mejor.fin - 1e-9 || (Math.abs(fin - mejor.fin) < 1e-9 && Y < mejor.Y)) mejor = { X, Y, g, m, fin };
          hecho = true; break;
        }
        if (hecho) break;
      }
    }
    return mejor;
  };
  // comprobación exacta: dentro del margen y a la separación de las piezas cercanas
  const exacto = (tb, f, x, y) => { const e = 1e-3;
    if (x < T.M - e || y < T.M - e || x + f.w > L - T.M + e || y + f.h > A - T.M + e) return false;
    return tb.formas.every(o => separadas(f, x, y, o.f, o.x, o.y, s)); };
  const poner = (tb, it, b) => { marcar(tb.bits, b.m.filas, b.X, b.Y); tb.formas.push({ f: b.m.f, x: b.X * c + R, y: b.Y * c + R }); tb.col.push({ it, p: it.ref, k: it.k, g: b.g, x: b.X * c + R, y: b.Y * c + R, w: b.m.f.w, h: b.m.f.h, rot: b.g !== giroBase(it.ref) }); tb.fin = Math.max(tb.fin, b.fin); };
  // de mayor a menor superficie (las grandes primero; las pequeñas buscan sus huecos)
  items.slice().sort((a, b) => { const fa = formaPieza(a.ref, a.gs[0]), fb = formaPieza(b.ref, b.gs[0]); return fb.w * fb.h - fa.w * fa.h || fb.area - fa.area; }).forEach(it => {
    for (const tb of tableros) { const b = mejorEn(tb, it); if (b) { poner(tb, it, b); return; } }
    const tb = nuevo(), b = mejorEn(tb, it);
    if (!b) { fuera.push(it); return; }
    poner(tb, it, b); tableros.push(tb);
  });
  return { tableros, fuera, celda: c };
}
// Giros que puede probar el anidador: el fijado en la lista; en «Auto», todos (con veta, solo 0° y 180°)
function girosPermitidos(p, T) {
  if (!giroAuto(p)) return [giroBase(p)];
  const gs = T.veta && p.veta ? [0, 180] : [0, 90, 180, 270];
  return p.tipo === 'rect' ? gs.filter(g => g < 180) : gs;
}
