"""Anidador v7: cantos (en la lista, el CSV y el dibujo) y resumen de material, tiempo y coste.
Uso: python3 cantos_coste.py <carpeta de la suite>   (se aplica sobre el anidador v6)
"""
import sys, os
P = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', 'anidador.html')
s = open(P, encoding='utf-8').read()
assert 'function resumenCoste' not in s, 'ya aplicado'
def rep(a, b, cnt=1):
    global s
    n = s.count(a); assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
    s = s.replace(a, b)

# ── versión
rep('<span class="ver" title="Versión del programa">v6</span>', '<span class="ver" title="Versión del programa">v7</span>')
rep('<h3>🪵 Anidador de tableros <span class="ver">v6</span></h3>', '<h3>🪵 Anidador de tableros <span class="ver">v7</span></h3>')

# ── estilos (la columna de la lista, algo más ancha para los cantos)
rep("grid-template-columns: 500px 1fr; gap: 16px;", "grid-template-columns: 548px 1fr; gap: 16px;")
rep("  .exportar { display: flex;", """  /* cantos */
  .piezas .cantos { padding: 0 2px; text-align: center; white-space: nowrap; }
  .mini { width: 38px; height: 26px; display: inline-block; vertical-align: middle; cursor: pointer; }
  .mini .lado { stroke: var(--borde); stroke-width: 2; stroke-dasharray: 2 2; }
  .mini .lado.on { stroke: var(--canto); stroke-width: 4; stroke-dasharray: none; }
  .mini .toque { stroke: transparent; stroke-width: 9; }
  .mini .toque:hover + .lado, .mini .lado:hover { stroke: var(--acento); }
  .mini .fondo { fill: var(--campo); stroke: none; }
  .piezas select.tcanto { width: 64px; font-size: 11px; padding: 2px 1px; }
  .coste .fila > label { font-size: 13.5px; }
  .tcantos { width: 100%; border-collapse: collapse; font-size: 13px; margin: 2px 0 6px; }
  .tcantos td { padding: 2px 3px; } .tcantos input.txt { width: 100%; padding: 3px 6px; } .tcantos input.num { width: 70px; padding: 3px 6px; }
  .resumen { width: 100%; border-collapse: collapse; font-size: 13.5px; margin-top: 10px; }
  .resumen th { text-align: left; font-weight: 600; font-size: 11px; text-transform: uppercase; letter-spacing: .05em; color: var(--texto-sec); padding: 4px 4px; border-bottom: 1px solid var(--borde); }
  .resumen td { padding: 4px 4px; border-bottom: 1px solid var(--borde); vertical-align: top; }
  .resumen td.n { text-align: right; font-family: Consolas, monospace; white-space: nowrap; }
  .resumen td small { color: var(--texto-sec); }
  .resumen tr.total td { font-weight: 700; border-bottom: none; border-top: 2px solid var(--borde); }
  .exportar { display: flex;""")
rep("--pieza-relleno: rgba(30,111,217,.10); --interior: #d64545;", "--pieza-relleno: rgba(30,111,217,.10); --interior: #d64545; --canto: #e09a00;")
rep("--pieza-relleno: rgba(108,180,255,.14); --interior: #ff8a8a;", "--pieza-relleno: rgba(108,180,255,.14); --interior: #ff8a8a; --canto: #ffc24d;")

# ── lista: columna de cantos
rep("""<th title="Veta: la pieza no se gira (su largo va en X). Sin veta, el anidador la puede girar 90° si cabe mejor">Veta</th><th></th>""",
    """<th title="Veta: la pieza no se gira (su largo va en X). Sin veta, el anidador la puede girar 90° si cabe mejor">Veta</th><th title="Cantos: clic en cada lado del dibujo para ponerle o quitarle canto (los dos largos abajo y arriba, los dos anchos a los lados). En las piezas del Calcador, clic para poner canto en todo su contorno exterior">Cantos</th><th></th>""")
rep("""    <td style="text-align:center"><input type="checkbox" data-c="veta" ${p.veta ? 'checked' : ''} title="Con veta (y el tablero con veta), el anidador no la gira: su largo va en X. Sin veta, la puede girar 90° si cabe mejor"></td>
    <td><button""", """    <td style="text-align:center"><input type="checkbox" data-c="veta" ${p.veta ? 'checked' : ''} title="Con veta (y el tablero con veta), el anidador no la gira: su largo va en X. Sin veta, la puede girar 90° si cabe mejor"></td>
    <td class="cantos">${celdaCantos(p)}</td>
    <td><button""")

# ── datos y funciones de cantos y coste (antes de «Pintar»)
rep("""// ════════════════════════════════════════════════════════════════════
//  Pintar
// ════════════════════════════════════════════════════════════════════""", r"""// ════════════════════════════════════════════════════════════════════
//  Cantos y coste
// ════════════════════════════════════════════════════════════════════
// p.cantos = { L1, L2, A1, A2 } en los rectángulos (L1 y L2: los dos lados largos; A1 y A2: los dos anchos);
// p.cantoPerim = true en las piezas del Calcador (canto en todo su contorno exterior); p.tipoCanto = id del tipo
let costes = { tablero: '', maquina: '', exceso: '20', F: '', paso: '', carga: '', tipos: [{ id: 'c1', nombre: 'Canto', precio: '' }] };
const LADOS = ['L1', 'A2', 'L2', 'A1'];            // abajo, derecha, arriba, izquierda (pieza sin girar)
const cantosDe = p => p.cantos || {};
const nCantos = p => p.tipo === 'rect' ? LADOS.filter(l => cantosDe(p)[l]).length : (p.cantoPerim ? 1 : 0);
const tipoCantoDe = p => costes.tipos.find(t => t.id === p.tipoCanto) || costes.tipos[0];
function celdaCantos(p) {
  const on = l => cantosDe(p)[l] ? ' on' : '';
  let svg;
  if (p.tipo === 'rect') {
    const L = [['L1', 6, 21, 32, 21, 'largo de abajo'], ['L2', 6, 5, 32, 5, 'largo de arriba'], ['A1', 6, 5, 6, 21, 'ancho de la izquierda'], ['A2', 32, 5, 32, 21, 'ancho de la derecha']];
    svg = `<svg class="mini" viewBox="0 0 38 26"><rect class="fondo" x="6" y="5" width="26" height="16"/>${L.map(([l, x1, y1, x2, y2, t]) => `<g data-canto="${l}"><title>Canto en el ${t} (${l}): clic para ${cantosDe(p)[l] ? 'quitarlo' : 'ponerlo'}</title><line class="toque" x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}"/><line class="lado${on(l)}" x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}"/></g>`).join('')}</svg>`;
  } else svg = `<svg class="mini" viewBox="0 0 38 26"><g data-canto="perim"><title>${p.cantoPerim ? 'Canto en todo el contorno exterior: clic para quitarlo' : 'Sin canto: clic para ponerlo en todo el contorno exterior'}</title><rect class="fondo" x="6" y="5" width="26" height="16" rx="8"/><rect class="lado${p.cantoPerim ? ' on' : ''}" x="6" y="5" width="26" height="16" rx="8" fill="none"/></g></svg>`;
  const sel = costes.tipos.length > 1 && nCantos(p) ? `<br><select class="tcanto" data-c="tipoCanto" title="Tipo de canto de esta pieza">${costes.tipos.map(t => `<option value="${esc(t.id)}"${t.id === tipoCantoDe(p).id ? ' selected' : ''}>${esc(t.nombre || 'Canto')}</option>`).join('')}</select>` : '';
  return svg + sel;
}
// lado que ocupa en el tablero (0 abajo, 1 derecha, 2 arriba, 3 izquierda) el lado l de la pieza, girada g grados antihorario
const ladoColocado = (l, g) => (LADOS.indexOf(l) + norm90(g) / 90) % 4;
// longitud de un contorno (con sus arcos) y área (con signo) de un polígono
function longitudContorno(c) {
  const n = c.pts.length, segs = c.cerrado ? n : n - 1; let L = 0;
  for (let i = 0; i < segs; i++) { const a = c.pts[i], b = c.pts[(i + 1) % n], bu = (c.b && c.b[i]) || 0, cu = Math.hypot(b.x - a.x, b.y - a.y);
    if (Math.abs(bu) < 1e-12 || cu < 1e-12) { L += cu; continue; }
    const th = 4 * Math.atan(Math.abs(bu)); L += cu / (2 * Math.sin(th / 2)) * th; }
  return L;
}
const areaPoli = pol => { let a = 0; for (let i = 0, j = pol.length - 1; i < pol.length; j = i++) a += (pol[j].x + pol[i].x) * (pol[j].y - pol[i].y); return a / 2; };
// medidas de una unidad de la pieza: superficie real, canto, cortes (longitud y nº de contornos, a qué profundidad)
function medidasPieza(p, T) {
  const ex = Math.max(0, num(costes.exceso) || 0);
  if (p.tipo === 'rect') {
    const c = cantosDe(p), lados = LADOS.filter(l => c[l]);
    return { area: p.L * p.A, canto: lados.reduce((a, l) => a + (l[0] === 'L' ? p.L : p.A) + ex, 0), cortes: [{ L: 2 * (p.L + p.A), prof: T.G + T.P }] };
  }
  const g = geomPieza(p, 0), polis = g.contornos.map(poliContorno), cl = clasesDe(g.contornos, polis);
  let area = 0, canto = 0; const cortes = [];
  g.contornos.forEach((k, i) => {
    if (!k.cerrado && cl[i] !== 'exterior') return;
    if (cl[i] === 'exterior' && k.cerrado) { area += Math.abs(areaPoli(polis[i])); if (p.cantoPerim) canto += longitudContorno(k) + ex; }
    if (cl[i] === 'interior') area -= Math.abs(areaPoli(polis[i]));
    if ((cl[i] === 'exterior' || cl[i] === 'interior') && !(k.mec && (k.mec.op === 'grabado' || k.mec.op === 'cajera' || k.mec.op === 'isla')))
      cortes.push({ L: longitudContorno(k), prof: k.mec && +k.mec.prof > 0 ? +k.mec.prof : T.G + T.P });
  });
  return { area: Math.max(0, area), canto, cortes };
}
// todo el anidado: material, canto, tiempo de máquina y coste
function resumenCoste() {
  if (!resultado) return null;
  const T = resultado.T, h = herramientaElegida(), colocadas = resultado.tableros.flatMap(t => t.col);
  const F = num(costes.F) > 0 ? num(costes.F) : h && +h.F > 0 ? +h.F : 1000, paso = num(costes.paso) > 0 ? num(costes.paso) : h && +h.paso > 0 ? +h.paso : 6;
  let area = 0, recorrido = 0, entradas = 0; const porTipo = new Map(), cache = new Map();
  colocadas.forEach(c => {
    if (!cache.has(c.p.id)) cache.set(c.p.id, medidasPieza(c.p, T));
    const m = cache.get(c.p.id); area += m.area;
    if (m.canto > 0) { const t = tipoCantoDe(c.p); porTipo.set(t.id, (porTipo.get(t.id) || 0) + m.canto); }
    m.cortes.forEach(k => { const n = Math.max(1, Math.ceil(k.prof / paso - 1e-9)); recorrido += k.L * n; entradas += n; });
  });
  const nT = resultado.tableros.length, areaT = nT * T.L * T.A;
  const carga = Math.max(0, num(costes.carga) || 0);
  const minutos = recorrido / F + entradas * 4 / 60 + nT * carga;   // corte al avance F + unos 4 s por pasada (bajar, entrar, subir) + poner y quitar cada tablero
  const precio = v => { const x = num(v); return isFinite(x) && x >= 0 && String(v).trim() !== '' ? x : null; };
  const pT = precio(costes.tablero), pM = precio(costes.maquina);
  const cantos = costes.tipos.map(t => ({ t, m: (porTipo.get(t.id) || 0) / 1000, precio: precio(t.precio) })).filter(x => x.m > 0);
  const partes = [pT !== null ? nT * pT : null, ...cantos.map(x => x.precio !== null ? x.m * x.precio : null), pM !== null ? minutos / 60 * pM : null];
  return { T, nT, areaT, area, desperdicio: Math.max(0, areaT - area), cantos, recorrido, entradas, minutos, F, paso, pT, pM, carga,
           total: partes.some(v => v !== null) ? partes.reduce((a, v) => a + (v || 0), 0) : null, faltan: partes.some(v => v === null), nPiezas: colocadas.length };
}
const eur = v => v === null || !isFinite(v) ? '—' : v.toLocaleString('es-ES', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' €';
const m2 = v => (v / 1e6).toLocaleString('es-ES', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' m²';
const mins = v => !isFinite(v) ? '—' : v < 60 ? `${Math.max(1, Math.round(v))} min` : `${Math.floor(v / 60)} h ${String(Math.round(v % 60)).padStart(2, '0')} min`;
const dec = (v, d) => (+v).toLocaleString('es-ES', { minimumFractionDigits: d, maximumFractionDigits: d });
function pintarCoste() {
  const h = herramientaElegida();
  $('cF').placeholder = h && +h.F > 0 ? String(h.F) : '1000'; $('cPaso').placeholder = h && +h.paso > 0 ? String(h.paso) : '6';
  $('tiposCanto').innerHTML = costes.tipos.map((t, i) => `<tr data-i="${i}"><td><input class="txt" data-k="nombre" value="${esc(t.nombre)}" title="Nombre del tipo de canto (sale en la lista de piezas y en el resumen)" placeholder="Canto"></td><td><input class="num" inputmode="decimal" data-k="precio" value="${esc(t.precio)}" placeholder="€/m" title="Precio del metro de este canto (€/m)"></td><td>${costes.tipos.length > 1 ? `<button class="quitar" data-quitarTipo title="Quitar este tipo de canto (sus piezas pasan al primero)">✕</button>` : ''}</td></tr>`).join('');
  const r = resumenCoste(), el = $('resumen');
  if (!r || !r.nT) { el.innerHTML = '<p class="nota">Añade piezas para ver el material, el canto, el tiempo y el coste.</p>'; return; }
  const fila = (a, b, c, ti) => `<tr title="${ti || ''}"><td>${a}</td><td class="n">${b}</td><td class="n">${c}</td></tr>`;
  let t = `<table class="resumen"><tr><th>Concepto</th><th style="text-align:right">Cantidad</th><th style="text-align:right">Coste</th></tr>`;
  t += fila(`Tableros <small>${f1(r.T.L)} × ${f1(r.T.A)} × ${f1(r.T.G)}</small>`, `${r.nT} · ${m2(r.areaT)}`, r.pT !== null ? eur(r.nT * r.pT) : '<small>sin precio</small>', 'Tableros que hacen falta y su superficie');
  t += fila(`Piezas <small>${r.nPiezas} ud.</small>`, m2(r.area), `<small>${Math.round(100 * r.area / r.areaT)} % aprovechado</small>`, 'Superficie real de las piezas colocadas (sin sus agujeros) y qué parte de los tableros es');
  t += fila('Desperdicio <small>(recortes y retales)</small>', m2(r.desperdicio), `<small>${Math.round(100 * r.desperdicio / r.areaT)} %</small>`, 'Lo que sobra de los tableros: separaciones, márgenes, agujeros y retales');
  r.cantos.forEach(x => { t += fila(`${esc(x.t.nombre || 'Canto')} <small>con ${f1(num(costes.exceso) || 0)} mm de más por tramo</small>`, `${dec(x.m, 2)} m`, x.precio !== null ? eur(x.m * x.precio) : '<small>sin precio</small>', 'Metros de canto para todas las piezas colocadas, contando el exceso de cada tramo'); });
  if (!r.cantos.length) t += fila('Canto <small>ninguna pieza lo lleva</small>', '0 m', '—', 'Marca los cantos en la lista de piezas (columna Cantos)');
  t += fila(`Máquina <small>≈ ${dec(r.recorrido / 1000, 1)} m de corte a F${f1(r.F)}, bajando ${f1(r.paso)} mm por pasada${r.carga ? `, y ${f1(r.carga)} min de carga por tablero` : ''}</small>`, '≈ ' + mins(r.minutos), r.pM !== null ? eur(r.minutos / 60 * r.pM) : '<small>sin precio</small>',
    'Estimación: el recorrido de los cortes (exteriores e interiores; sin cajeras ni grabados) en todas sus pasadas, al avance F, más unos 4 s por pasada para bajar, entrar y subir. La máquina real tarda algo más (aceleraciones, desplazamientos y cambios de herramienta)');
  t += `<tr class="total"><td>Total aproximado${r.faltan && r.total !== null ? ' <small>(solo lo que tiene precio)</small>' : ''}</td><td></td><td class="n">${r.total !== null ? eur(r.total) : '<small>escribe los precios</small>'}</td></tr></table>`;
  el.innerHTML = t;
}
// CSV del despiece con cantos, y el resumen de material, tiempo y coste
function csvCoste() {
  const r = resumenCoste(); if (!r || !r.nT) { snack('No hay piezas colocadas'); return; }
  const d = v => String(v).replace('.', ','), c = t => '"' + String(t).replace(/"/g, '""') + '"', T = r.T;
  const filas = [['Pieza', 'Tipo', 'Largo (mm)', 'Ancho (mm)', 'Ud.', 'Veta', 'Canto largo', 'Canto ancho', 'Tipo de canto', 'Canto por ud. (m)', 'Canto total (m)', 'Superficie por ud. (m²)']];
  piezas.forEach(p => { const m = medidasPieza(p, T), g = geomPieza(p, 0), cn = cantosDe(p);
    filas.push([c(p.nombre), p.tipo === 'rect' ? 'rectángulo' : 'Calcador', d(+g.w.toFixed(1)), d(+g.h.toFixed(1)), p.cant, p.veta ? 'sí' : 'no',
      p.tipo === 'rect' ? (cn.L1 ? 1 : 0) + (cn.L2 ? 1 : 0) : (p.cantoPerim ? 'contorno' : 0), p.tipo === 'rect' ? (cn.A1 ? 1 : 0) + (cn.A2 ? 1 : 0) : '', c(nCantos(p) ? tipoCantoDe(p).nombre || 'Canto' : ''),
      d((m.canto / 1000).toFixed(3)), d((m.canto * p.cant / 1000).toFixed(3)), d((m.area / 1e6).toFixed(4))]); });
  filas.push([], ['Resumen'], ['Tableros', r.nT, c(`${f1(T.L)} × ${f1(T.A)} × ${f1(T.G)} mm`), r.pT !== null ? d((r.nT * r.pT).toFixed(2)) + ' €' : ''],
    ['Superficie de los tableros (m²)', d((r.areaT / 1e6).toFixed(3))], ['Superficie de las piezas (m²)', d((r.area / 1e6).toFixed(3))], ['Desperdicio (m²)', d((r.desperdicio / 1e6).toFixed(3)), d(Math.round(100 * r.desperdicio / r.areaT)) + ' %']);
  r.cantos.forEach(x => filas.push([c(`${x.t.nombre || 'Canto'} (m)`), d(x.m.toFixed(2)), x.precio !== null ? d((x.m * x.precio).toFixed(2)) + ' €' : '']));
  filas.push(['Tiempo de máquina aproximado (min)', d(r.minutos.toFixed(1)), r.pM !== null ? d((r.minutos / 60 * r.pM).toFixed(2)) + ' €' : ''], ['Total aproximado (€)', r.total !== null ? d(r.total.toFixed(2)) : '']);
  descargar('﻿' + filas.map(f => f.join(';')).join('\r\n') + '\r\n', nombreArchivo(nombreProyecto()) + ' - despiece y coste.csv', 'text/csv');
}
// "L1 L2 A1", "2L 1A", "todos": qué lados llevan canto
function leerCantos(t) {
  t = String(t || '').trim().toLowerCase(); const c = {};
  if (!t) return c;
  if (/^(todos?|4|perimetro|perímetro|contorno)$/.test(t)) { LADOS.forEach(l => c[l] = true); return c; }
  t.replace(/([12])?\s*([la])([12])?/g, (_, n, l, k) => { const L = l.toUpperCase(); if (k) c[L + k] = true; else { c[L + '1'] = true; if (n === '2') c[L + '2'] = true; } });
  return c;
}
const esCantos = t => /^\s*(todos?|perimetro|perímetro|contorno|([12]?\s*[la][12]?[\s,+y]*)+)\s*$/i.test(String(t || '')) && /[la]|todo|per|cont/i.test(String(t || ''));
function tipoCantoPorNombre(nombre) {
  nombre = String(nombre || '').trim(); if (!nombre) return costes.tipos[0].id;
  let t = costes.tipos.find(x => (x.nombre || '').trim().toLowerCase() === nombre.toLowerCase());
  if (!t) { if (costes.tipos.length === 1 && !costes.tipos[0].precio && /^canto$/i.test(costes.tipos[0].nombre)) { costes.tipos[0].nombre = nombre; t = costes.tipos[0]; }
            else { t = { id: 'c' + Date.now().toString(36) + costes.tipos.length, nombre, precio: '' }; costes.tipos.push(t); } }
  return t.id;
}

// ════════════════════════════════════════════════════════════════════
//  Pintar
// ════════════════════════════════════════════════════════════════════""")

# ── CSV: columnas por su título y cantos
rep("""  const sep = lineas[0].includes(';') ? ';' : lineas[0].includes('\\t') ? '\\t' : ',';
  const out = [], malas = [];
  lineas.forEach((l, k) => {
    const c = l.split(sep).map(x => x.trim().replace(/^"|"$/g, ''));
    const L = num(c[1]), A = num(c[2]);
    if (k === 0 && !isFinite(L)) return;                      // línea de títulos
    if (!(L > 0 && A > 0)) { malas.push(k + 1); return; }
    const cant = Math.max(1, Math.round(num(c[3]) || 1));
    const v = String(c[4] || '').toLowerCase();
    out.push({ id: nuevoId(), nombre: (c[0] || `Pieza ${out.length + 1}`).slice(0, 60), tipo: 'rect', L, A, cant: Math.min(cant, 500), veta: /^(s|sí|si|x|1|true|veta|yes|y)$/.test(v), giro: null, color: colorNuevo(out) });
  });
  if (!out.length) throw new Error(`«${nombreArch}» no tiene piezas válidas (nombre; largo; ancho; cantidad; veta)`);""",
"""  const sep = lineas[0].includes(';') ? ';' : lineas[0].includes('\\t') ? '\\t' : ',';
  const out = [], malas = [], celdas = l => l.split(sep).map(x => x.trim().replace(/^"|"$/g, ''));
  // columnas: por su título si la primera línea los tiene; si no, en este orden
  let col = { nombre: 0, largo: 1, ancho: 2, cant: 3, veta: 4, cl: 5, ca: 6, tc: 7 };
  const cab = celdas(lineas[0]);
  if (!isFinite(num(cab[1]))) {
    const m = {}, nrm = t => t.toLowerCase().normalize('NFD').replace(/[\\u0300-\\u036f]/g, '').replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '');
    cab.forEach((h, i) => { const n = nrm(h);
      if (/^(nombre|pieza|piezas|descripcion|denominacion|concepto)$/.test(n)) m.nombre = i;
      else if (/^(largo|longitud|largo_mm|l)$/.test(n)) m.largo = i;
      else if (/^(ancho|anchura|ancho_mm|a)$/.test(n)) m.ancho = i;
      else if (/^(cantidad|cant|ud|uds|unidades|n)$/.test(n)) m.cant = i;
      else if (/^veta$/.test(n)) m.veta = i;
      else if (/^(canto_largo|cantos_largo|canto_l|cl|cantos_l)$/.test(n)) m.cl = i;
      else if (/^(canto_ancho|cantos_ancho|canto_a|ca|cantos_a)$/.test(n)) m.ca = i;
      else if (/^(tipo_canto|tipo_de_canto|canto|cantos|material_canto)$/.test(n)) m.tc = i; });
    if (m.largo !== undefined && m.ancho !== undefined) col = m;
  }
  const v01 = x => { const n = Math.round(num(x)); return n >= 2 ? 2 : n >= 1 ? 1 : 0; };
  lineas.forEach((l, k) => {
    const c = celdas(l), en = j => j === undefined ? '' : (c[j] || '');
    const L = num(en(col.largo)), A = num(en(col.ancho));
    if (k === 0 && !isFinite(L)) return;                      // línea de títulos
    if (!(L > 0 && A > 0)) { malas.push(k + 1); return; }
    const cant = Math.max(1, Math.round(num(en(col.cant)) || 1));
    const v = String(en(col.veta)).toLowerCase();
    const p = { id: nuevoId(), nombre: (en(col.nombre) || `Pieza ${out.length + 1}`).slice(0, 60), tipo: 'rect', L, A, cant: Math.min(cant, 500), veta: /^(s|sí|si|x|1|true|veta|yes|y)$/.test(v), giro: null, color: colorNuevo(out) };
    // cantos: «canto largo» y «canto ancho» (0, 1 o 2 lados), o «L1 L2 A1» / «2L 1A» / «todos» en cualquiera de las columnas de cantos
    let cn = {}; const cl = en(col.cl), ca = en(col.ca), tc = en(col.tc);
    [cl, ca, tc].forEach(x => { if (x && esCantos(x) && !isFinite(num(x))) Object.assign(cn, leerCantos(x)); });
    if (isFinite(num(cl)) && cl !== '') { const n = v01(cl); if (n >= 1) cn.L1 = true; if (n >= 2) cn.L2 = true; }
    if (isFinite(num(ca)) && ca !== '') { const n = v01(ca); if (n >= 1) cn.A1 = true; if (n >= 2) cn.A2 = true; }
    if (Object.keys(cn).length) p.cantos = cn;
    if (tc && !esCantos(tc)) p.tipoCanto = tipoCantoPorNombre(tc);
    out.push(p);
  });
  if (!out.length) throw new Error(`«${nombreArch}» no tiene piezas válidas (nombre; largo; ancho; cantidad; veta; canto largo; canto ancho; tipo de canto)`);""")

# ── plantilla y lista en CSV con cantos
rep("""$('btnPlantilla').onclick = () => descargar('﻿nombre;largo;ancho;cantidad;veta\\nCostado;720;400;2;sí\\nBalda;560;380;3;sí\\nTrasera;720;560;1;no\\n', 'despiece_plantilla.csv', 'text/csv');""",
    """$('btnPlantilla').onclick = () => descargar('﻿nombre;largo;ancho;cantidad;veta;canto largo;canto ancho;tipo de canto\\nCostado;720;400;2;sí;1;0;PVC 2 mm\\nBalda;560;380;3;sí;1;0;PVC 2 mm\\nTapa;800;420;1;sí;2;2;PVC 2 mm\\nTrasera;720;560;1;no;0;0;\\n', 'despiece_plantilla.csv', 'text/csv');""")
rep("""  descargar('﻿nombre;largo;ancho;cantidad;veta\\n' + r.map(p => [p.nombre.replace(/;/g, ','), String(p.L).replace('.', ','), String(p.A).replace('.', ','), p.cant, p.veta ? 'sí' : 'no'].join(';')).join('\\n') + '\\n', 'despiece.csv', 'text/csv'); };""",
    """  descargar('﻿nombre;largo;ancho;cantidad;veta;canto largo;canto ancho;tipo de canto\\n' + r.map(p => { const c = cantosDe(p), n = nCantos(p);
    return [p.nombre.replace(/;/g, ','), String(p.L).replace('.', ','), String(p.A).replace('.', ','), p.cant, p.veta ? 'sí' : 'no', (c.L1 ? 1 : 0) + (c.L2 ? 1 : 0), (c.A1 ? 1 : 0) + (c.A2 ? 1 : 0), n ? (tipoCantoDe(p).nombre || 'Canto').replace(/;/g, ',') : ''].join(';'); }).join('\\n') + '\\n', 'despiece.csv', 'text/csv'); };""")

# ── clic en los cantos de la lista y tipo de canto
rep("""$('lista').addEventListener('click', e => { if (!e.target.closest('[data-quitar]')) return;""",
    """$('lista').addEventListener('click', e => {
  const g = e.target.closest('[data-canto]');
  if (g) { const p = piezas.find(q => q.id === e.target.closest('tr').dataset.id); if (!p) return; const l = g.dataset.canto;
    if (l === 'perim') p.cantoPerim = !p.cantoPerim; else { p.cantos = { ...cantosDe(p), [l]: !cantosDe(p)[l] }; if (!p.cantos[l]) delete p.cantos[l]; }
    pintarLista(); pintarVista(); guardar(); return; }
  if (!e.target.closest('[data-quitar]')) return;""")
rep("""  else if (c === 'color') { p.color = e.target.value; e.target.style.background = colorDe(p).c; pintarVista(); guardar(); }
});""", """  else if (c === 'color') { p.color = e.target.value; e.target.style.background = colorDe(p).c; pintarVista(); guardar(); }
  else if (c === 'tipoCanto') { p.tipoCanto = e.target.value; pintarCoste(); guardar(); }
});""")

# ── el dibujo: los lados con canto (en la vista, el SVG y el PNG)
rep("""    cont.forEach((kk, ik) => { const pol = polis[ik].map(P); s += `<path class="contorno ${clases[ik]}\"""",
    """    s += lineasCanto(c, cont, polis, clases).map(pts => { const q = pts.map(P); return `<polyline points="${q.map(z => z.x.toFixed(1) + ',' + z.y.toFixed(1)).join(' ')}" fill="none" stroke="${v('--canto')}" stroke-width="5" stroke-linecap="round" stroke-linejoin="round" stroke-opacity=".9" vector-effect="non-scaling-stroke"><title>Canto</title></polyline>`; }).join('');
    cont.forEach((kk, ik) => { const pol = polis[ik].map(P); s += `<path class="contorno ${clases[ik]}\"""")
rep("""function pintarVista() {""", """// Tramos con canto de una pieza colocada (coordenadas del tablero), metidos un poco hacia dentro para verlos junto al corte
function lineasCanto(c, cont, polis, clases) {
  if (c.p.tipo === 'rect') {
    const x0 = c.x, y0 = c.y, x1 = c.x + c.w, y1 = c.y + c.h, d = Math.min(c.w, c.h) * 0.02;
    const L = [[{ x: x0, y: y0 + d }, { x: x1, y: y0 + d }], [{ x: x1 - d, y: y0 }, { x: x1 - d, y: y1 }], [{ x: x0, y: y1 - d }, { x: x1, y: y1 - d }], [{ x: x0 + d, y: y0 }, { x: x0 + d, y: y1 }]];
    return LADOS.filter(l => cantosDe(c.p)[l]).map(l => L[ladoColocado(l, c.g)]);
  }
  if (!c.p.cantoPerim) return [];
  return cont.map((k, i) => clases[i] === 'exterior' && k.cerrado ? polis[i] : null).filter(Boolean);
}
function pintarVista() {""")
rep("""    cont.forEach((k, j) => { const ext = clases[j] === 'exterior', col = ext ? colorDe(c.p).c : COLOR_EXP[clases[j]];""",
    """    lineasCanto(c, cont, cont.map(poliContorno), clases).forEach(pts => { s += `  <polyline class="canto" points="${pts.map(q => X(q.x) + ',' + Y(q.y)).join(' ')}" fill="none" stroke="#e09a00" stroke-width="${fx(3 * sw)}" stroke-linecap="round" stroke-linejoin="round"/>\\n`; });
    cont.forEach((k, j) => { const ext = clases[j] === 'exterior', col = ext ? colorDe(c.p).c : COLOR_EXP[clases[j]];""")

# ── guardar y abrir el tablero con sus cantos
rep("""tipo: c.p.tipo, ref: c.p.id, veta: !!c.p.veta, color: c.p.color, giroLista: giroAuto(c.p) ? null : giroBase(c.p), contornos: deCada[n] })) } };""",
    """tipo: c.p.tipo, ref: c.p.id, veta: !!c.p.veta, color: c.p.color, giroLista: giroAuto(c.p) ? null : giroBase(c.p), contornos: deCada[n],
      ...(nCantos(c.p) ? { cantos: c.p.tipo === 'rect' ? { ...cantosDe(c.p) } : 'contorno', tipoCanto: tipoCantoDe(c.p).nombre || 'Canto' } : {}) })) } };""")
rep("""    if (!porClave.has(clave)) { porClave.set(clave, p); p.color = COLORES.some(c => c.id === q.color) ? q.color : colorNuevo(nuevas); if (q.giroLista !== undefined && q.giroLista !== null) p.giro = norm90(q.giroLista); nuevas.push(p); }""",
    """    if (!porClave.has(clave)) { porClave.set(clave, p); p.color = COLORES.some(c => c.id === q.color) ? q.color : colorNuevo(nuevas); if (q.giroLista !== undefined && q.giroLista !== null) p.giro = norm90(q.giroLista);
      if (q.cantos === 'contorno') p.cantoPerim = true; else if (q.cantos && typeof q.cantos === 'object') { p.cantos = {}; LADOS.forEach(l => { if (q.cantos[l]) p.cantos[l] = true; }); if (p.tipo !== 'rect') p.cantoPerim = true; }
      if (q.tipoCanto) p.tipoCanto = tipoCantoPorNombre(q.tipoCanto);
      nuevas.push(p); }""")

# ── estado: los costes
rep("""    const d = { v: {}, veta: $('tVeta').checked, cero: $('tCero').value, herr: $('hSel').value, piezas };""",
    """    const d = { v: {}, veta: $('tVeta').checked, cero: $('tCero').value, herr: $('hSel').value, piezas, costes };""")
rep("""  piezas.forEach(p => { if (!COLORES.some(c => c.id === p.color)) p.color = colorNuevo(); if (p.fijas && typeof p.fijas !== 'object') delete p.fijas; });
}""", """  piezas.forEach(p => { if (!COLORES.some(c => c.id === p.color)) p.color = colorNuevo(); if (p.fijas && typeof p.fijas !== 'object') delete p.fijas; });
  if (d.costes && Array.isArray(d.costes.tipos) && d.costes.tipos.length) costes = { ...costes, ...d.costes };
}""")
rep("""function todo() { calcular(); pintarLista(); pintarVista(); notaSeparacion(); guardar(); }""",
    """function todo() { calcular(); pintarLista(); pintarVista(); notaSeparacion(); guardar(); }""")
# la vista vuelve a pintar el coste (cambia con cualquier cosa del anidado)
rep("""  avisos.innerHTML = av;
  botones(n > 0);
}""", """  avisos.innerHTML = av;
  botones(n > 0);
  pintarCoste();
}""")

# ── el panel
rep("""  <div>
    <div class="caja">
      <h2>Tableros</h2>""", """    <div class="caja coste">
      <h2>Cantos y coste <span class="mas"><button class="chico" id="btnCoste" title="Descarga el despiece con los cantos y el resumen de material, tiempo y coste (.csv, para Excel o LibreOffice)">⬇ Despiece y coste (CSV)</button></span></h2>
      <div class="fila" title="Precio de un tablero entero como el de arriba (€). Vacío: no se cuenta"><label>Precio del tablero <small>(€/ud.)</small></label><input class="num" inputmode="decimal" id="cTablero" placeholder="€"></div>
      <div style="font-size:13.5px;margin-top:8px" title="Los tipos de canto que usas, con su precio por metro. Si hay más de uno, cada pieza elige el suyo en la lista">Cantos <small style="color:var(--texto-sec)">(tipo y €/m)</small> <button class="chico" id="btnTipoCanto" title="Añade otro tipo de canto (por ejemplo, de otro grueso o color)">＋ Tipo</button></div>
      <table class="tcantos"><tbody id="tiposCanto"></tbody></table>
      <div class="fila" title="Lo que se añade a cada tramo de canto para poder recortarlo (en la canteadora se corta un poco más largo que la pieza)"><label>Exceso por tramo de canto <small>(mm)</small></label><input class="num" inputmode="decimal" id="cExceso" value="20"></div>
      <div class="fila" title="Precio de la hora de máquina (€/h). Vacío: no se cuenta"><label>Hora de máquina <small>(€/h)</small></label><input class="num" inputmode="decimal" id="cMaquina" placeholder="€/h"></div>
      <div class="fila" title="Avance de corte para estimar el tiempo. Vacío: el de la fresa elegida (o 1000 mm/min)"><label>Avance de corte F <small>(mm/min)</small></label><input class="num" inputmode="decimal" id="cF"></div>
      <div class="fila" title="Profundidad que baja la fresa en cada pasada: con un tablero de 16 mm y 6 mm por pasada, son 3 pasadas. Vacío: la de la fresa elegida (o 6 mm)"><label>Bajada por pasada <small>(mm)</small></label><input class="num" inputmode="decimal" id="cPaso"></div>
      <div class="fila" title="Tiempo de poner, fijar y quitar cada tablero en la máquina (min). Se suma al tiempo de máquina. Vacío: no se cuenta"><label>Carga y descarga <small>(min/tablero)</small></label><input class="num" inputmode="decimal" id="cCarga" placeholder="min"></div>
      <div id="resumen"></div>
      <p class="nota">Cantos: en la lista, clic en cada lado del dibujo de la pieza. El tiempo es una estimación para comparar: la máquina real tarda algo más.</p>
    </div>
  </div>

  <div>
    <div class="caja">
      <h2>Tableros</h2>""")
# la caja de coste se cierra con el </div> de la columna izquierda que ya existía: quitar el cierre previo
rep("""        <button class="chico" id="btnVaciar" title="Quita todas las piezas de la lista">🗑 Vaciar</button>
      </div>
    </div>
  </div>
""", """        <button class="chico" id="btnVaciar" title="Quita todas las piezas de la lista">🗑 Vaciar</button>
      </div>
    </div>
""")

# ── eventos del panel de coste
rep("""$('btnAbrir').onclick = () => $('archivo').click();""", """// cantos y coste
[['cTablero', 'tablero'], ['cExceso', 'exceso'], ['cMaquina', 'maquina'], ['cF', 'F'], ['cPaso', 'paso'], ['cCarga', 'carga']].forEach(([id, k]) => $(id).addEventListener('input', () => { const t = $(id).value.trim(), ok = t === '' || num(t) >= 0; $(id).classList.toggle('mal', !ok); if (!ok) return; costes[k] = t; pintarCoste(); guardar(); }));
const ponerCostesEnPantalla = () => { $('cTablero').value = costes.tablero || ''; $('cExceso').value = costes.exceso ?? '20'; $('cMaquina').value = costes.maquina || ''; $('cF').value = costes.F || ''; $('cPaso').value = costes.paso || ''; $('cCarga').value = costes.carga || ''; };
$('tiposCanto').addEventListener('input', e => { const i = +e.target.closest('tr').dataset.i, k = e.target.dataset.k, t = costes.tipos[i]; if (!t || !k) return;
  if (k === 'precio') { const ok = e.target.value.trim() === '' || num(e.target.value) >= 0; e.target.classList.toggle('mal', !ok); if (!ok) return; }
  t[k] = e.target.value; const r = $('resumen'); if (r) { const foco = document.activeElement; pintarCoste(); if (foco && foco.dataset && foco.dataset.k) { const el = document.querySelector(`#tiposCanto tr[data-i="${i}"] input[data-k="${k}"]`); if (el) { el.focus(); el.setSelectionRange(el.value.length, el.value.length); } } }
  if (k === 'nombre') pintarLista(); guardar(); });
$('tiposCanto').addEventListener('click', e => { if (!e.target.closest('[data-quitarTipo]')) return; const i = +e.target.closest('tr').dataset.i, t = costes.tipos[i]; costes.tipos.splice(i, 1);
  piezas.forEach(p => { if (p.tipoCanto === t.id) delete p.tipoCanto; }); pintarLista(); pintarCoste(); guardar(); });
$('btnTipoCanto').onclick = () => { costes.tipos.push({ id: 'c' + Date.now().toString(36), nombre: `Canto ${costes.tipos.length + 1}`, precio: '' }); pintarLista(); pintarCoste(); guardar(); const el = document.querySelector('#tiposCanto tr:last-child input[data-k="nombre"]'); if (el) { el.focus(); el.select(); } };
$('btnCoste').onclick = csvCoste;
$('btnAbrir').onclick = () => $('archivo').click();""")
rep("""cargar();
todo();""", """cargar();
ponerCostesEnPantalla();
todo();""")
# al cambiar de fresa cambian el avance y la bajada por defecto
rep("""$('hSel').addEventListener('change', () => { const h = herramientaElegida(); if (h) $('hD').value = h.d; todo(); });""",
    """$('hSel').addEventListener('change', () => { const h = herramientaElegida(); if (h) $('hD').value = h.d; todo(); });  // todo() → pintarVista() → pintarCoste()""")

# ── ayuda
rep("""  <h4>4. El resultado</h4>""", """  <h4>Cantos</h4>
  <p>En la columna <b>Cantos</b> de la lista, clic en cada lado del dibujo de la pieza para ponerle o quitarle canto: abajo y arriba, los dos <b>largos</b> (L1 y L2); a los lados, los dos <b>anchos</b> (A1 y A2). En las piezas del Calcador, un clic pone canto en todo su <b>contorno exterior</b>. En el tablero, los lados con canto se ven en amarillo, también con la pieza girada: así sabes qué canto va en cada lado al sacarla.</p>
  <p>En el CSV, las columnas <code>canto largo</code> y <code>canto ancho</code> dicen cuántos lados llevan canto (0, 1 o 2), y <code>tipo de canto</code>, cuál (por ejemplo, <i>PVC 2 mm</i>). También vale escribir los lados: <code>L1 L2 A1</code>, <code>2L 1A</code> o <code>todos</code>. Las columnas se reconocen por su título, en cualquier orden.</p>
  <h4>Cantos y coste</h4>
  <p>El panel <b>Cantos y coste</b> suma lo que lleva todo el anidado: tableros, superficie de las piezas y desperdicio; metros de cada tipo de canto (con el exceso de cada tramo para recortarlo) y un tiempo de máquina aproximado (el recorrido de los cortes, en todas sus pasadas, al avance de la fresa, más unos segundos por pasada y, si lo escribes, el tiempo de cargar y descargar cada tablero). Escribe los precios (tablero, cada canto, hora de máquina) para ver el coste; lo que se deja vacío no se cuenta. <b>⬇ Despiece y coste (CSV)</b> lo descarga todo para la hoja de cálculo.</p>
  <h4>4. El resultado</h4>""")
rep("""      <pre>nombre;largo;ancho;cantidad;veta
Costado;720;400;2;sí
Balda;560;380;3;sí
Trasera;720;560;1;no</pre>
      Separa con punto y coma (o comas, o tabuladores). Con punto y coma, los decimales pueden llevar coma. La primera línea de títulos es opcional.</li>""",
    """      <pre>nombre;largo;ancho;cantidad;veta;canto largo;canto ancho;tipo de canto
Costado;720;400;2;sí;1;0;PVC 2 mm
Balda;560;380;3;sí;1;0;PVC 2 mm
Trasera;720;560;1;no;0;0;</pre>
      Separa con punto y coma (o comas, o tabuladores). Con punto y coma, los decimales pueden llevar coma. La primera línea de títulos es opcional (sin ella, las columnas van en este orden); las de cantos, también.</li>""")

# ── retoques: la tabla de tipos de canto se pinta aparte (para no perder el foco al escribir)
rep("""  $('tiposCanto').innerHTML = costes.tipos.map(""","""  const r = resumenCoste(), el = $('resumen');
  if (!r || !r.nT) { el.innerHTML = '<p class="nota">Añade piezas para ver el material, el canto, el tiempo y el coste.</p>'; return; }
  pintarResumen(r, el);
}
function pintarTiposCanto() {
  $('tiposCanto').innerHTML = costes.tipos.map(""")
rep("""<button class="quitar" data-quitarTipo title="Quitar este tipo de canto (sus piezas pasan al primero)">✕</button>` : ''}</td></tr>`).join('');
  const r = resumenCoste(), el = $('resumen');
  if (!r || !r.nT) { el.innerHTML = '<p class="nota">Añade piezas para ver el material, el canto, el tiempo y el coste.</p>'; return; }
  const fila""","""<button class="quitar" data-quitarTipo title="Quitar este tipo de canto (sus piezas pasan al primero)">✕</button>` : ''}</td></tr>`).join('');
}
function pintarResumen(r, el) {
  const fila""")
rep("""  t[k] = e.target.value; const r = $('resumen'); if (r) { const foco = document.activeElement; pintarCoste(); if (foco && foco.dataset && foco.dataset.k) { const el = document.querySelector(`#tiposCanto tr[data-i="${i}"] input[data-k="${k}"]`); if (el) { el.focus(); el.setSelectionRange(el.value.length, el.value.length); } } }
  if (k === 'nombre') pintarLista(); guardar(); });""","""  t[k] = e.target.value; pintarCoste(); if (k === 'nombre') pintarLista(); guardar(); });""")
rep("""piezas.forEach(p => { if (p.tipoCanto === t.id) delete p.tipoCanto; }); pintarLista(); pintarCoste(); guardar(); });""","""piezas.forEach(p => { if (p.tipoCanto === t.id) delete p.tipoCanto; }); pintarTiposCanto(); pintarLista(); pintarCoste(); guardar(); });""")
rep("""costes.tipos.push({ id: 'c' + Date.now().toString(36), nombre: `Canto ${costes.tipos.length + 1}`, precio: '' }); pintarLista();""","""costes.tipos.push({ id: 'c' + Date.now().toString(36), nombre: `Canto ${costes.tipos.length + 1}`, precio: '' }); pintarTiposCanto(); pintarLista();""")
rep("""function todo() { calcular(); pintarLista(); pintarVista(); notaSeparacion(); guardar(); }""","""function todo() { calcular(); pintarTiposCanto(); pintarLista(); pintarVista(); notaSeparacion(); guardar(); }""")
rep("""  if (c === 'nombre') p.nombre = e.target.value.slice(0, 60);
  else if (c === 'veta')""","""  if (c === 'tipoCanto') return;
  if (c === 'nombre') p.nombre = e.target.value.slice(0, 60);
  else if (c === 'veta')""")
rep("""avisos.innerHTML = `<div class="aviso mal">Revisa las medidas del tablero y de la fresa.</div>`; botones(false); return; }""","""avisos.innerHTML = `<div class="aviso mal">Revisa las medidas del tablero y de la fresa.</div>`; botones(false); pintarCoste(); return; }""")
open(P, 'w', encoding='utf-8').write(s)
print('Anidador v7: cantos y coste:', P)
