"""Construye unos apuntes sueltos (taladros, TpaCAD…) con el estilo de los apuntes ISO.
Uso: python3 construir_doc.py <fuente.html> <salida.html> "<título>" [carpeta de dibujos …]
{{svg:nombre}} o {{svg:nombre|70%}} se busca en las carpetas de dibujos dadas y, si no, en guia_iso/diagramas/.
El estilo (pre.prog, figure.dib, tablas…) es el de la fuente de los apuntes ISO más el de los manuales."""
import sys, os, re, subprocess
AQUI = os.path.dirname(os.path.abspath(__file__))
fuente, salida, titulo = sys.argv[1:4]; dirs = sys.argv[4:] + [os.path.join(AQUI, 'guia_iso', 'diagramas')]
s = open(fuente, encoding='utf-8').read()
estilo_iso = re.search(r'<style>(.*?)</style>', open(os.path.join(AQUI, 'guia_iso', 'fuente_apuntes_iso.html'), encoding='utf-8').read(), re.S).group(1)
s = s.replace('<style>', '<style>\n' + estilo_iso + '\n', 1) if '<style>' in s else '<style>' + estilo_iso + '</style>\n' + s
def svg(m):
    for d in dirs:
        f = os.path.join(d, m.group(1) + '.svg')
        if os.path.exists(f): break
    t = open(f, encoding='utf-8').read()
    return re.sub(r'style="width:[^"]*"', f'style="width:{m.group(2)}"', t, count=1) if m.group(2) else t
s = re.sub(r'\{\{svg:([a-z0-9_]+)(?:\|([0-9]+%))?\}\}', svg, s)
tmp = os.path.join(os.path.dirname(os.path.abspath(fuente)), '_tmp_con_dibujos.html'); open(tmp, 'w', encoding='utf-8').write(s)
suite = os.path.abspath(os.path.join(AQUI, '..', '..'))
try:
    subprocess.run([sys.executable, os.path.join(AQUI, 'anidador_calculadora', 'construir_manual.py'), tmp, AQUI, salida, titulo, os.path.join(suite, 'manual_corrector.html')], check=True)
finally: os.remove(tmp)
