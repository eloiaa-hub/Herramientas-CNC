"""Dibujos (SVG) de los apuntes «Códigos ISO de la Suite CNC». Uso: python3 diagramas.py  (los deja en diagramas/)
Cada dibujo se escribe en mm del plano (Y hacia arriba) y se pasa a SVG (Y hacia abajo)."""
import os, math
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'diagramas'); os.makedirs(OUT, exist_ok=True)
AZUL, NAR, VERDE, GRIS, ROJO, TINTA, MADERA, MADERA2 = '#005A9C', '#C4580C', '#1e8449', '#8a97a5', '#c0392b', '#1c2733', '#f3e3c3', '#c9a46a'

class D:
    def __init__(s, w, h, esc=4, x0=0, y0=0):
        s.w, s.h, s.k, s.x0, s.y0, s.o = w, h, esc, x0, y0, []
    def P(s, x, y): return (round(s.x0 + x * s.k, 2), round(s.h - (s.y0 + y * s.k), 2))
    def add(s, t): s.o.append(t)
    def linea(s, a, b, col=TINTA, w=1.6, dash=None, flecha=False):
        (x1, y1), (x2, y2) = s.P(*a), s.P(*b)
        s.add(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{col}" stroke-width="{w}"' + (f' stroke-dasharray="{dash}"' if dash else '') + (f' marker-end="url(#f{col[1:]})"' if flecha else '') + '/>')
    def poli(s, pts, col=TINTA, w=1.6, fill='none', dash=None, cerrar=False, flecha=False):
        d = ' '.join(f'{x},{y}' for x, y in (s.P(*p) for p in pts))
        tag = 'polygon' if cerrar else 'polyline'
        s.add(f'<{tag} points="{d}" fill="{fill}" stroke="{col}" stroke-width="{w}"' + (f' stroke-dasharray="{dash}"' if dash else '') + (f' marker-end="url(#f{col[1:]})"' if flecha else '') + ' stroke-linejoin="round"/>')
    def arco(s, c, r, a0, a1, col=TINTA, w=1.6, dash=None, flecha=False, n=60):
        pts = [(c[0] + r * math.cos(math.radians(a0 + (a1 - a0) * i / n)), c[1] + r * math.sin(math.radians(a0 + (a1 - a0) * i / n))) for i in range(n + 1)]
        s.poli(pts, col, w, dash=dash, flecha=flecha)
    def circ(s, c, r, col=TINTA, w=1.4, fill='none', dash=None):
        x, y = s.P(*c); s.add(f'<circle cx="{x}" cy="{y}" r="{round(r * s.k, 2)}" fill="{fill}" stroke="{col}" stroke-width="{w}"' + (f' stroke-dasharray="{dash}"' if dash else '') + '/>')
    def punto(s, c, col=TINTA, r=3):
        x, y = s.P(*c); s.add(f'<circle cx="{x}" cy="{y}" r="{r}" fill="{col}"/>')
    def texto(s, c, t, col=TINTA, tam=12, anc='start', peso='400', dx=0, dy=0, mono=False):
        x, y = s.P(*c); f = "Consolas,'DejaVu Sans Mono',monospace" if mono else "'Segoe UI','DejaVu Sans',Arial,sans-serif"
        s.add(f'<text x="{round(x + dx, 2)}" y="{round(y + dy, 2)}" fill="{col}" font-size="{tam}" font-family="{f}" text-anchor="{anc}" font-weight="{peso}">{t}</text>')
    def rect(s, a, b, col=TINTA, fill='none', w=1.4, dash=None):
        (x1, y1), (x2, y2) = s.P(*a), s.P(*b)
        s.add(f'<rect x="{min(x1, x2)}" y="{min(y1, y2)}" width="{abs(x2 - x1)}" height="{abs(y2 - y1)}" fill="{fill}" stroke="{col}" stroke-width="{w}"' + (f' stroke-dasharray="{dash}"' if dash else '') + '/>')
    def cero(s, c):
        x, y = s.P(*c); r = 7
        s.add(f'<circle cx="{x}" cy="{y}" r="{r}" fill="#fff" stroke="{TINTA}" stroke-width="1.3"/>'
              f'<path d="M{x},{y} L{x + r},{y} A{r},{r} 0 0,0 {x},{y - r} Z" fill="{TINTA}"/><path d="M{x},{y} L{x - r},{y} A{r},{r} 0 0,0 {x},{y + r} Z" fill="{TINTA}"/>')
    def svg(s, nombre, ancho='100%'):
        marcas = ''.join(f'<marker id="f{c[1:]}" viewBox="0 0 10 10" refX="8.5" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="{c}"/></marker>' for c in (AZUL, NAR, VERDE, GRIS, ROJO, TINTA))
        t = f'<svg class="dib" viewBox="0 0 {s.w} {s.h}" style="width:{ancho}" xmlns="http://www.w3.org/2000/svg"><defs>{marcas}</defs>' + ''.join(s.o) + '</svg>'
        open(os.path.join(OUT, nombre + '.svg'), 'w', encoding='utf-8').write(t)

def flecha_en_arco(d, c, r, ang, sentido, col):
    # pequeña flecha tangente en el ángulo ang (grados); sentido +1 antihorario, -1 horario
    a = math.radians(ang); p = (c[0] + r * math.cos(a), c[1] + r * math.sin(a)); t = (-math.sin(a) * sentido, math.cos(a) * sentido)
    d.linea((p[0] - t[0] * 2.2, p[1] - t[1] * 2.2), (p[0] + t[0] * 0.6, p[1] + t[1] * 0.6), col, 1.8, flecha=True)

# 1. Ejes, cero pieza y alturas
d = D(660, 240, esc=2.2, x0=40, y0=36)
d.rect((0, 0), (110, 70), GRIS, MADERA, 1.2)
d.poli([(15, 12), (95, 12), (95, 58), (15, 58)], AZUL, 2, cerrar=True)
d.linea((0, 0), (122, 0), ROJO, 1.8, flecha=True); d.linea((0, 0), (0, 84), VERDE, 1.8, flecha=True)
d.texto((123, 0), 'X+', ROJO, 13, peso='700', dy=5); d.texto((0, 86), 'Y+', VERDE, 13, peso='700', anc='middle', dy=-4)
d.cero((0, 0)); d.texto((0, 0), 'X0 Y0 · cero pieza', TINTA, 11.5, dx=10, dy=20)
d.texto((55, 72), 'PLANTA (desde arriba)', GRIS, 11, anc='middle', peso='700', dy=-8)
e = D(660, 240, esc=2.2, x0=345, y0=36); e.o = d.o
e.rect((0, 0), (90, 18), GRIS, MADERA, 1.2)
e.linea((-10, 18), (92, 18), TINTA, 1.3, dash='5 4'); e.texto((93, 18), 'Z0: cara de arriba', TINTA, 11, dy=4)
e.linea((-10, 38), (92, 38), GRIS, 1.3, dash='5 4'); e.texto((93, 38), 'Z20: seguridad', GRIS, 11, dy=4)
e.rect((42, 15), (48, 46), NAR, '#f6c9a6', 1.4); e.rect((40, 46), (50, 62), GRIS, '#dfe5eb', 1.2)
e.linea((-10, 15), (55, 15), NAR, 1, dash='2 3'); e.texto((-11, 15), 'Z−3', NAR, 11, anc='end', dy=4, peso='700')
e.linea((-24, -4), (-24, 70), AZUL, 1.8, flecha=True); e.texto((-24, 72), 'Z+', AZUL, 13, anc='middle', dy=-4, peso='700')
e.texto((45, 0), 'ALZADO (de frente)', GRIS, 11, anc='middle', peso='700', dy=18)
d.svg('ejes')

# 2. G2 y G3
d = D(640, 230, esc=3, x0=30, y0=40)
for cx, sent, nom, col in ((45, -1, 'G2 · sentido horario', AZUL), (155, 1, 'G3 · sentido antihorario', NAR)):
    c = (cx, 25); r = 22
    if sent < 0: d.arco(c, r, 160, 20, col, 2.4, flecha=True)
    else: d.arco(c, r, 20, 160, col, 2.4, flecha=True)
    d.punto(c, GRIS, 2.5); d.circ(c, r, GRIS, 0.8, dash='3 4')
    a0 = 160 if sent < 0 else 20
    d.punto((c[0] + r * math.cos(math.radians(a0)), c[1] + r * math.sin(math.radians(a0))), TINTA, 3.5)
    d.texto((c[0], c[1] - r), nom, col, 13.5, 'middle', '700', dy=28)
d.texto((100, 60), 'vistos desde arriba, como en el plano (eje Z hacia ti)', GRIS, 11.5, 'middle')
d.svg('g2g3')

# 3. I y J
d = D(640, 260, esc=4.2, x0=30, y0=20)
for gx in range(0, 71, 10): d.linea((gx, 0), (gx, 50), '#e6ebf0', 1)
for gy in range(0, 51, 10): d.linea((0, gy), (70, gy), '#e6ebf0', 1)
C, Pp, Q = (30, 30), (45, 10), (55, 30)
d.circ(C, 25, GRIS, 0.8, dash='3 4')
a0 = math.degrees(math.atan2(Pp[1] - C[1], Pp[0] - C[0])); d.arco(C, 25, a0, 0, AZUL, 2.6, flecha=True)
d.linea(Pp, (C[0], Pp[1]), NAR, 2, flecha=True); d.linea((C[0], Pp[1]), C, NAR, 2, flecha=True)
d.texto(((Pp[0] + C[0]) / 2, Pp[1]), 'I = −15', NAR, 13, 'middle', '700', dy=17)
d.texto((C[0], (Pp[1] + C[1]) / 2), 'J = 20', NAR, 13, 'end', '700', dx=-6, dy=4)
d.punto(C, NAR, 3.5); d.texto(C, 'centro X30 Y30', NAR, 11.5, 'end', dx=-8, dy=-6)
d.punto(Pp, TINTA, 4); d.texto(Pp, 'inicio X45 Y10', TINTA, 11.5, dx=8, dy=14)
d.punto(Q, TINTA, 4); d.texto(Q, 'final X55 Y30', TINTA, 11.5, dx=8, dy=-6)
d.texto((80, 34), 'G3 X55 Y30 I−15 J20', AZUL, 14, 'start', '700', mono=True)
d.texto((80, 26), 'I: del inicio al centro en X', TINTA, 12); d.texto((80, 20), 'J: del inicio al centro en Y', TINTA, 12)
d.texto((80, 14), '(siempre desde el punto de inicio,', GRIS, 11.5); d.texto((80, 9), 'también en G90)', GRIS, 11.5)
d.svg('ij')

# 4. R positivo y R negativo
d = D(640, 270, esc=3.4, x0=200, y0=62)
A, B, R = (0, 0), (40, 0), 25
h = math.sqrt(R * R - 20 * 20)
c1, c2 = (20, -h), (20, h)       # G2 de A a B: corto (R+) con el centro abajo; largo (R−) con el centro arriba
ang = lambda p, c: math.degrees(math.atan2(p[1] - c[1], p[0] - c[0]))
d.circ(c2, R, GRIS, 0.8, dash='3 4')
d.arco(c1, R, ang(A, c1), ang(B, c1), AZUL, 2.8, flecha=True)
d.arco(c2, R, ang(A, c2) + 360, ang(B, c2), NAR, 2.8, flecha=True)
d.punto(A, TINTA, 4); d.punto(B, TINTA, 4); d.texto(A, 'inicio', TINTA, 11.5, 'end', dx=-8, dy=4); d.texto(B, 'final', TINTA, 11.5, dx=10, dy=4)
d.punto(c2, NAR, 2.5)
d.texto((20, 0), 'G2 X40 Y0 R25', AZUL, 13, 'middle', '700', dy=30, mono=True); d.texto((20, 0), 'el arco corto: menos de media vuelta', AZUL, 11, 'middle', dy=46)
d.texto((48, 38), 'G2 X40 Y0 R−25', NAR, 13, 'start', '700', mono=True); d.texto((48, 38), 'el arco largo: más de media vuelta', NAR, 11, 'start', dy=14)
d.svg('r')

# 5. G41 y G42: la regla de la mano
d = D(640, 200, esc=4, x0=40, y0=20)
d.linea((0, 20), (128, 20), AZUL, 2.6, flecha=True); d.texto((128, 20), 'sentido de avance', AZUL, 11.5, 'end', dy=-8)
d.texto((0, 20), 'contorno del plano', AZUL, 11.5, dy=-8)
for x, y, nom, txt in ((55, 27, 'G41', 'fresa a la IZQUIERDA'), (55, 13, 'G42', 'fresa a la DERECHA')):
    d.circ((x, y), 6, NAR, 1.6, '#f6c9a6'); d.punto((x, y), NAR, 2)
    d.texto((x + 9, y), f'<tspan font-weight="700">{nom}</tspan> · {txt}', NAR, 13, dy=5)
d.texto((64, 0), 'mira en el sentido en que avanza la fresa: G41 la lleva a tu izquierda y G42 a tu derecha', GRIS, 11.5, 'middle', dy=-2)
d.svg('g41g42')

# 6. Exterior e interior, en sentido antihorario
d = D(640, 230, esc=3.1, x0=40, y0=25)
d.rect((0, 0), (90, 60), GRIS, MADERA, 1.2)
d.poli([(10, 8), (80, 8), (80, 52), (10, 52)], AZUL, 2.4, cerrar=True)
for (a, b) in (((40, 8), (52, 8)), ((80, 24), (80, 36)), ((52, 52), (40, 52)), ((10, 36), (10, 24))): d.linea(a, b, AZUL, 2.4, flecha=True)
d.circ((45, 30), 11, ROJO, 2.4, '#fff')
flecha_en_arco(d, (45, 30), 11, 0, 1, ROJO); flecha_en_arco(d, (45, 30), 11, 180, 1, ROJO)
d.circ((45, 4), 4, NAR, 1.5, '#f6c9a6'); d.texto((45, 4), 'G42', NAR, 11, 'middle', '700', dy=22)
d.circ((45, 23), 4, NAR, 1.5, '#f6c9a6'); d.texto((45, 31), 'G41', NAR, 11, 'middle', '700', dy=4)
d.texto((45, 60), 'los dos contornos, en sentido antihorario', GRIS, 11.5, 'middle', dy=-6)
d.texto((96, 52), 'Exterior (azul): la fresa va por fuera.', AZUL, 12.5, peso='700')
d.texto((96, 46), 'En antihorario, el exterior queda a la derecha', TINTA, 11.5); d.texto((96, 41), 'de la fresa → G42.', TINTA, 11.5)
d.texto((96, 31), 'Interior (rojo): la fresa va por dentro.', ROJO, 12.5, peso='700')
d.texto((96, 25), 'En antihorario, el hueco queda a la izquierda', TINTA, 11.5); d.texto((96, 20), 'de la fresa → G41.', TINTA, 11.5)
d.texto((96, 9), 'En sentido horario, al revés.', GRIS, 11.5, peso='700')
d.svg('ext_int')

# 7. Entrada y salida (exterior en antihorario, G42); dibujo esquemático (la entrada, exagerada)
d = D(640, 330, esc=4.6, x0=120, y0=120)
d.rect((-14, -16), (64, 38), GRIS, MADERA, 1.2)
d.add(f'<rect x="{d.P(0, 26)[0]}" y="{d.P(0, 26)[1]}" width="{50 * d.k}" height="{26 * d.k}" fill="#e9d2a4" stroke="none"/>')
d.poli([(25, 0), (50, 0), (50, 26), (0, 26), (0, 0), (25, 0)], AZUL, 2.2)
for (a, b) in (((34, 0), (42, 0)), ((50, 9), (50, 17)), ((17, 26), (9, 26)), ((0, 17), (0, 9))): d.linea(a, b, AZUL, 2.2, flecha=True)
d.poli([(25, -3), (53, -3), (53, 29), (-3, 29), (-3, -3), (25, -3)], VERDE, 1.2, dash='4 3')
d.texto((25, 13), 'pieza', GRIS, 12, 'middle', dy=4)
d.linea((25, -12), (25, 0), VERDE, 2.6, flecha=True); d.punto((25, -12), TINTA, 4)
d.texto((25, -12), 'X25 Y−12: aquí se baja, en la zona que sobra', TINTA, 11.5, dx=8, dy=4)
d.texto((-14, -16), '① G42 G1 X25 Y0 · entrada en recta (activa la compensación)', VERDE, 11.5, peso='700', dy=20)
d.linea((22.5, 0), (22.5, -11), ROJO, 1.8, dash='4 3', flecha=True)
d.texto((-14, -16), '③ G40 G1 X25 Y−12 · salida en recta (la anula)', ROJO, 11.5, peso='700', dy=38)
d.texto((66, 20), '② el contorno', AZUL, 11.5, peso='700'); d.texto((66, 20), 'en verde, por donde pasa', VERDE, 11, dy=15); d.texto((66, 20), 'el centro de la fresa', VERDE, 11, dy=29)
d.svg('entrada')

# 8. Esquina interior: queda el radio de la fresa
d = D(640, 230, esc=3.2, x0=60, y0=20)
d.poli([(0, 50), (0, 0), (60, 0)], AZUL, 2.4)
d.add(f'<path d="M{d.P(0, 50)[0]},{d.P(0, 50)[1]} L{d.P(0, 0)[0]},{d.P(0, 0)[1]} L{d.P(60, 0)[0]},{d.P(60, 0)[1]} L{d.P(60, -6)[0]},{d.P(60, -6)[1]} L{d.P(-6, -6)[0]},{d.P(-6, -6)[1]} L{d.P(-6, 50)[0]},{d.P(-6, 50)[1]} Z" fill="{MADERA}" stroke="none"/>')
d.poli([(0, 50), (0, 0), (60, 0)], AZUL, 2.4)
r = 8
d.circ((r, r), r, NAR, 1.6, '#f6c9a6'); d.punto((r, r), NAR, 2.5)
d.arco((r, r), r, 180, 270, ROJO, 2.6)
d.poli([(r, 50), (r, r), (60, r)], NAR, 1.4, dash='5 4')
d.texto((72, 40), 'la fresa no entra en la esquina:', TINTA, 12, peso='700')
d.texto((72, 40), 'queda redondeada con su radio', TINTA, 12, dy=16)
d.texto((72, 40), 'Si el plano pide un arco cóncavo más pequeño', GRIS, 11.5, dy=40)
d.texto((72, 40), 'que el radio de la fresa, la fresa no cabe', GRIS, 11.5, dy=56); d.texto((72, 40), 'y el Simulador da un error.', GRIS, 11.5, dy=72)
d.svg('esquina')

# 9. Concordancia y oposición (vista desde arriba, husillo a derechas: M03)
d = D(640, 240, esc=3.4, x0=20, y0=46)
for x0, nom, txt, abajo in ((0, 'Concordancia', 'G41 con M03: la pieza a la derecha', True), (95, 'Oposición', 'G42 con M03: la pieza a la izquierda', False)):
    c = (x0 + 40, 25)
    if abajo: d.rect((x0, 4), (x0 + 80, 16), GRIS, MADERA, 1)
    else: d.rect((x0, 34), (x0 + 80, 46), GRIS, MADERA, 1)
    d.circ(c, 9, NAR, 1.6, '#f6c9a6')
    d.arco(c, 13, 130, 30, NAR, 1.8, flecha=True)
    d.linea((x0 + 4, 25), (x0 + 24, 25), VERDE, 2.4, flecha=True)
    d.texto((x0 + 40, 0), nom, AZUL, 14, 'middle', '700', dy=18)
    d.texto((x0 + 40, 0), txt, TINTA, 11.5, 'middle', dy=34)
d.texto((87, 52), 'vista desde arriba · avance en verde · en marrón, la pieza (la pared que queda)', GRIS, 11, 'middle', dy=-2)
d.svg('concordancia')

# 10. K: un arco en el plano XZ (G18), visto de frente: redondear un canto de R10
d = D(640, 240, esc=3.6, x0=50, y0=170)
d.rect((0, -30), (60, 0), GRIS, MADERA, 1.2)
d.add(f'<rect x="{d.P(60, 0)[0]}" y="{d.P(60, 0)[1]}" width="{25 * d.k}" height="{30 * d.k}" fill="#fff" stroke="none"/>')
C = (50, -10)
d.rect((50.3, -10), (61, 0.6), '#ffffff', '#ffffff', 0)
d.poli([C] + [(C[0] + 10 * math.cos(math.radians(a)), C[1] + 10 * math.sin(math.radians(a))) for a in range(0, 91, 5)], MADERA, 0.1, fill=MADERA, cerrar=True)
d.linea((0, 0), (50, 0), AZUL, 2.4); d.arco(C, 10, 90, 0, AZUL, 2.8, flecha=True); d.linea((60, -10), (60, -30), AZUL, 2.4)
d.punto((50, 0), TINTA, 4); d.texto((50, 0), 'inicio X50 Z0', TINTA, 11.5, 'end', dx=-6, dy=-8)
d.punto((60, -10), TINTA, 4); d.texto((60, -10), 'final X60 Z−10', TINTA, 11.5, dx=8, dy=4)
d.linea((50, 0), C, NAR, 2, flecha=True); d.texto((50, -5), 'K = −10', NAR, 12.5, 'end', '700', dx=-6, dy=4)
d.punto(C, NAR, 3.5); d.texto(C, 'centro', NAR, 11, 'end', dx=-8, dy=14)
d.linea((-6, -36), (75, -36), ROJO, 1.6, flecha=True); d.texto((76, -36), 'X+', ROJO, 12, peso='700', dy=4)
d.linea((-6, -36), (-6, 10), AZUL, 1.6, flecha=True); d.texto((-6, 11), 'Z+', AZUL, 12, 'middle', '700', dy=-4)
d.texto((86, 6), 'G18 G3 X60 Z−10 I0 K−10', AZUL, 14, peso='700', mono=True)
d.texto((86, -2), 'vista de frente (plano XZ): I es la distancia', TINTA, 11.5)
d.texto((86, -7), 'al centro en X y K, la distancia en Z', TINTA, 11.5)
d.texto((86, -15), 'Es G3 aunque, visto de frente, vaya como las', ROJO, 11.5); d.texto((86, -20), 'agujas del reloj: en G18 el sentido se mira', ROJO, 11.5); d.texto((86, -25), 'desde detrás de la máquina (desde Y+).', ROJO, 11.5)
d.svg('k')

# 11. Coordenadas polares
d = D(640, 260, esc=3.2, x0=90, y0=40)
for gx in range(0, 61, 10): d.linea((gx, 0), (gx, 50), '#e6ebf0', 1)
for gy in range(0, 51, 10): d.linea((0, gy), (60, gy), '#e6ebf0', 1)
O = (10, 10); R = 40; A = 30
P = (O[0] + R * math.cos(math.radians(A)), O[1] + R * math.sin(math.radians(A)))
d.linea(O, (O[0] + 52, O[1]), GRIS, 1.2, dash='4 3')
d.linea(O, P, AZUL, 2.6, flecha=True); d.texto(((O[0] + P[0]) / 2, (O[1] + P[1]) / 2), 'radio 40', AZUL, 12.5, 'end', '700', dx=-4, dy=-6)
d.arco(O, 14, 0, A, NAR, 2, flecha=True); d.texto((O[0] + 16, O[1] + 3.5), '30°', NAR, 12.5, peso='700', dx=2)
d.cero(O); d.texto(O, 'origen polar', TINTA, 11.5, 'middle', dy=22)
d.punto(P, TINTA, 4.5); d.texto(P, 'el punto', TINTA, 11.5, dx=8, dy=-6)
d.linea(P, (P[0], O[1]), GRIS, 1, dash='3 3'); d.texto((P[0], O[1]), 'X = 40 · cos 30° = 34,641', GRIS, 11, 'middle', dy=16)
d.texto((P[0], (O[1] + P[1]) / 2), 'Y = 40 · sen 30° = 20', GRIS, 11, dx=8)
d.texto((82, 50), 'Polares: el punto se da con', TINTA, 12.5, peso='700'); d.texto((82, 50), 'una distancia (el radio) y un ángulo', TINTA, 12, dy=16)
d.texto((82, 50), 'desde el origen polar.', TINTA, 12, dy=32)
d.texto((82, 50), 'El ángulo se mide desde el eje +X,', GRIS, 11.5, dy=56); d.texto((82, 50), 'en sentido antihorario.', GRIS, 11.5, dy=72)
d.svg('polares')
print('dibujos en', OUT)
