// Capturas de los apuntes «Códigos ISO de la Suite CNC»: el Simulador con el plano del ejercicio (ISO 13)
// y el programa del Calcador, bien compensado y con G41/G42 cambiados.
// Uso: LANG=C.UTF-8 node capt_iso.js        (deja las imágenes en capturas/)
const path = require('path'), fs = require('fs');
const { lanzar, SUITE } = require('../../pruebas/comun.js');
const OUT = path.join(__dirname, 'capturas'); fs.mkdirSync(OUT, { recursive: true });
const EJ = path.join(__dirname, '../../pruebas/ISO 13 - dos herramientas');
const PLANO = path.join(__dirname, '../../pruebas/Prueba01.json');
(async () => {
  const b = await lanzar(); const ctx = await b.newContext({ viewport: { width: 1280, height: 800 }, deviceScaleFactor: 2 });
  // el programa, generado por el Calcador (G90, según el trazado, G41/G42 en la entrada de cada contorno)
  const cal = await ctx.newPage(); cal.on('dialog', d => d.accept());
  await cal.goto('file://' + path.join(SUITE, 'calcador.html')); await cal.evaluate(() => localStorage.clear()); await cal.reload(); await cal.waitForTimeout(700);
  await cal.setInputFiles('#fileJSON', PLANO); await cal.waitForTimeout(400); await cal.evaluate(() => abrirMec());
  const nc = await cal.evaluate(() => { cfgMec.comp = 'auto'; cfgMec.coord = 'G90'; cfgMec.estr = 'plano'; pintarCamposMec(); generarMec(); return document.getElementById('mecTexto').value; });
  fs.writeFileSync(path.join(OUT, 'pieza.nc'), nc);
  const malo = nc.replace(/G41/g, 'GX').replace(/G42/g, 'G41').replace(/GX/g, 'G42');
  const sim = await ctx.newPage(); sim.on('dialog', d => d.accept());
  await sim.goto('file://' + path.join(SUITE, 'simulador3d.html')); await sim.evaluate(() => localStorage.clear()); await sim.reload(); await sim.waitForTimeout(1000);
  const plano = JSON.parse(fs.readFileSync(PLANO, 'utf8'));
  const foto = async (prog, nombre, modo2D) => {
    await sim.evaluate(([prog, plano, modo2D]) => { cargarGcodeTexto(prog, 'pieza.nc'); cargarPlano(plano, 'Prueba01'); setModo2D(modo2D); irAlFinal(); }, [prog, plano, modo2D]);
    await sim.waitForTimeout(900); await sim.evaluate(() => document.getElementById('snack').classList.remove('visible')); await sim.waitForTimeout(400);
    const ev = await sim.evaluate(() => document.getElementById('planoEval').innerText); fs.writeFileSync(path.join(OUT, nombre + '.txt'), ev);
    const bb = await (await sim.$('#viewport')).boundingBox(); const recorte = modo2D ? 0 : 60;
    await sim.screenshot({ path: path.join(OUT, nombre + '.png'), clip: { x: bb.x, y: bb.y + recorte, width: bb.width, height: bb.height - recorte - (modo2D ? 0 : 40) } });
  };
  await foto(nc, 'bien_2d', true);
  await foto(malo, 'mal_2d', true);
  await foto(nc, 'bien_3d', false);
  await sim.evaluate(() => setModo2D(true));
  await sim.screenshot({ path: path.join(OUT, 'pantalla.png') });
  console.log(await sim.evaluate(() => document.getElementById('planoEval').innerText));
  await b.close(); console.log('capturas en', OUT);
})();
