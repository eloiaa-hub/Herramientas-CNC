"""Manual del Calcador: 🧩 Ejercicio aleatorio (al final del capítulo 8, Formas). Uso (tras node capt_generador.js): python3 manual_generador.py <suite>"""
import sys, os, io, base64
from PIL import Image
D = sys.argv[1] if len(sys.argv) > 1 else '../../..'
P = os.path.join(D, 'manual_calcador.html'); s = open(P, encoding='utf-8').read()
assert 'Ejercicio aleatorio</h3>' not in s, 'ya aplicado'
im = Image.open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'capturas', 'generador.png')).convert('RGB')
im = im.resize((1400, round(im.height * 1400 / im.width)), Image.LANCZOS); b = io.BytesIO(); im.save(b, 'WEBP', quality=82, method=6)
src = 'data:image/webp;base64,' + base64.b64encode(b.getvalue()).decode()
def rep(a, c):
    global s
    assert s.count(a) == 1, (s.count(a), a[:80]); s = s.replace(a, c)
cap = 'La ventana 🧩 Ejercicio aleatorio: los parámetros a la izquierda y seis propuestas, cada una con su número. Un clic en una la pasa al dibujo.'
rep('</section>\n<section class="capitulo" id="texto">', f'''<h3>🧩 Ejercicio aleatorio</h3>
<p>Para preparar ejercicios nuevos sin dibujarlos, <span class="boton">🧩 Ejercicio aleatorio…</span> (arriba del todo en el panel de la izquierda) los genera al azar con estas mismas formas: rectángulos, polígonos, estrellas, círculos y colisos, con agujeros dentro.</p>
<ul>
<li><strong>Tamaño</strong>: el ancho y el alto máximos que ocupa el conjunto (por ejemplo, 250 × 200), y lo que ocupa como mínimo cada pieza de su sitio.</li>
<li><strong>Piezas</strong> e <strong>interiores de cada pieza</strong>: cuántos (de… a…) y qué formas pueden salir para cada cosa.</li>
<li><strong>Cotas múltiplos de</strong> 1, 5 o 10 mm: los rectángulos, los colisos, los centros y los radios salen en esos múltiplos, para que el alumno trabaje con números redondos. Los polígonos tienen el lado de abajo en la rejilla; sus otros vértices, como los de las estrellas, dan decimales (se calculan con polares). <strong>Formas giradas</strong> las gira en múltiplos de 15°, y también dan decimales.</li>
<li><strong>Diámetro de la fresa</strong> y <strong>pared mínima</strong>: ningún agujero es más pequeño que dos diámetros de fresa, entre un agujero y el borde de la pieza (o entre dos agujeros) queda al menos la pared, y las piezas quedan separadas el diámetro más 4 mm. Así todos los ejercicios se pueden mecanizar. Si un agujero no cabe, la propuesta lo dice.</li>
</ul>
<figure class="ancha"><img src="{src}" alt="{cap}"><figcaption>{cap}</figcaption></figure>
<p>Haz clic en la propuesta que quieras: sustituye al dibujo (se deshace con <kbd>Ctrl</kbd>+<kbd>Z</kbd>) con el cero pieza en la esquina de abajo a la izquierda del conjunto, las cotas a la vista y cada pieza agrupada con sus agujeros. Las formas siguen siendo editables, como si las hubieras dibujado tú. <span class="boton">🎲 Otras seis</span> enseña otras. Cada propuesta lleva un <strong>número</strong>: con el mismo número y los mismos parámetros sale el mismo ejercicio (escríbelo en <em>Número</em> y pulsa <em>Ver</em>). El número y los parámetros se guardan en el JSON, y el proyecto se llama «Ejercicio aleatorio» y su número.</p>
</section>
<section class="capitulo" id="texto">''')
s = s.replace('Calcador de contornos v85 · Por Eloi A.A.', 'Calcador de contornos v86 · Por Eloi A.A.')
open(P, 'w', encoding='utf-8').write(s); print('manual_calcador.html: ejercicio aleatorio')
