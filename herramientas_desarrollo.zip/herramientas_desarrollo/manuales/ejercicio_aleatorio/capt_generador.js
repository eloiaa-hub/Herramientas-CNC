// Captura del manual del Calcador: la ventana 🧩 Ejercicio aleatorio con sus seis propuestas
const path = require('path'), fs = require('fs');
const { lanzar, SUITE } = require('../../pruebas/comun.js');
const OUT = path.join(__dirname, 'capturas'); fs.mkdirSync(OUT, { recursive: true });
(async () => {
  const b = await lanzar(); const ctx = await b.newContext({ viewport: { width: 1500, height: 1000 }, deviceScaleFactor: 1.5 }), p = await ctx.newPage(); p.on('dialog', d => d.accept());
  await p.goto('file://' + path.join(SUITE, 'calcador.html')); await p.evaluate(() => localStorage.clear()); await p.reload(); await p.waitForTimeout(700);
  await p.evaluate(() => { genBase = 31400; abrirGenerador(); elegirNivel('tangentes'); });
  await p.waitForTimeout(500);
  await (await p.$('#modalGenerador .help-modal')).screenshot({ path: path.join(OUT, 'generador3.png') });
  await b.close(); console.log('captura en', OUT);
})();
