"""Manual del Calcador: 🧩 Ejercicio aleatorio, fase 2 (esquinas y lados en arco) y captura nueva. Uso (tras node capt_generador.js): python3 manual_generador_fase2.py <suite>"""
import sys, os, io, base64, re
from PIL import Image
D = sys.argv[1] if len(sys.argv) > 1 else '../../..'
P = os.path.join(D, 'manual_calcador.html'); s = open(P, encoding='utf-8').read()
assert '<strong>Esquinas y lados</strong>' not in s, 'ya aplicado'
im = Image.open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'capturas', 'generador2.png')).convert('RGB')
im = im.resize((1400, round(im.height * 1400 / im.width)), Image.LANCZOS); b = io.BytesIO(); im.save(b, 'WEBP', quality=82, method=6)
src = 'data:image/webp;base64,' + base64.b64encode(b.getvalue()).decode()
def rep(a, c):
    global s
    assert s.count(a) == 1, (s.count(a), a[:80]); s = s.replace(a, c)
rep('<li><strong>Cotas múltiplos de</strong> 1, 5 o 10 mm:', '<li><strong>Esquinas y lados</strong>: la probabilidad de que cada esquina de un rectángulo, polígono o estrella salga <strong>redondeada</strong> (arco hacia fuera, tangente a los dos lados), <strong>hacia dentro</strong> (cuarto de círculo con centro en la esquina) o con <strong>chaflán</strong>, y de que un lado recto (entre dos esquinas vivas) salga como <strong>arco abombado</strong> o <strong>hundido</strong>. Con <em>También en los interiores</em>, igual en los agujeros. Los radios y los chaflanes salen en múltiplos del paso de las cotas. Un rectángulo con solo esquinas sigue siendo un rectángulo editable; con algún lado en arco, o en polígonos y estrellas, queda como un contorno normal.</li>\n<li><strong>Cotas múltiplos de</strong> 1, 5 o 10 mm:')
rep('Así todos los ejercicios se pueden mecanizar.', 'Los arcos que la fresa recorre por su lado cóncavo (una esquina hacia dentro o un lado hundido de una pieza, una esquina redondeada de un agujero…) miden al menos un diámetro de fresa. Así todos los ejercicios se pueden mecanizar.')
m = re.search(r'(<figure class="ancha"><img src=")[^"]+(" alt="La ventana 🧩 Ejercicio aleatorio)', s); assert m
s = s[:m.start()] + m.group(1) + src + m.group(2) + s[m.end():]
s = s.replace('Calcador de contornos v86 · Por Eloi A.A.', 'Calcador de contornos v87 · Por Eloi A.A.')
open(P, 'w', encoding='utf-8').write(s); print('manual_calcador.html: esquinas y lados en arco')
