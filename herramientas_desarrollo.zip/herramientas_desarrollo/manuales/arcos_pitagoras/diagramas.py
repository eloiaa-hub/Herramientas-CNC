"""Dibujos de «Arcos con el centro fuera de la línea: Pitágoras para I y J».
Usa la clase D de ../guia_iso/diagramas.py (mismo estilo que los apuntes). Uso: python3 diagramas.py  (los deja en diagramas/)"""
import os, math
AQUI = os.path.dirname(os.path.abspath(__file__))
src = open(os.path.join(AQUI, '..', 'guia_iso', 'diagramas.py'), encoding='utf-8').read()
src = src[:src.index('\nd = D(')].replace("os.path.join(os.path.dirname(os.path.abspath(__file__)), 'diagramas')", repr(os.path.join(AQUI, 'diagramas')))
exec(src)
B2 = '#d35400'      # variante B (naranja)
A2 = AZUL           # variante A (azul)
H = math.sqrt(15 ** 2 - 5 ** 2)      # 14.142…

def contorno(yc, xa):
    """La pieza: cero abajo a la izquierda; muesca R15 con centro (60, yc), que corta la línea de arriba en 60 ± xa."""
    pts = [(0, 0), (120, 0), (120, 40)]
    pts += [(100 + 20 * math.cos(math.radians(a)), 40 + 20 * math.sin(math.radians(a))) for a in range(0, 91, 5)]
    pts += [(60 + xa, 60)]
    a0 = math.degrees(math.atan2(60 - yc, xa)); a1 = 180 - a0       # de la derecha a la izquierda, por abajo (horario)
    n = 80
    for i in range(1, n):
        a = a0 - (a0 + 360 - a1) * i / n
        pts.append((60 + 15 * math.cos(math.radians(a)), yc + 15 * math.sin(math.radians(a))))
    pts += [(60 - xa, 60), (20, 60)]
    pts += [(20 + 20 * math.cos(math.radians(a)), 40 + 20 * math.sin(math.radians(a))) for a in range(90, 181, 5)]
    pts += [(0, 0)]
    return pts

def cruz(d, c, col, e=2.2, w=1.6):
    d.linea((c[0] - e, c[1]), (c[0] + e, c[1]), col, w); d.linea((c[0], c[1] - e), (c[0], c[1] + e), col, w)

def cota_h(d, a, b, y, txt, col=TINTA, dy=-6):
    d.linea((a, y), (b, y), col, 1, flecha=True); d.linea((b, y), (a, y), col, 1, flecha=True)
    d.texto(((a + b) / 2, y), txt, col, 12, 'middle', '600', dy=dy)

# 1. Las dos piezas superpuestas (pieza entera)
d = D(640, 300, esc=3.4, x0=30, y0=54)
d.poli(contorno(60, 15), A2, 2.4, fill='rgba(0,90,156,.07)')
d.poli(contorno(55, H), B2, 2.4, dash='7 4')
d.cero((0, 0))
cruz(d, (60, 60), A2, 1.6); cruz(d, (60, 55), B2, 1.6)
d.linea((60, 65), (60, 34), GRIS, 0.8, dash='6 3 1.5 3')
d.linea((127, 50), (135, 50), A2, 3); d.texto((137, 50), 'Variante A', A2, 14, 'start', '700', dy=5)
d.texto((127, 44), 'centro en la línea de arriba', A2, 12)
d.linea((127, 34), (135, 34), B2, 3, dash='7 4'); d.texto((137, 34), 'Variante B', B2, 14, 'start', '700', dy=5)
d.texto((127, 28), 'centro 5 mm más abajo', B2, 12)
d.texto((127, 14), 'Todo lo demás es igual:', GRIS, 12); d.texto((127, 9), '120 × 60, R20 y R15', GRIS, 12)
cota_h(d, 0, 120, -7, '120', dy=-5)
d.svg('superpuestas')

# 2. Detalle de la muesca: centros, inicios y finales
d = D(640, 360, esc=10, x0=-280, y0=-330)
a0 = math.degrees(math.atan2(5, H))
d.linea((31, 60), (89, 60), GRIS, 1.2)
d.linea((60, 65), (60, 37.5), GRIS, 0.8, dash='6 3 1.5 3')
d.arco((60, 60), 15, 0, -180, A2, 2.6)
d.arco((60, 55), 15, a0, -180 - a0, B2, 2.6, dash='9 5')
cruz(d, (60, 60), A2, 1.2, 2); cruz(d, (60, 55), B2, 1.2, 2)
d.texto((60, 60), 'centro A (60, 60)', A2, 13, 'start', '700', dx=16, dy=-8)
d.texto((60, 55), 'centro B (60, 55)', B2, 13, 'start', '700', dx=16, dy=5)
for x, t, anc in ((75, 'X75', 'middle'), (45, 'X45', 'middle')):
    d.punto((x, 60), A2, 5); d.texto((x, 60), t, A2, 13, anc, '700', dy=-11)
d.punto((60 + H, 60), B2, 5); d.texto((60 + H, 60), 'X74.142', B2, 13, 'end', '700', dx=-7, dy=20)
d.punto((60 - H, 60), B2, 5); d.texto((60 - H, 60), 'X45.858', B2, 13, 'start', '700', dx=7, dy=20)
d.punto((60, 45), A2, 4); d.texto((60, 45), 'fondo A: Y45', A2, 12, 'start', '700', dx=11, dy=4)
d.punto((60, 40), B2, 4); d.texto((60, 40), 'fondo B: Y40', B2, 12, 'start', '700', dx=11, dy=4)
d.texto((31, 60), 'Y60', GRIS, 12, 'end', dx=-4, dy=4)
d.svg('detalle', '90%')

# 3. El triángulo rectángulo de la variante B
d = D(640, 330, esc=12, x0=-410, y0=-436)
P, C, Q = (60 + H, 60), (60, 55), (60, 60)
d.linea((40, 60), (82, 60), GRIS, 1.2)
d.arco((60, 55), 15, a0, -180 - a0, B2, 1.4, dash='9 5')
d.poli([C, Q, P], B2, 0, fill='rgba(211,84,0,.14)', cerrar=True)
d.linea(C, P, VERDE, 3); d.linea(Q, P, AZUL, 3); d.linea(C, Q, ROJO, 3)
k = 0.8; d.poli([(60, 60 - k), (60 + k, 60 - k), (60 + k, 60)], TINTA, 1.2)
cruz(d, C, B2, 0.9, 2); d.punto(P, B2, 5)
d.texto(C, 'centro C (60, 55)', B2, 13, 'end', '700', dx=-12, dy=14)
d.texto(P, 'inicio del arco', B2, 13, 'start', '700', dx=10, dy=4)
d.texto(P, '(74.142, 60)', B2, 12, 'start', dx=10, dy=19)
d.texto(((60 + P[0]) / 2, 60), '14.142  =  |I|', AZUL, 14, 'middle', '700', dy=-10)
d.texto((60, 57.5), '5  =  |J|', ROJO, 14, 'end', '700', dx=-10, dy=5)
d.texto(((C[0] + P[0]) / 2, (C[1] + P[1]) / 2), 'R15 (hipotenusa)', VERDE, 14, 'start', '700', dx=12, dy=20)
d.texto((60, 47.5), '15²  =  5²  +  14.142²', TINTA, 16, 'middle', '700', mono=True)
d.svg('triangulo', '90%')

# 4. Los signos de I y J (desde el inicio del arco hasta el centro), A y B
def signos(nombre, yc, xa, col, ti, tj):
    d = D(320, 250, esc=7, x0=-268, y0=-238)
    d.linea((42, 60), (79, 60), GRIS, 1.2)
    a0 = math.degrees(math.atan2(60 - yc, xa)); d.arco((60, yc), 15, a0, -180 - a0, col, 2.2)
    P = (60 + xa, 60); cruz(d, (60, yc), col, 1.3, 2); d.punto(P, col, 5)
    d.linea(P, (60.5, 60), AZUL, 2.4, flecha=True)
    d.texto(((60 + P[0]) / 2, 60), ti, AZUL, 13, 'middle', '700', dy=-10)
    if yc != 60:
        d.linea((60, 60), (60, yc + 0.5), ROJO, 2.4, flecha=True); i = tj.rindex(' = '); d.texto((60, (60 + yc) / 2), tj[:i], ROJO, 13, 'start', '700', dx=12, dy=-3); d.texto((60, (60 + yc) / 2), tj[i + 1:], ROJO, 13, 'start', '700', dx=12, dy=13)
        d.texto((60, yc), 'centro', col, 12, 'middle', '600', dy=20)
    else:
        d.texto((60, yc), 'centro', col, 12, 'middle', '600', dy=20); d.texto((60, yc), tj, ROJO, 13, 'middle', '700', dy=36)
    d.texto(P, 'inicio', col, 12, 'start', '600', dx=6, dy=18)
    d.svg(nombre)
signos('signos_a', 60, 15, A2, 'I = 60 − 75 = −15', 'J = 60 − 60 = 0')
signos('signos_b', 55, H, B2, 'I = 60 − 74.142 = −14.142', 'J = 55 − 60 = −5')
# 5. Los planos de la variante B: acotada con el ancho de la muesca (caso 1) y con la posición del centro (caso 2)
COTA = TINTA
def cota_h(d, x1, x2, y, ypie, txt, dy=-5):
    for x in (x1, x2): d.linea((x, ypie), (x, y + (1.2 if y > ypie else -1.2)), COTA, 0.8)
    d.linea((x1, y), (x2, y), COTA, 1, flecha=True); d.linea((x2, y), (x1, y), COTA, 1, flecha=True)
    d.texto(((x1 + x2) / 2, y), txt, COTA, 12.5, 'middle', '600', dy=dy)
def cota_v(d, y1, y2, x, xpie, txt):
    for y in (y1, y2): d.linea((xpie, y), (x - 1.2, y), COTA, 0.8)
    d.linea((x, y1), (x, y2), COTA, 1, flecha=True); d.linea((x, y2), (x, y1), COTA, 1, flecha=True)
    px, py = d.P(x, (y1 + y2) / 2); px -= 6
    d.add(f'<text x="{px}" y="{py}" fill="{COTA}" font-size="12.5" font-weight="600" font-family="\'Segoe UI\',\'DejaVu Sans\',Arial,sans-serif" text-anchor="middle" transform="rotate(-90 {px} {py})">{txt}</text>')
def radio(d, c, r, ang, largo, txt, col=COTA):
    a = math.radians(ang); p = (c[0] + r * math.cos(a), c[1] + r * math.sin(a)); q = (c[0] + (r + largo) * math.cos(a), c[1] + (r + largo) * math.sin(a))
    d.linea(q, p, col, 1, flecha=True); d.linea(c, p, col, 0.6, dash='3 2')
    d.texto(q, txt, col, 12.5, 'start' if math.cos(a) >= 0 else 'end', '700', dx=4 if math.cos(a) >= 0 else -4, dy=4)
def plano(nombre, caso):
    d = D(640, 330, esc=3.0, x0=62, y0=92)
    d.poli(contorno(55, H), TINTA, 2.6, fill='rgba(211,84,0,.06)')
    d.linea((60, 67), (60, 30), GRIS, 0.8, dash='6 3 1.5 3'); cruz(d, (60, 55), B2, 1.8, 1.8)
    d.cero((0, 0))
    cota_h(d, 0, 120, -9 if caso == 1 else -21, -1, '120', dy=16)
    cota_v(d, 0, 60, -10, -1, '60')
    radio(d, (100, 40), 20, 45, 9, 'R20')
    radio(d, (60, 55), 15, -40, 14, 'R15', B2)
    if caso == 1:
        cota_h(d, 60 - H, 60 + H, 70, 61, '28.28')
        cota_h(d, 20, 60 - H, 66, 61, '25.86'); cota_h(d, 60 + H, 100, 66, 61, '25.86')
        d.texto((132, 52), 'Caso 1', B2, 15, 'start', '700'); d.texto((132, 44), 'El plano da el ancho', TINTA, 12.5)
        d.texto((132, 39), 'de la muesca (28.28)', TINTA, 12.5); d.texto((132, 31), 'Falta: la Y del centro', ROJO, 12.5, 'start', '700')
        d.texto((132, 26), '→ Pitágoras da J', ROJO, 12.5, 'start', '700')
    else:
        cota_h(d, 0, 60, -9, -1, '60', dy=16)
        cota_v(d, 55, 60, 52, 59, '5'); d.linea((59, 55), (51, 55), COTA, 0.8)
        d.texto((132, 52), 'Caso 2', B2, 15, 'start', '700'); d.texto((132, 44), 'El plano da dónde está', TINTA, 12.5)
        d.texto((132, 39), 'el centro (X60, 5 mm abajo)', TINTA, 12.5); d.texto((132, 31), 'Falta: dónde corta la línea', ROJO, 12.5, 'start', '700')
        d.texto((132, 26), '→ Pitágoras da I y las X', ROJO, 12.5, 'start', '700')
    d.svg(nombre)
plano('plano_caso1', 1); plano('plano_caso2', 2)
print('dibujos en', os.path.join(AQUI, 'diagramas'))
