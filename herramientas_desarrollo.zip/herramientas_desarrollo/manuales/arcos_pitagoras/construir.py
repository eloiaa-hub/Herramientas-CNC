"""Construye arcos_pitagoras.html (apuntes «Arcos con el centro fuera de la línea») en la carpeta de la suite.
Uso (desde esta carpeta): python3 ../guia_iso/diagramas.py && python3 diagramas.py && python3 construir.py ../../..
(el repaso de los arcos usa los dibujos de los apuntes ISO, de ../guia_iso/diagramas/)
y el PDF: SOLO=arcos_pitagoras node ../../generar_pdf_manuales.js ../../..   (desde la carpeta de la suite: node herramientas_desarrollo/generar_pdf_manuales.js .)"""
import sys, os, re, subprocess
AQUI = os.path.dirname(os.path.abspath(__file__)); D = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else os.path.join(AQUI, '../../..'))
s = open(os.path.join(AQUI, 'fuente_arcos_pitagoras.html'), encoding='utf-8').read()
def svg(m):
    f = os.path.join(AQUI, 'diagramas', m.group(1) + '.svg')
    if not os.path.exists(f): f = os.path.join(AQUI, '..', 'guia_iso', 'diagramas', m.group(1) + '.svg')     # los dibujos de los apuntes ISO (repaso de los arcos)
    t = open(f, encoding='utf-8').read()
    return re.sub(r'style="width:[^"]*"', f'style="width:{m.group(2)}"', t, count=1) if m.group(2) else t
s = re.sub(r'\{\{svg:([a-z0-9_]+)(?:\|([0-9]+%))?\}\}', svg, s)
tmp = os.path.join(AQUI, '_fuente_con_dibujos.html'); open(tmp, 'w', encoding='utf-8').write(s)
try:
    subprocess.run([sys.executable, os.path.join(AQUI, '..', 'anidador_calculadora', 'construir_manual.py'), tmp, AQUI,
                    os.path.join(D, 'arcos_pitagoras.html'), 'Arcos con el centro fuera de la línea — Apuntes para el alumnado', os.path.join(D, 'manual_corrector.html')], check=True)
finally: os.remove(tmp)
