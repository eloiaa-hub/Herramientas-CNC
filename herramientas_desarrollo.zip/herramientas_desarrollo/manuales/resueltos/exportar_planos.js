// Planos (SVG con cotas) de las piezas de los programas resueltos, exportados con el Calcador. Crea también el aro.
// Uso: LANG=C.UTF-8 node exportar_planos.js      (deja piezas/*.svg)
const path = require('path'), fs = require('fs');
const { lanzar, SUITE } = require('../../pruebas/comun.js');
const D = path.join(__dirname, 'piezas');
(async () => {
  const b = await lanzar(); const p = await b.newPage(); const errs = []; p.on('pageerror', e => errs.push(e.message)); p.on('dialog', d => d.accept());
  await p.goto('file://' + path.join(SUITE, 'calcador.html')); await p.evaluate(() => localStorage.clear()); await p.reload(); await p.waitForTimeout(800);
  // el aro: círculo exterior R50 y agujero R20, los dos con centro en X50 Y50 (cada círculo, dos semicírculos)
  const aro = await p.evaluate(() => {
    const c1 = { pts:[{ x:100, y:50 }, { x:0, y:50 }], b:[1, 1], cerrado:true, tipo:'auto', uid:nuevoUid() };
    const c2 = { pts:[{ x:70, y:50 }, { x:30, y:50 }], b:[1, 1], cerrado:true, tipo:'auto', uid:nuevoUid() };
    return datosDeEstado({ contornos:[c1, c2], aux:[] }, { titulo:'Aro' }, 'Aro');
  });
  fs.writeFileSync(path.join(D, 'aro.json'), JSON.stringify(aro, null, 1));
  for (const f of fs.readdirSync(D).filter(f => f.endsWith('.json'))) {
    const d = JSON.parse(fs.readFileSync(path.join(D, f), 'utf8'));
    if (f === 'muesca_a.json') d.calcador.cotasManuales = [];      // con las cotas automáticas (las manuales repetían medidas)
    const svg = await p.evaluate(d => { abrirJSONDatos(d); document.getElementById('chkCotasSVG').checked = true; const o = document.getElementById('chkOrigen'); if (o) o.checked = false;
      cfgCotas.ver = true; return exportarSVG(true, false); }, d);
    fs.writeFileSync(path.join(D, f.replace('.json', '.svg')), svg);
    console.log(f, svg.length);
  }
  console.log('errores', errs); await b.close();
})();
