"""Manuales del Calcador y del Corrector: corrección desde el zip de Aules, informe de entrega y 📝 Cuestionario para Aules.
Uso (después de node capt_entregas.js): python3 manuales_entregas.py <carpeta de la suite>   (se aplica una vez)
"""
import sys, os, io, base64, re
from PIL import Image
D = sys.argv[1] if len(sys.argv) > 1 else '../../..'
CAP = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'capturas')
def img(nombre, ancho=1800):
    im = Image.open(os.path.join(CAP, nombre)).convert('RGB')
    if im.width > ancho: im = im.resize((ancho, round(im.height * ancho / im.width)), Image.LANCZOS)
    b = io.BytesIO(); im.save(b, 'WEBP', quality=82, method=6)
    return 'data:image/webp;base64,' + base64.b64encode(b.getvalue()).decode()

ZIP_TXT = """<p><strong>Directamente desde Aules.</strong> En la tarea de Aules, <em>Ver todos los envíos → Descargar todas las entregas</em> baja un <strong>.zip</strong> con una carpeta por alumno («Apellidos, Nombre_123456_assignsubmission_file_»). Ese zip se añade tal cual con <span class="boton">📂 Añadir programas o zip de Aules…</span> (o arrastrándolo): cada alumno sale del <strong>nombre de su carpeta</strong>, también si la descarga es sin carpetas, si ha pegado el programa en el <strong>texto en línea</strong> o si ha subido un .zip dentro. Los archivos que no son programas (fotos, documentos) no se usan, y un alumno que entrega dos programas sale dos veces («Nombre · a.nc» y «Nombre · b.nc»).</p>
<p><strong>El informe de entrega.</strong> Si la tarea pide el <strong>🧾 informe de entrega</strong> del Simulador (un PDF con el programa, la simulación, la revisión y un código de comprobación), el Corrector lo lee: junto al nombre aparece <strong>🧾</strong> si el informe es válido y el programa entregado es el mismo que el del informe, y <strong>🧾⚠️</strong> si el informe se ha modificado o el programa no coincide (pasa el ratón por encima para ver el motivo). Si el alumno solo ha subido el informe, se corrige el programa que lleva dentro. El estado del informe sale también en el CSV y en su informe impreso.</p>"""
ZIP_FIG_CAP = 'Una clase abierta desde el zip de Aules: 🧾 informe que coincide, 🧾⚠️ informe que no coincide o modificado, y un alumno que entregó dos programas.'
CU_TXT = """<p><span class="boton">📝 Cuestionario para Aules…</span> (panel Exportar) prepara preguntas sobre el ejercicio abierto para un <strong>cuestionario de Aules</strong> que se corrige solo: el alumno escribe los valores y Aules los compara con la solución.</p>
<ul>
<li><strong>Coordenadas absolutas (G90)</strong>, <strong>incrementales (G91)</strong> y <strong>polares</strong> (radio y ángulo) de un punto.</li>
<li><strong>Centro de un arco</strong> (I y J) y su <strong>radio R</strong> con signo.</li>
<li><strong>¿G2 o G3?</strong> de un arco y <strong>¿G41 o G42?</strong> de un contorno, en el sentido de la flecha.</li>
</ul>
<p>Cada pregunta lleva el <strong>plano acotado</strong> con los puntos marcados (P1, P2…), los arcos (A1, A2…), el cero pieza X0 Y0 y el sentido de cada contorno, y sale en varias <strong>variantes</strong> de la pieza (las de 🎲 Variantes para examen: simetrías, giro, otro cero pieza, escala), cada una con su plano y su solución. En la ventana eliges cuántas variantes, la tolerancia y cuántas preguntas de cada tipo; a la derecha se ven las de la variante A con su respuesta y su explicación.</p>
<p><span class="boton">⬇ Descargar el XML de Moodle</span> guarda un archivo .xml. En Aules: <strong>Banco de preguntas → Importar → Formato Moodle XML</strong>. Cada pregunta queda en su propia categoría con sus variantes; en el cuestionario, <strong>Añadir → una pregunta aleatoria</strong> de cada categoría, y cada alumno recibe una variante distinta. Al terminar, cada alumno ve la explicación de su variante.</p>"""
CU_CAP = 'El cuestionario de un ejercicio: ocho preguntas en cuatro variantes, con el plano marcado y la solución de cada una.'

# ── Corrector ──
P = os.path.join(D, 'manual_corrector.html'); s = open(P, encoding='utf-8').read()
assert 'Cuestionario para Aules' not in s, 'el manual del Corrector ya está actualizado'
def rep(a, b, cnt=1):
    global s
    n = s.count(a); assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:90]}'
    s = s.replace(a, b)
rep("<li>Variantes para examen</li><li>⚙️ Mecanizar y Simulador</li><li>Problemas frecuentes</li>", "<li>Variantes para examen</li><li>Cuestionario para Aules</li><li>⚙️ Mecanizar y Simulador</li><li>Problemas frecuentes</li>")
rep("""<li>Pulsa <span class="boton">📂 Añadir programas…</span> y elige todos los archivos a la vez, o arrástralos sobre la ventana. <strong>El nombre de cada archivo es el del alumno</strong> (por ejemplo, <code>Ana García.nc</code>); las tildes y los espacios no son un problema.</li>""",
    """<li>Pulsa <span class="boton">📂 Añadir programas o zip de Aules…</span> y elige todos los archivos a la vez, o arrástralos sobre la ventana. <strong>El nombre de cada archivo es el del alumno</strong> (por ejemplo, <code>Ana García.nc</code>); las tildes y los espacios no son un problema. O, más cómodo, el <strong>zip de Aules</strong> (abajo).</li>""")
rep("""<h3>La nota orientativa</h3>
<p>Los criterios se ajustan en la propia ventana.""", """<h3>El zip de Aules y el informe de entrega</h3>
""" + ZIP_TXT + f"""
<figure><img src="{img('masiva_aules.png')}" style="width:100%"><figcaption>{ZIP_FIG_CAP}</figcaption></figure>
<h3>La nota orientativa</h3>
<p>Los criterios se ajustan en la propia ventana.""")
i = s.index('<span>10</span>Variantes para examen</h2>'); j = s.index('</section>', i) + len('</section>')
s = s[:j] + f"""
<section><h2 class="cap"><span>11</span>Cuestionario para Aules</h2>
<figure><img src="{img('cuestionario_corrector.png')}" style="width:100%"><figcaption>{CU_CAP}</figcaption></figure>
{CU_TXT}
</section>""" + s[j:]
rep('<span>11</span>⚙️ Mecanizar y Simulador</h2>', '<span>12</span>⚙️ Mecanizar y Simulador</h2>')
rep('<span>12</span>Problemas frecuentes</h2>', '<span>13</span>Problemas frecuentes</h2>')
open(P, 'w', encoding='utf-8').write(s); print('manual_corrector.html actualizado')

# ── Calcador ──
P = os.path.join(D, 'manual_calcador.html'); s = open(P, encoding='utf-8').read()
assert 'Cuestionario para Aules' not in s, 'el manual del Calcador ya está actualizado'
rep("""<li>Pulsa <span class="boton">📂 Añadir programas…</span> y elige todos los archivos de la clase a la vez, o <strong>arrástralos</strong> a la ventana. Cada archivo es un alumno: su nombre se toma del nombre del archivo (<code>Laura_Pérez.nc</code> → «Laura Pérez»).""",
    """<li>Pulsa <span class="boton">📂 Añadir programas o zip de Aules…</span> y elige todos los archivos de la clase a la vez, o <strong>arrástralos</strong> a la ventana; o el zip de entregas de Aules (abajo). Cada archivo es un alumno: su nombre se toma del nombre del archivo (<code>Laura_Pérez.nc</code> → «Laura Pérez»).""")
rep("""<p>Pulsando la cabecera de una columna se ordena por ella (otra vez, en orden inverso). Debajo de la tabla, el <strong>resumen de la clase</strong>: en cuántos sale bien la pieza, cuántos cumplen lo pedido, la nota media y los aprobados.</p>""",
    """<p>Pulsando la cabecera de una columna se ordena por ella (otra vez, en orden inverso). Debajo de la tabla, el <strong>resumen de la clase</strong>: en cuántos sale bien la pieza, cuántos cumplen lo pedido, la nota media y los aprobados.</p>
<h3>Las entregas de Aules: el zip y el informe de entrega</h3>
""" + ZIP_TXT + f"""
<figure class="ancha"><img src="{img('masiva_aules.png')}" alt="{ZIP_FIG_CAP}"><figcaption>{ZIP_FIG_CAP}</figcaption></figure>""")
rep("""numeradas 12A, 12B…: para corregir el programa de un alumno, abre su variante.</p>""",
    """numeradas 12A, 12B…: para corregir el programa de un alumno, abre su variante.</p>
<h3>📝 Cuestionario para Aules</h3>
""" + CU_TXT + f"""
<figure class="ancha"><img src="{img('cuestionario_calcador.png')}" alt="{CU_CAP}"><figcaption>{CU_CAP}</figcaption></figure>""")
rep("""<span class="boton">🎲 Variantes para examen…</span> (capítulo 19)""", """<span class="boton">🎲 Variantes para examen…</span> y <span class="boton">📝 Cuestionario para Aules…</span> (capítulo 19)""")
open(P, 'w', encoding='utf-8').write(s); print('manual_calcador.html actualizado')
