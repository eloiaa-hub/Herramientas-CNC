// Guía del Simulador para el alumnado: sus fuentes originales no están, así que se parte del PDF de 17 páginas
// (guia_simulador_base_17p.pdf) y se rehacen las páginas que cambian desde guia_paginas.html: el índice (pág. 2) y,
// desde la 16, «12 El informe de entrega», «13 Corregir el programa en el simulador», «14 Problemas frecuentes» y «15 Antes de entregar».
// Uso: node construir_guia.js <carpeta de la suite>    (antes, las capturas: LANG=C.UTF-8 node capt_informe.js)
const path = require('path'), fs = require('fs'), { execFileSync } = require('child_process');
const { lanzar } = require('../../pruebas/comun.js');
const D = path.resolve(process.argv[2] || '../../..'), AQUI = __dirname, TMP = fs.mkdtempSync(path.join(require('os').tmpdir(), 'guia-'));
const pie = num => `<div style="width:100%;font-size:6.5pt;font-family:'Segoe UI',Arial,sans-serif;color:#555;padding:0 15mm;display:flex;justify-content:space-between"><span>Simulador G-Code · Guía para el alumnado</span><span>${num}</span></div>`;
(async () => {
  let html = fs.readFileSync(path.join(AQUI, 'guia_paginas.html'), 'utf8');
  html = html.replace(/\{\{img:([^}]+)\}\}/g, (_, f) => 'data:image/png;base64,' + fs.readFileSync(path.join(AQUI, 'img', f)).toString('base64'));
  const fh = path.join(TMP, 'guia.html'); fs.writeFileSync(fh, html);
  const b = await lanzar(), partes = {};
  // número de página de cada sección nueva (las del final se numeran seguidas)
  const secciones = [['contenido', 2], ['informe', 16], ['editar', null], ['problemas', null], ['antes', null]];
  let sig = 16;
  for (const [id, n0] of secciones) {
    const p = await b.newPage(); await p.goto('file://' + fh + '#' + id); await p.waitForTimeout(300); await p.emulateMedia({ media: 'print' });
    // primero se mide cuántas páginas ocupa; luego se imprime con su número en el pie
    const pr = path.join(TMP, id + '.pdf'), n = n0 || sig;
    await p.pdf({ path: pr, format: 'A4', printBackground: true, preferCSSPageSize: true, displayHeaderFooter: true, headerTemplate: '<span></span>', footerTemplate: pie(n) });
    const pags = +execFileSync('pdfinfo', [pr]).toString().match(/Pages:\s+(\d+)/)[1];
    if (pags > 1) throw new Error(`la sección «${id}» ocupa ${pags} páginas: acórtala`);
    if (id !== 'contenido') sig = n + 1;
    partes[id] = pr; await p.close();
  }
  await b.close();
  const salida = path.join(D, 'guia_simulador.pdf');
  execFileSync('python3', ['-c', `
import pikepdf, sys
base = pikepdf.open(sys.argv[1]); out = pikepdf.new()
abiertos = []
def nueva(f):
    abiertos.append(pikepdf.open(f)); return abiertos[-1].pages[0]
pags = [base.pages[0], nueva(sys.argv[2])] + [base.pages[i] for i in range(2, 15)] + [nueva(f) for f in sys.argv[3:7]]
for p in pags: out.pages.append(p)
out.docinfo['/Title'] = 'Simulador G-Code — Guía para el alumnado'
out.save(sys.argv[7])
`, path.join(AQUI, 'guia_simulador_base_17p.pdf'), partes.contenido, partes.informe, partes.editar, partes.problemas, partes.antes, salida]);
  try { execFileSync('python3', [path.join(AQUI, '../../aligerar_pdf.py'), salida, salida], { stdio: 'pipe' }); } catch (e) { console.log('(sin aligerar)', String(e.stderr || e.message).slice(-300)); }
  console.log(`guia_simulador.pdf: ${execFileSync('pdfinfo', [salida]).toString().match(/Pages:\s+(\d+)/)[1]} páginas, ${(fs.statSync(salida).size / 1048576).toFixed(1)} MB`);
  fs.rmSync(TMP, { recursive: true, force: true });
})();
