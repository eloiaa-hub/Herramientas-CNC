#!/bin/sh
# Guía del Simulador 3D: fuente_guia.html + capturas de img/ → guia_simulador.html y guia_simulador.pdf (en la carpeta de la suite)
# Antes, las capturas (desde esta carpeta): LANG=C.UTF-8 node capt_guia.js; node capt_editor.js; node capt_informe.js; node capt_explicar.js
set -e
cd "$(dirname "$0")"
S=../../..
python3 ../anidador_calculadora/construir_manual.py fuente_guia.html img $S/guia_simulador.html "Simulador 3D — Guía para el alumnado y el profesorado"
cd $S && SOLO=guia_simulador LANG=C.UTF-8 node herramientas_desarrollo/generar_pdf_manuales.js .
python3 herramientas_desarrollo/aligerar_pdf.py guia_simulador.pdf /tmp/guia_lig.pdf && mv /tmp/guia_lig.pdf guia_simulador.pdf
pdfinfo guia_simulador.pdf | grep Pages
