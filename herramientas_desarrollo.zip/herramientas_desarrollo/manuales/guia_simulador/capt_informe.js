// Capturas de la guía del Simulador: la ventana 🧾 Entrega y la primera página del PDF del informe
// Uso: LANG=C.UTF-8 node capt_informe.js <carpeta de salida>
const path = require('path'), fs = require('fs'), { execFileSync } = require('child_process');
const { lanzar, SUITE } = require('../../pruebas/comun.js');
const OUT = process.argv[2] || path.join(__dirname, 'img'); fs.mkdirSync(OUT, { recursive: true });
const EJ = path.join(__dirname, '../../pruebas/ISO 13 - dos herramientas');
(async () => {
  const b = await lanzar(); const ctx = await b.newContext({ viewport: { width: 1280, height: 800 }, deviceScaleFactor: 2, acceptDownloads: true });
  const pg = await ctx.newPage(); pg.on('dialog', d => d.accept());
  await pg.goto('file://' + path.join(SUITE, 'simulador3d.html')); await pg.evaluate(() => localStorage.clear()); await pg.reload(); await pg.waitForTimeout(800);
  await pg.setInputFiles('#fileInput', EJ + '.json'); await pg.waitForTimeout(400);
  await pg.setInputFiles('#fileInput', EJ + '.nc'); await pg.waitForTimeout(1500);
  await pg.evaluate(() => setModo2D(true)); await pg.waitForTimeout(400);
  await pg.evaluate(() => abrirInforme()); await pg.waitForTimeout(600);
  await pg.evaluate(() => { document.getElementById('infAlumno').value = 'Pérez López, Ana'; document.getElementById('infGrupo').value = '1.º DA'; actualizarInforme(); });
  const caja = await pg.$('#informeVentana'); await caja.screenshot({ path: path.join(OUT, 'informe_ventana.png') });
  const [dl] = await Promise.all([pg.waitForEvent('download'), pg.evaluate(() => descargarInforme())]);
  const pdf = path.join(OUT, 'informe_ejemplo.pdf'); await dl.saveAs(pdf);
  execFileSync('pdftoppm', ['-r', '110', '-f', '1', '-l', '1', '-png', '-singlefile', pdf, path.join(OUT, 'informe_pdf')]);
  // el botón de la cabecera
  await pg.evaluate(() => cerrarInforme());
  const bot = await pg.$('button[onclick="abrirInforme()"]'); const bb = await bot.boundingBox();
  await pg.screenshot({ path: path.join(OUT, 'informe_boton.png'), clip: { x: Math.max(0, bb.x - 260), y: 0, width: 420, height: 52 } });
  await b.close(); console.log('capturas en', OUT);
})();
