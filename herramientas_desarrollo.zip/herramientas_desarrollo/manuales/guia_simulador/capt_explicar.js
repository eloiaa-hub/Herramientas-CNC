// Captura de la guía del Simulador: 💬 explicar la línea y 📍 posición absoluta en G91 (ejercicio 3 de los programas resueltos)
// Uso: LANG=C.UTF-8 node capt_explicar.js
const path = require('path'), fs = require('fs');
const { lanzar, SUITE } = require('../../pruebas/comun.js');
const OUT = path.join(__dirname, 'img'); fs.mkdirSync(OUT, { recursive: true });
(async () => {
  const b = await lanzar(); const ctx = await b.newContext({ viewport: { width: 1280, height: 800 }, deviceScaleFactor: 2 });
  const pg = await ctx.newPage();
  await pg.goto('file://' + path.join(SUITE, 'simulador3d.html')); await pg.evaluate(() => localStorage.clear()); await pg.reload(); await pg.waitForTimeout(800);
  const t = fs.readFileSync(path.join(__dirname, '../resueltos/programas/ejercicio3_G91.nc'), 'utf8');
  await pg.evaluate(t => { cargarGcodeTexto(t, 'ejercicio3_G91.nc'); irALinea(10); document.getElementById('panelCodigo').style.width = '470px'; onResizeViewport(); }, t);
  await pg.waitForTimeout(800);
  const r = await pg.evaluate(() => { const a = document.getElementById('panelCodigo').getBoundingClientRect(); return { x: a.x, y: a.y, width: a.width, height: a.height }; });
  await pg.screenshot({ path: path.join(OUT, 'explicar.png'), clip: r });
  await b.close(); console.log('captura en', OUT);
})();
