// Capturas de la guía del Simulador 3D (alumnado y profesorado)
// Uso: LANG=C.UTF-8 node capt_guia.js        (deja las imágenes en img/)
const path = require('path'), fs = require('fs');
const { lanzar, SUITE } = require('../../pruebas/comun.js');
const { marcar, quitarMarcas } = require('../anidador_calculadora/comun_capt.js');
const OUT = path.join(__dirname, 'img'); fs.mkdirSync(OUT, { recursive: true });
const PR = path.join(__dirname, 'progs');
const EJ = path.join(__dirname, '../../pruebas/ISO 13 - dos herramientas');
const PLANO = path.join(__dirname, '../../pruebas/Prueba01.json');
const esperar = ms => new Promise(r => setTimeout(r, ms));
(async () => {
  const b = await lanzar();
  const ctx = await b.newContext({ viewport: { width: 1280, height: 760 }, deviceScaleFactor: 2 });
  const nueva = async () => { const p = await ctx.newPage(); p.on('dialog', d => d.accept()); p.on('pageerror', e => console.log('ERR', e.message));
    await p.goto('file://' + path.join(SUITE, 'simulador3d.html')); await p.evaluate(() => localStorage.clear()); await p.reload(); await p.waitForTimeout(1200);
    await p.addStyleTag({ content: '#snack { display: none !important; }' }); return p; };
  const shot = (p, n, opt) => p.screenshot(Object.assign({ path: path.join(OUT, n) }, opt || {}));
  const seccion = async (p, h3, n) => { const el = await p.evaluateHandle(t => [...document.querySelectorAll('#panel h3')].find(h => h.textContent.trim() === t).parentElement, h3); await el.screenshot({ path: path.join(OUT, n) }); };
  // (el arranque del husillo, en el orden de la suite: S… M03)
  const prog = (p, f) => p.evaluate(([t, n]) => cargarGcodeTexto(t, n), [fs.readFileSync(f, 'utf8').replace(/M03 S(\d+)/g, 'S$1 M03'), path.basename(f)]);

  // 1. La pantalla, a mitad de la simulación, con las zonas numeradas
  let p = await nueva();
  await p.setInputFiles('#fileInput', EJ + '.json'); await p.waitForTimeout(400);
  await prog(p, EJ + '.nc'); await p.waitForTimeout(1500);
  await p.evaluate(() => { moverHerramientaA(Math.round(puntosPlanos.length * 0.55)); }); await p.waitForTimeout(500);
  await shot(p, 'pantalla_portada.png');
  await marcar(p, [{ n: 1, sel: '#filenameLabel', pos: 'tr', dy: 18 }, { n: 2, sel: '#listaCodigo', pos: 'tr', dy: 300, ox: -10 }, { n: 3, sel: '#panelRevision', pos: 'tr', dy: 22, ox: -40 },
                   { n: 4, sel: '#viewport', pos: 'c', oy: -120 }, { n: 5, sel: '#transport', dx: 330, dy: 18 }, { n: 6, sel: '#panel', dx: 150, dy: 60 }]);
  await shot(p, 'pantalla.png'); await quitarMarcas(p);
  // la barra de reproducción
  const tr = await p.$('#transport'); await tr.screenshot({ path: path.join(OUT, 'transporte.png') });
  // la cabecera
  const hd = await p.$('header'); await hd.screenshot({ path: path.join(OUT, 'cabecera.png') });
  // el panel de posición y programa
  await seccion(p, 'Posición actual', 'posicion.png'); await seccion(p, 'Programa', 'programa.png');
  await p.close();

  // 2. Vista 2D y 3D: vaciado de 5 mm y contorno de 19 mm en tres pasadas
  p = await nueva(); await prog(p, path.join(PR, 'vaciado.nc')); await p.waitForTimeout(800);
  await p.evaluate(() => { document.getElementById('matGrosorAuto').value = 19; leerCfgMaterial(); irAlFinal(); }); await p.waitForTimeout(800);
  await shot(p, 'vista3d.png', { clip: { x: 330, y: 52, width: 690, height: 640 } });
  await p.evaluate(() => ponerVista('alzado')); await p.waitForTimeout(600);
  await shot(p, 'alzado.png', { clip: { x: 330, y: 52, width: 690, height: 640 } });
  await p.evaluate(() => { setModo2D(true); }); await p.waitForTimeout(800);
  await p.evaluate(() => moverHerramientaA(Math.round(puntosPlanos.length * 0.7))); await p.waitForTimeout(500);
  await shot(p, 'vista2d.png', { clip: { x: 330, y: 52, width: 690, height: 640 } });
  await seccion(p, 'Material', 'material.png'); await seccion(p, 'Visualización', 'visualizacion.png');
  await p.close();

  // 3. La revisión: un programa con errores
  p = await nueva(); await p.setViewportSize({ width: 1280, height: 1060 }); await prog(p, path.join(PR, 'errores.nc')); await p.waitForTimeout(800);
  await p.evaluate(() => { document.getElementById('panelRevision').classList.remove('plegado'); irAlFinal(); }); await p.waitForTimeout(600);
  const ac = await p.$('#panelCodigo'); await ac.screenshot({ path: path.join(OUT, 'revision.png') });
  await p.close();

  // 4. La herramienta: la sección y la base
  p = await nueva(); await prog(p, path.join(PR, 'herramienta.nc')); await p.waitForTimeout(800);
  await p.evaluate(() => irAlFinal()); await p.waitForTimeout(500);
  await seccion(p, 'Herramienta', 'herramienta.png');
  await p.evaluate(() => HB.abrir(aplicarHerramientaSim)); await p.waitForTimeout(600);
  const hb = await p.$('.hb-caja'); await hb.screenshot({ path: path.join(OUT, 'base_herramientas.png') });
  await p.close();

  // 5. Los ejemplos de G41 y G42
  p = await nueva();
  for (const [id, n] of [['gcodeEjemploG41', 'ej_g41.png'], ['gcodeEjemploG42', 'ej_g42.png']]) {
    await p.evaluate(id => { cargarEjemplo(id); setModo2D(true); irAlFinal(); }, id); await p.waitForTimeout(900);
    await shot(p, n, { clip: { x: 330, y: 52, width: 690, height: 640 } });
  }
  await p.close();

  // 6. Con el plano del ejercicio: bien y con la compensación cambiada
  const cal = await ctx.newPage(); cal.on('dialog', d => d.accept());
  await cal.goto('file://' + path.join(SUITE, 'calcador.html')); await cal.evaluate(() => localStorage.clear()); await cal.reload(); await cal.waitForTimeout(700);
  await cal.setInputFiles('#fileJSON', PLANO); await cal.waitForTimeout(400); await cal.evaluate(() => abrirMec());
  const nc = await cal.evaluate(() => { cfgMec.comp = 'auto'; cfgMec.coord = 'G90'; cfgMec.estr = 'plano'; pintarCamposMec(); generarMec(); return document.getElementById('mecTexto').value; });
  await cal.close();
  const malo = nc.replace(/G41/g, 'GX').replace(/G42/g, 'G41').replace(/GX/g, 'G42');
  const plano = JSON.parse(fs.readFileSync(PLANO, 'utf8'));
  for (const [t, suf] of [[nc, 'bien'], [malo, 'mal']]) {
    p = await nueva();
    await p.evaluate(([t, plano]) => { cargarGcodeTexto(t, 'pieza.nc'); cargarPlano(plano, 'Prueba01'); setModo2D(true); irAlFinal(); }, [t, plano]); await p.waitForTimeout(1200);
    await shot(p, `plano_${suf}.png`, { clip: { x: 330, y: 52, width: 690, height: 640 } });
    await seccion(p, 'Plano del ejercicio', `panel_plano_${suf}.png`);
    await p.close();
  }

  // 7. Grabar vídeo: el botón
  p = await nueva(); const g = await p.$('#btnGrabar'); const bb = await g.boundingBox();
  await shot(p, 'grabar.png', { clip: { x: Math.max(0, bb.x - 120), y: bb.y - 8, width: bb.width + 140, height: bb.height + 16 } });
  // 📄 nuevo programa
  await p.close();
  await b.close(); console.log('capturas en', OUT);
})();
