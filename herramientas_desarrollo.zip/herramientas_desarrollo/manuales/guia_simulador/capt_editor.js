// Captura de la guía del Simulador: el editor de G-code (✏️ Editar) abierto
// Uso: LANG=C.UTF-8 node capt_editor.js
const path = require('path'), fs = require('fs');
const { lanzar, SUITE } = require('../../pruebas/comun.js');
const OUT = path.join(__dirname, 'img'); fs.mkdirSync(OUT, { recursive: true });
const EJ = path.join(__dirname, '../../pruebas/ISO 13 - dos herramientas');
(async () => {
  const b = await lanzar(); const ctx = await b.newContext({ viewport: { width: 1280, height: 760 }, deviceScaleFactor: 2 });
  const pg = await ctx.newPage(); pg.on('dialog', d => d.accept());
  await pg.goto('file://' + path.join(SUITE, 'simulador3d.html')); await pg.evaluate(() => localStorage.clear()); await pg.reload(); await pg.waitForTimeout(800);
  await pg.setInputFiles('#fileInput', EJ + '.json'); await pg.waitForTimeout(400);
  await pg.setInputFiles('#fileInput', EJ + '.nc'); await pg.waitForTimeout(1500);
  await pg.evaluate(() => { setModo2D(true); toggleEdicionCodigo(); seleccionarLineaEditor && seleccionarLineaEditor(24); });
  await pg.waitForTimeout(600);
  await pg.screenshot({ path: path.join(OUT, 'editor.png') });
  await b.close(); console.log('captura en', OUT);
})();
