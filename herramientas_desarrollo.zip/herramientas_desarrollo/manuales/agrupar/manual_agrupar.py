"""Manual del Calcador: agrupar y mover con las flechas. Uso (tras node capt_agrupar.js): python3 manual_agrupar.py <suite>"""
import sys, os, io, base64
from PIL import Image
D = sys.argv[1] if len(sys.argv) > 1 else '../../..'
P = os.path.join(D, 'manual_calcador.html'); s = open(P, encoding='utf-8').read()
assert 'Agrupar contornos' not in s, 'ya aplicado'
im = Image.open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'capturas', 'grupo.png')).convert('RGB').crop((520, 120, 2100, 1240))
im = im.resize((1500, round(im.height * 1500 / im.width)), Image.LANCZOS); b = io.BytesIO(); im.save(b, 'WEBP', quality=82, method=6)
src = 'data:image/webp;base64,' + base64.b64encode(b.getvalue()).decode()
def rep(a, c):
    global s
    assert s.count(a) == 1, (s.count(a), a[:80]); s = s.replace(a, c)
cap = 'Una pieza agrupada (exterior y agujero), seleccionada con un clic: marco «🔗 grupo» y, en el panel, Agrupar y Desagrupar. A la derecha, su copia, que es un grupo propio.'
rep('<h3>Transformar con asas</h3>', f'''<h3>Agrupar contornos</h3>
<p>Una pieza suele tener varios contornos: el exterior, sus agujeros, sus grabados… Para moverlos siempre juntos, <strong>agrúpalos</strong>: selecciónalos (Mayús + clic o un recuadro) y pulsa <kbd>Ctrl</kbd>+<kbd>G</kbd> o <span class="boton">🔗 Agrupar</span> en el panel.</p>
<ul>
<li>Un <strong>clic en cualquier contorno del grupo</strong> selecciona el grupo entero (se ve un marco discontinuo con «🔗 grupo»). Así se mueve arrastrándolo, se gira, se escala con las asas, se copia, se pega o se borra todo junto. El recuadro de selección también coge el grupo entero.</li>
<li><kbd>Alt</kbd> + clic selecciona <strong>un solo contorno</strong> del grupo, por ejemplo para cambiar su mecanizado o su herramienta. Los vértices se siguen arrastrando uno a uno.</li>
<li><kbd>Ctrl</kbd>+<kbd>Mayús</kbd>+<kbd>G</kbd> o <span class="boton">⛓ Desagrupar</span> deshace el grupo.</li>
<li>Los grupos se guardan en el JSON. Cada copia de un grupo (pegar, matrices, «Hacer copia») es un grupo nuevo, independiente del original.</li>
<li>Un tablero del <strong>Anidador</strong> llega al Calcador con cada pieza agrupada: un clic la selecciona entera.</li>
</ul>
<figure class="ancha"><img src="{src}" alt="{cap}"><figcaption>{cap}</figcaption></figure>
<h3>Mover con las flechas</h3>
<p>Con la herramienta Editar y algo seleccionado, las <strong>flechas</strong> del teclado lo mueven <strong>1 mm</strong>; con <kbd>Mayús</kbd>, 10 mm, y con <kbd>Ctrl</kbd>, 0,1 mm. La barra de estado dice cuánto se ha movido y dónde queda la esquina de la selección. Varias pulsaciones seguidas se deshacen de una vez con <kbd>Ctrl</kbd>+<kbd>Z</kbd>. Sin nada seleccionado, las flechas siguen recorriendo la pieza bloque a bloque; <kbd>Esc</kbd> quita la selección.</p>
<h3>Transformar con asas</h3>''')
rep('<tr><td><kbd>←</kbd> <kbd>→</kbd></td><td>Recorrido de la pieza: bloque a bloque</td><td><kbd>↑</kbd> <kbd>↓</kbd></td><td>Recorrido: reproducir / pausa</td></tr>',
    '<tr><td><kbd>←</kbd> <kbd>→</kbd></td><td>Recorrido de la pieza: bloque a bloque (sin nada seleccionado)</td><td><kbd>↑</kbd> <kbd>↓</kbd></td><td>Recorrido: reproducir / pausa (sin nada seleccionado)</td></tr>')
rep('<tr><td><kbd>Esc</kbd></td><td>Terminar el contorno en curso, cerrar menús, salir de las asas</td></tr>',
    '<tr><td><kbd>Ctrl</kbd>+<kbd>G</kbd> / <kbd>Ctrl</kbd>+<kbd>Mayús</kbd>+<kbd>G</kbd></td><td>Agrupar / desagrupar la selección</td></tr><tr><td><kbd>Alt</kbd> + clic</td><td>Un solo contorno de un grupo</td></tr><tr><td><kbd>←</kbd> <kbd>→</kbd> <kbd>↑</kbd> <kbd>↓</kbd></td><td>Con algo seleccionado: moverlo 1 mm (Mayús: 10 mm; Ctrl: 0,1 mm)</td></tr><tr><td><kbd>Esc</kbd></td><td>Terminar el contorno en curso, cerrar menús, salir de las asas, quitar la selección</td></tr>')
s = s.replace('Calcador de contornos v82 · Por Eloi A.A.', 'Calcador de contornos v83 · Por Eloi A.A.')
open(P, 'w', encoding='utf-8').write(s); print('manual_calcador.html: agrupar y flechas')
