// Captura del manual del Calcador: un grupo seleccionado (marco «🔗 grupo» y panel con Agrupar / Desagrupar)
const path = require('path'), fs = require('fs');
const { lanzar, SUITE } = require('../../pruebas/comun.js');
const OUT = path.join(__dirname, 'capturas'); fs.mkdirSync(OUT, { recursive: true });
(async () => {
  const b = await lanzar(); const ctx = await b.newContext({ viewport: { width: 1400, height: 880 }, deviceScaleFactor: 1.5 }), p = await ctx.newPage(); p.on('dialog', d => d.accept());
  await p.goto('file://' + path.join(SUITE, 'calcador.html')); await p.evaluate(() => localStorage.clear()); await p.reload(); await p.waitForTimeout(700);
  await p.evaluate(d => { abrirJSONDatos(d); setHerramienta('editar'); seleccionarVarios([0, 1], false); agruparSeleccion(); copiarSeleccion(); pegar(true); empujarSeleccion(180, 0); seleccionarUno(0); encuadrar(); refrescar(); },
    JSON.parse(fs.readFileSync(path.join(__dirname, '../../pruebas/ISO 13 - dos herramientas.json'), 'utf8')));
  await p.evaluate(() => { const s = document.getElementById('snackbar'); if (s) s.classList.remove('show'); }); await p.waitForTimeout(600);
  await p.screenshot({ path: path.join(OUT, 'grupo.png') });
  await b.close(); console.log('captura en', OUT);
})();
