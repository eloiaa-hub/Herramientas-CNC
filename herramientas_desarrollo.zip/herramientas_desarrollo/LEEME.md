# Herramientas de desarrollo de la Suite CNC

Esta carpeta no se usa en clase y no hace falta subirla a Aules. Sirve para mantener la suite sin perder trabajo.

## Construir el Corrector

El Corrector es el Calcador en modo visor. Después de cualquier cambio en `calcador.html`:

```
python3 construir_corrector.py ..
```

(el argumento es la carpeta de la suite). Para subir la versión del Corrector, cambia `VERSION_CORRECTOR` dentro del script.

## Fuentes de ⚙️ Mecanizar (`fuentes_mecanizar/`)

Copia de referencia de lo que se integró en el Calcador (v74 y v75). **El Calcador ya lo lleva dentro**: los cambios nuevos se hacen directamente en `calcador.html`.

- `motor_mecanizado.js`: motor de G-code (adaptación fiel del Generador v81 a mm reales).
- `adaptador_calcador.js`: convierte los contornos del Calcador en trazados para el motor.
- `mecanizar_ui.js`: ventana ⚙️ Mecanizar (campos, vista previa, descargar, simulador).
- `caj_bloque.js`, `offset_bloque.js`, `clipper_bloque.js`: cajeras, desbaste/acabado y Clipper 6.4.2 (licencia Boost), sacados del Generador.
- `integrar_mecanizar.py` + `quitar_generador.py` + `multiherramienta.py` + `dxf_texto.py` + `recibir_proyecto.py` + `entregas_aules.py` + `cuestionario_moodle.py` + `dxf_exportar.py` + `orden_corte.py` + `agrupar.py` + `herramientas_cad.py` + `ejercicio_aleatorio.py` + `centros_arcos.py` + `simulador_unico_calc.py` + `calcador_v73_original.html`: rehacen el Calcador actual desde el v73 (la versión resultante está en `VERSION_CALCADOR`) y, al final, el Corrector. Todo seguido, con:

  ```
  sh construir_calcador.sh
  ```

  `quitar_generador.py` quita del Calcador las referencias visibles al Generador (botón, escala y textos). `multiherramienta.py` añade la herramienta por contorno: el campo del panel, el cambio con M06 en el intérprete, la compensación con el radio de cada tramo, la corrección de la herramienta y el cambio en el programa de la tabla de soluciones. `recibir_proyecto.py` recibe el proyecto del Anidador también sin almacén compartido (por mensaje). `dxf_texto.py` lee los textos de los DXF de fondo con sus acentos (UTF-8, página de códigos, `\U+XXXX` y `%%nnn`). `entregas_aules.py` mete `zip_lector.js` (lector de .zip con descompresión propia) y `entregas_comun.js` (SHA-256, código y lectura del informe de entrega) para la corrección masiva desde el zip de Aules. `cuestionario_moodle.py` mete `cuestionario_moodle.js` (📝 Cuestionario para Aules, Moodle XML). `dxf_exportar.py` escribe el DXF como R12 completo (AutoCAD abría vacío el anterior). `orden_corte.py` añade el orden de corte de ⚙️ Mecanizar (interiores primero por defecto, de dentro afuera). `agrupar.py`, los grupos (Ctrl+G) y mover la selección con las flechas. `herramientas_cad.py` (con `herramientas_cad.js`), alinear y repartir, bloquear contornos, recortar (Y) y alargar (H). `ejercicio_aleatorio.py` (con `ejercicio_aleatorio.js`), la ventana 🧩 Ejercicio aleatorio: piezas al azar con las formas del Calcador, con semilla. `centros_arcos.py`, la cruz de cada centro (5 mm) en su propia capa de cotas (E), rojo oscuro y más gruesa, y el contorno de la pieza más grueso que las cotas en el SVG y las hojas. El Generador está retirado: `generador.html` se conserva sin actualizar y solo lo usan las pruebas de referencia.

## Manuales

Las fuentes originales de los manuales no están: se editan directamente `manual_calcador.html` y `manual_corrector.html`, y los PDF se rehacen con

```
node generar_pdf_manuales.js ..
```

(Chromium y Playwright; con Python, pikepdf y Pillow, `aligerar_pdf.py` pasa después las capturas a JPEG y el PDF pesa menos de la mitad; en el del Calcador recalcula las páginas del índice impreso; `SOLO=manual_anidador` imprime solo ese). En `manuales/` están los scripts que quitaron el Generador de los dos manuales (ya aplicados: no se vuelven a ejecutar), y `manuales_m06.py`, que añadió la herramienta por contorno y el M06, `orden_dxf_manuales.py`, el orden de corte y el DXF R12, `agrupar/manual_agrupar.py` (con su captura, `capt_agrupar.js`), los grupos y las flechas, `herramientas_cad/manual_herramientas_cad.py` (con `capt_herramientas_cad.js`), alinear, repartir, bloquear, recortar y alargar, y `ejercicio_aleatorio/manual_generador.py`, `manual_generador_fase2.py` y `manual_generador_fase3.py` (con `capt_generador.js`), el ejercicio aleatorio.

En `manuales/entregas/`, `capt_entregas.js` hace las capturas del zip de Aules y del cuestionario, y `manuales_entregas.py` (ya aplicado) las añadió a los manuales del Calcador y del Corrector.

La **guía del Simulador 3D** se hace desde su fuente, `manuales/guia_simulador/fuente_guia.html`, como los manuales de la Calculadora y el Anidador: primero las capturas (en esa carpeta, `LANG=C.UTF-8 node capt_guia.js`, `node capt_editor.js` y `node capt_informe.js`, que dejan las imágenes en `img/`, que no va en el zip; los programas de ejemplo de las capturas están en `progs/`) y después `sh construir_guia.sh`, que hace `guia_simulador.html` y `guia_simulador.pdf`.

La **biblioteca de inicio** (`biblioteca_inicio/` en la suite) sale de `biblioteca_inicio/construir_biblioteca.js` con el plan de `plan.js`: cada ejercicio es una semilla y una etapa (los parámetros del generador) de su nivel, con la programación pedida. Las semillas se eligieron mirando las hojas de contactos de `candidatos.js` (`LANG=C.UTF-8 node candidatos.js [nivel]`). El script escribe los JSON por niveles, el paquete `Biblioteca_de_inicio.json`, la página `index.html` (`pagina.js`), el `LEEME.md` (copia de `LEEME_biblioteca.md`) y, importándolo en la biblioteca del Calcador, las hojas y las soluciones en PDF; `resumen.csv` lista lo que ha salido. Si cambia el generador, vuelve a mirar los candidatos: un mismo número puede dar otra pieza.

Los **apuntes de códigos ISO** (`apuntes_iso.html` y `.pdf`) tienen sus fuentes en `manuales/guia_iso/`: el texto en `fuente_apuntes_iso.html` (con `{{svg:…}}` para los dibujos y `{{img:…}}` para las capturas), los dibujos en `diagramas.py` (los deja en `diagramas/`), las capturas del Simulador con la pieza ISO 13 en `capt_iso.js` y `construir_apuntes.py`, que lo junta con el estilo de los manuales. Orden: `python3 diagramas.py`, `LANG=C.UTF-8 node capt_iso.js`, `python3 construir_apuntes.py ../../..` y después el PDF con `SOLO=apuntes_iso node generar_pdf_manuales.js ..`. Los programas de ejemplo de los apuntes están comprobados en el Simulador (sin avisos; el del capítulo 9, al 100 % del plano). `enlazar_calcador.py` (ya aplicado) añadió al manual del Calcador la explicación de la estrategia y el enlace a los apuntes.

Los manuales de la **Calculadora** y del **Anidador** sí tienen fuentes, en `manuales/anidador_calculadora/`: el texto en `fuentes/` (con `{{img:captura.png}}` donde va cada imagen), los guiones que hacen las capturas con ejemplos (`capt_calc.js`, `capt_anid.js`; el del Anidador usa ejercicios de la carpeta `EJERCICIOS`) y `construir_manual.py`, que incrusta las capturas en WebP con el estilo del manual del Corrector. Después, el PDF con `generar_pdf_manuales.js`.

## Simuladores

`simulador3d.html` se edita directamente (no se genera): es el único Simulador 3D, con editor, para alumnado y profesorado. `simulador_unico.py` (ya aplicado) lo hizo a partir del antiguo `simulador3d_profesor.html`, que ahora solo lleva a `simulador3d.html`. `simulador_m06.py` (ya aplicado) es el cambio de herramienta con T… M06. `simulador_informe.py` le añade el 🧾 informe de entrega (`fuentes_mecanizar/entregas_comun.js` + `informe_entrega.js`, entre las marcas `// <informe-entrega>`); si ya está, solo actualiza ese código: `python3 simulador_informe.py ..`.

## Anidador

`anidador.html` se edita directamente. `anidador/cantos_coste.py` es el paso de la v6 (`anidador/anidador_v6.html`) a la v7: cantos y coste; `anidador/forma_real.py` (con `forma_real.js`), el de la v7 a la v8: anidado por la forma real. Para rehacerlo: `cp anidador/anidador_v6.html ../anidador.html && python3 anidador/cantos_coste.py .. && python3 anidador/forma_real.py ..`.

## Pruebas automáticas (`pruebas/`)

Requieren Node.js y Playwright con Chromium. Variables opcionales: `SUITE` (carpeta de la suite, por defecto `../..`), `EJERCICIOS` (carpeta con JSON de ejercicios) y `CHROME` (ruta del navegador).

| Prueba | Qué comprueba |
|---|---|
| `arranque.js` | Todos los programas abren sin errores y muestran su versión |
| `regresion_basica.js` | Todos los ejercicios abren y se corrigen en Calcador y Corrector |
| `motor_vs_generador.js` | El motor de Mecanizar da el mismo G-code que el Generador (`referencia_generador.json`, 390 casos). Desde el Calcador v75 los 65 casos con G41/G42 (`comp_oposic`) salen distintos a propósito: entrada y salida de la compensación | Desde el Calcador v85, las configuraciones con estrategia «concordancia» (`pasadas_g91`, `mixto_g91`) salen distintas a propósito: el Generador tenía la concordancia al revés (con M03, concordancia = G41).
| `referencia_generador.js` | Regenera esa referencia con el Generador |
| `comp_simulador.js` | Programas con G41/G42 en el Simulador: la trayectoria compensada corta todo el contorno sin meterse en la pieza (con `Prueba01.json`) |
| `corpus_comp.js` | `comp_simulador.js` sobre todos los ejercicios (quedan avisos esperables: detalles más pequeños que la fresa y huecos que se solapan) |
| `calculadora.js` | Calculadora de taller: resultados con valores conocidos, conversión G90 ↔ G91 (ida y vuelta), guardado, móvil (las cinco pestañas sin salirse) y capturas |
| `anidador.js` | Anidador: sin solapes y dentro del margen, veta, varios tableros, CSV con coma decimal, piezas reales; el tablero se abre en el Calcador y ⚙️ Mecanizar genera el programa; colocar a mano con el ratón (arrastrar, doble clic para girar, asas para la escala, chincheta, pasar a otro tablero por su pestaña o a uno nuevo; los tableros vacíos se quitan), giro y color en la lista; reabrir un tablero guardado (también de versiones anteriores, `anidado_v3_usuario.json`) con las piezas por separado; exportar PNG, SVG y DXF (en el SVG y el DXF se comprueba que cada arco va hacia su lado, y en el DXF el color de cada pieza; el DXF se valida con `validar_dxf.py`, que necesita `pip install ezdxf`) |
| `dxf_texto.js` | Calcador: textos de DXF de fondo con acentos (R12 en Windows-1252 y en UTF-8, DXF 2010, `\U+XXXX`, `%%nnn`); crea los DXF con ezdxf |
| `multiherr.js` | Herramienta por contorno: panel, plano, ⚙️ Mecanizar con M06, corrección de los errores típicos del cambio y nota |
| `sim_m06.js` | Simuladores con T… M06: compensación y corte con el radio de cada herramienta, fresa dibujada y revisión |
| `entregas.js` | 🧾 Informe de entrega de los dos Simuladores (PDF válido, código, plano y revisión) y corrección masiva desde el zip de Aules (en carpetas, sin carpetas, texto en línea, zip dentro, informe que coincide, que no y modificado), también con la descompresión propia. Con `LANG=C.UTF-8` |
| `cuestionario.js` | 📝 Cuestionario: en cada variante de 30 ejercicios, las respuestas (G90, G91, polares, I J, R, G2/G3, G41/G42) coinciden con la geometría, el Cloze está bien escrito y el XML se lee |
| `agrupar.js` | Grupos (Ctrl+G, clic, Alt + clic, arrastrar, pegar y matrices como grupos nuevos, JSON, desagrupar, tablero del Anidador agrupado por piezas) y flechas (1 / 10 / 0,1 mm, deshacer de una vez, sin selección no mueven) |
| `herramientas_cad.js` | Alinear (seis modos, el grupo como una pieza) y repartir; bloquear (ni clic, ni arrastre, ni Ctrl+A, ni flechas; sí desde la lista; JSON); recortar (extremo, trozo central, contorno cerrado, círculo, hasta una auxiliar, con un bloqueado de borde) y alargar (recta, por el principio hasta un círculo auxiliar, arco), teclas Y / H y Esc |
| `simulador_unico.js` | Un solo Simulador 3D: sin «Profesor» y V40, con el editor (editar y aplicar), el enlace antiguo `simulador3d_profesor.html` lleva al nuevo, «➜ Abrir en el Simulador» del Calcador lo abre con el plano y la solución, y la portada tiene una sola ficha |
| `ejercicio_aleatorio.js` | 🧩 Ejercicio aleatorio: 1650 semillas con once configuraciones, también los cuatro niveles (nivel 1 solo rectas horizontales y verticales en la rejilla, nivel 2 sin arcos, nivel 3 con los centros de los arcos enteros) y una comprobación de solapes independiente; la serie en la biblioteca (carpeta, número de orden, semilla, sin tocar el dibujo abierto); el nivel pasa a «Libre» al cambiar algo; y (también con esquinas y lados en arco: salen los cinco tipos, sin cruces y con los arcos cóncavos para la fresa de al menos su diámetro; sin estos parámetros, las piezas de la v86) (tamaño, cotas en múltiplos del paso, interiores dentro con la pared mínima y en el grupo de su pieza, piezas separadas, huecos de más de dos diámetros de fresa), la misma semilla da lo mismo, la ventana, usar, deshacer, Nuevo y el JSON, y ⚙️ Mecanizar de cinco propuestas en el Simulador (todo cortado, sin meterse en la pieza) |
| `orden_dxf.js` | Orden de corte (interiores primero por defecto, elegible, en el programa, el plano, la tabla y el JSON) y DXF del Calcador (un ejercicio y un anidado, en los dos modos) leído por ezdxf sin recuperar: R12, sin errores y con la misma longitud que los contornos |
| `forma_real.js` | Anidador por la forma real: anillos y discos y ejercicios del Calcador sin solapes ni separaciones menores que la de la fresa (geometría exacta), dentro del margen, los discos en los huecos, mejor que por rectángulos, veta, colocar a mano dentro de un hueco, arrastrar (en rojo si choca), guardar y reabrir, y en el Calcador el corte de dentro afuera |
| `cantos_coste.js` | Anidador: cantos desde el CSV (por título, números y letras), clic en la lista, dibujo con la pieza girada, metros de canto, superficie, tiempo y coste, guardar y reabrir, CSV y móvil |
| `mecanizar_ui.js` | La ventana ⚙️ Mecanizar: herramienta, opciones, guardado, descarga y simulador |
| `interp_corpus.js`, `interp_cmp.js` | Intérprete ISO de los simuladores frente al corpus de programas |
| `estres_mecanizar.js`, `perfil_*.js`, `mec_vista.js` | Casos extremos y medidas de tiempo |

Ejemplo: `cd pruebas && node arranque.js`
