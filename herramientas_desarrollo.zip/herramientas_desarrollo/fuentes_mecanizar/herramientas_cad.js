// ════════════════════════════════════════════════
//  ALINEAR Y REPARTIR · BLOQUEAR · RECORTAR Y ALARGAR
// ════════════════════════════════════════════════
// Unidades de la selección: cada grupo, cada texto y cada contorno suelto cuentan como una pieza
function unidadesSel(ids) {
    const out = [], visto = new Set();
    ids.forEach(i => { if (visto.has(i)) return; const c = contornos[i];
        const u = ids.filter(j => { const d = contornos[j]; return j === i || (c.grupo && d.grupo === c.grupo) || (c.texto && d.texto && d.texto.id === c.texto.id); });
        u.forEach(j => visto.add(j)); out.push(u); });
    return out;
}
function desplazarIds(ids, d) {
    ids.forEach(i => { const c = contornos[i]; c.pts = c.pts.map(q => add(q, d));
        if (c.mec && c.mec.puentes && Array.isArray(c.mec.puentes.pts)) c.mec.puentes.pts = c.mec.puentes.pts.map(q => add(q, d));
        if (c.texto && c.texto.receta && c.texto.receta.pos) c.texto.receta.pos = add(c.texto.receta.pos, d); });
}
// modo: izq, centroX, der, abajo, centroY, arriba (respecto al conjunto de la selección)
function alinearSeleccion(modo) {
    const ids = seleccionados(), us = unidadesSel(ids);
    if (us.length < 2) { snack('Selecciona dos o más piezas (o grupos) para alinearlas'); return; }
    guardarUndo();
    const B = bboxSeleccion(ids);
    us.forEach(u => { const b = bboxSeleccion(u), d = { x:0, y:0 };
        if (modo === 'izq') d.x = B.x0 - b.x0; else if (modo === 'der') d.x = B.x1 - b.x1; else if (modo === 'centroX') d.x = (B.x0 + B.x1) / 2 - (b.x0 + b.x1) / 2;
        else if (modo === 'abajo') d.y = B.y0 - b.y0; else if (modo === 'arriba') d.y = B.y1 - b.y1; else if (modo === 'centroY') d.y = (B.y0 + B.y1) / 2 - (b.y0 + b.y1) / 2;
        desplazarIds(u, d); });
    refrescar();
    snack({ izq:'Alineadas a la izquierda', der:'Alineadas a la derecha', centroX:'Centradas en vertical (mismo centro en X)', abajo:'Alineadas abajo', arriba:'Alineadas arriba', centroY:'Centradas en horizontal (mismo centro en Y)' }[modo] + ` (${us.length} piezas)`);
}
// Repartir: la misma separación entre piezas, entre la primera y la última (eje 'x' o 'y')
function repartirSeleccion(eje) {
    const ids = seleccionados(), us = unidadesSel(ids);
    if (us.length < 3) { snack('Selecciona tres o más piezas (o grupos) para repartirlas'); return; }
    guardarUndo();
    const k0 = eje === 'x' ? 'x0' : 'y0', k1 = eje === 'x' ? 'x1' : 'y1';
    const it = us.map(u => ({ u, b:bboxSeleccion(u) })).sort((a, b) => (a.b[k0] + a.b[k1]) - (b.b[k0] + b.b[k1]));
    const ini = it[0].b[k0], fin = it[it.length - 1].b[k1], suma = it.reduce((s, o) => s + o.b[k1] - o.b[k0], 0);
    const hueco = (fin - ini - suma) / (it.length - 1);
    let pos = ini;
    it.forEach(o => { const d = o.b[k0] - pos; if (Math.abs(d) > 1e-12) desplazarIds(o.u, eje === 'x' ? { x:-d, y:0 } : { x:0, y:-d }); pos += o.b[k1] - o.b[k0] + hueco; });
    refrescar();
    snack(`${it.length} piezas repartidas en ${eje === 'x' ? 'horizontal' : 'vertical'}: ${fmt(hueco, 3)} mm entre una y otra${hueco < 0 ? ' (negativo: se solapan; sepáralas más antes)' : ''}`);
}
// ── Bloquear: un contorno bloqueado no se coge en el dibujo (ni con clic, ni con recuadro, ni con Ctrl+A); sí desde la lista
const bloqueado = i => !!(contornos[i] && contornos[i].bloqueado);
function bloquearSeleccion(si) {
    const ids = seleccionados(); if (!ids.length) return;
    guardarUndo();
    ids.forEach(i => { if (si) contornos[i].bloqueado = true; else delete contornos[i].bloqueado; });
    if (si) seleccionarUno(-1);
    refrescar();
    snack(si ? `${ids.length} contorno(s) bloqueado(s): ya no se cogen en el dibujo (los imanes sí los ven). Para desbloquear, selecciónalos en la lista de contornos` : `${ids.length} contorno(s) desbloqueado(s)`);
}
function desbloquearTodo() {
    const n = contornos.filter(c => c.bloqueado).length; if (!n) return;
    guardarUndo(); contornos.forEach(c => delete c.bloqueado); refrescar(); snack(`${n} contorno(s) desbloqueado(s)`);
}

// ── Geometría para recortar y alargar ──
const EPS_RA = 1e-7;
function geoTramo(t) { if (!t.b) return { L:true, p1:t.p1, p2:t.p2 }; const a = arcoDeBulge(t.p1, t.p2, t.b); return a ? { L:false, c:a.c, r:a.r, a1:a.a1, th:a.theta, p1:t.p1, p2:t.p2 } : { L:true, p1:t.p1, p2:t.p2 }; }
const largoTramo = g => g.L ? dist(g.p1, g.p2) : g.r * Math.abs(g.th);
// fracción (0..1) del punto P (que está sobre el soporte) dentro del tramo; null si cae fuera
function fraccionEn(g, P, tol) {
    tol = tol || 1e-6;
    if (g.L) { const v = sub(g.p2, g.p1), L2 = dot(v, v); if (L2 < 1e-18) return null; const t = dot(sub(P, g.p1), v) / L2, L = Math.sqrt(L2); return t >= -tol / L && t <= 1 + tol / L ? Math.max(0, Math.min(1, t)) : null; }
    const ang = Math.atan2(P.y - g.c.y, P.x - g.c.x) - g.a1, u = g.th > 0 ? wrap(ang) : wrap(-ang), T = Math.abs(g.th), tu = tol / g.r;
    if (u <= T + tu) return Math.min(1, u / T);
    if (u >= TAU - tu) return 0;
    return null;
}
// cortes entre dos soportes: recta (p, d) o circunferencia (c, r)
function cortesSoportes(A, B) {
    const out = [];
    if (A.recta && B.recta) {
        const den = cross(A.d, B.d); if (Math.abs(den) < 1e-12) return out;
        const s = cross(sub(B.p, A.p), B.d) / den; out.push(add(A.p, mulv(A.d, s))); return out;
    }
    if (A.recta || B.recta) {
        const R = A.recta ? A : B, C = A.recta ? B : A, f = sub(R.p, C.c), a = dot(R.d, R.d), b = 2 * dot(f, R.d), cc = dot(f, f) - C.r * C.r, disc = b * b - 4 * a * cc;
        if (disc < -1e-9) return out;
        const sq = Math.sqrt(Math.max(0, disc));
        [(-b - sq) / (2 * a), (-b + sq) / (2 * a)].forEach((s, k) => { if (k && sq < 1e-12) return; out.push(add(R.p, mulv(R.d, s))); });
        return out;
    }
    const d = dist(A.c, B.c); if (d < 1e-12 || d > A.r + B.r + 1e-9 || d < Math.abs(A.r - B.r) - 1e-9) return out;
    const a = (A.r * A.r - B.r * B.r + d * d) / (2 * d), h = Math.sqrt(Math.max(0, A.r * A.r - a * a)), u = mulv(sub(B.c, A.c), 1 / d), m = add(A.c, mulv(u, a)), n = { x:-u.y, y:u.x };
    out.push(add(m, mulv(n, h))); if (h > 1e-9) out.push(add(m, mulv(n, -h)));
    return out;
}
const soporteDe = g => g.L ? { recta:true, p:g.p1, d:sub(g.p2, g.p1) } : { recta:false, c:g.c, r:g.r };
// Los bordes que cortan: los tramos de los demás contornos (y los de este, si se pide) y las líneas y círculos auxiliares
function bordesDeCorte(ci, conPropios, tramoExcluido) {
    const B = [];
    contornos.forEach((c, j) => { if (c.pts.length < 2 || (j === ci && !conPropios)) return;
        tramos(c).forEach((t, k) => { if (j === ci && k === tramoExcluido) return; const g = geoTramo(t); if (largoTramo(g) > 1e-9) B.push({ g, sop:soporteDe(g), ci:j, k }); }); });
    aux.forEach(e => { if (e.t === 'L') B.push({ g:null, sop:{ recta:true, p:e.p, d:e.d } }); else if (e.t === 'C') B.push({ g:null, sop:{ recta:false, c:e.c, r:e.r } }); });
    return B;
}
// Puntos donde el tramo g corta a los bordes (sobre el tramo y sobre el borde)
function cortesDeTramo(g, bordes) {
    const out = [], S = soporteDe(g);
    bordes.forEach(b => cortesSoportes(S, b.sop).forEach(P => { if (fraccionEn(g, P) === null) return; if (b.g && fraccionEn(b.g, P) === null) return; out.push(P); }));
    return out;
}
// Recorrido de un contorno por su longitud: s de un punto (tramo k, fracción f)
function largosContorno(c) { const gs = tramos(c).map(geoTramo), acc = [0]; gs.forEach(g => acc.push(acc[acc.length - 1] + largoTramo(g))); return { gs, acc, L:acc[acc.length - 1] }; }

// ── Recortar: quita el trozo del contorno entre los dos cortes (con otros contornos o auxiliares) más cercanos al clic ──
function calcularRecorte(q) {
    const pc = puntoDeCorteRA(q); if (!pc) return null;
    const c = contornos[pc.ci]; if (c.texto || c.deTexto) return { ci:pc.ci, error:'Los trazos de un texto no se recortan (conviértelo antes en trazos)' };
    const { gs, acc, L } = largosContorno(c), bordes = bordesDeCorte(pc.ci, true);
    const sClic = acc[pc.si] + fraccionEn(gs[pc.si], pc.p, 1e-3) * largoTramo(gs[pc.si]);
    const ss = [];
    gs.forEach((g, k) => { const propios = bordes.filter(b => !(b.ci === pc.ci && (b.k === k || Math.abs(b.k - k) === 1 || (c.cerrado && Math.abs(b.k - k) === gs.length - 1))));
        cortesDeTramo(g, propios).forEach(P => { let s = acc[k] + fraccionEn(g, P) * largoTramo(g); if (c.cerrado && s > L - 1e-6) s = 0; if (!ss.some(x => Math.abs(x.s - s) < 1e-6)) ss.push({ s, P }); }); });
    const tolS = 1e-6;
    if (c.cerrado) {
        const cand = ss;
        if (cand.length < 2) return { ci:pc.ci, error:'Este contorno no cruza nada en dos puntos: no hay trozo que recortar' };
        const sig = cand.filter(x => x.s > sClic + tolS).sort((a, b) => a.s - b.s)[0] || cand.slice().sort((a, b) => a.s - b.s)[0];
        const ant = cand.filter(x => x.s < sClic - tolS).sort((a, b) => b.s - a.s)[0] || cand.slice().sort((a, b) => b.s - a.s)[0];
        if (!sig || !ant || Math.abs(sig.s - ant.s) < tolS) return { ci:pc.ci, error:'Este contorno no cruza nada en dos puntos: no hay trozo que recortar' };
        return { ci:pc.ci, cerrado:true, ant, sig, sClic, L, p:pc.p };
    }
    const ant = ss.filter(x => x.s < sClic - tolS && x.s > tolS).sort((a, b) => b.s - a.s)[0] || null;
    const sig = ss.filter(x => x.s > sClic + tolS && x.s < L - tolS).sort((a, b) => a.s - b.s)[0] || null;
    if (!ant && !sig) return { ci:pc.ci, error:'Este trazo no cruza ningún otro contorno ni auxiliar: no hay dónde recortarlo (bórralo si sobra)' };
    return { ci:pc.ci, cerrado:false, ant, sig, sClic, L, p:pc.p };
}
// contorno y punto más cercanos al cursor (también en los extremos)
function puntoDeCorteRA(q) {
    const tol = 12 / view.z; let mejor = null;
    contornos.forEach((c, ci) => { if (c.pts.length < 2 || bloqueado(ci)) return;
        tramos(c).forEach((t, si) => { const g = geoTramo(t); const p = g.L ? cercanoEnSegRecta(q, t.p1, t.p2) : cercanoEnArco(q, g.c, g.r, g.a1, g.th);
            const d = dist(p, q); if (d <= tol && (!mejor || d < mejor.d - 1e-9)) mejor = { ci, si, p, d }; }); });
    return mejor;
}
// muestras del trozo de contorno entre s0 y s1 (para dibujar lo que se quitará)
function muestrasEntre(c, s0, s1) {
    const { gs, acc } = largosContorno(c), out = [];
    gs.forEach((g, k) => { const a = Math.max(s0, acc[k]), b = Math.min(s1, acc[k + 1]); if (b <= a) return; const L = largoTramo(g), n = g.L ? 1 : Math.max(2, Math.ceil(Math.abs(g.th) * 36 / Math.PI * (b - a) / L));
        for (let i = 0; i <= n; i++) { const f = ((a + (b - a) * i / n) - acc[k]) / L; out.push(g.L ? add(g.p1, mulv(sub(g.p2, g.p1), f)) : add(g.c, { x:g.r * Math.cos(g.a1 + g.th * f), y:g.r * Math.sin(g.a1 + g.th * f) })); } });
    return out;
}
function trozoRecorte(r) {
    const c = contornos[r.ci];
    if (!r.cerrado) return muestrasEntre(c, r.ant ? r.ant.s : 0, r.sig ? r.sig.s : r.L);
    if (r.ant.s < r.sig.s) return muestrasEntre(c, r.ant.s, r.sig.s);
    return muestrasEntre(c, r.ant.s, r.L).concat(muestrasEntre(c, 0, r.sig.s));
}
// corta el contorno ci en el punto P (sin deshacer propio ni avisos); devuelve si ha cortado
function cortarSilencioso(ci, P) {
    const c = contornos[ci]; let mejor = null;
    tramos(c).forEach((t, si) => { const g = geoTramo(t), p = g.L ? cercanoEnSegRecta(P, t.p1, t.p2) : cercanoEnArco(P, g.c, g.r, g.a1, g.th), d = dist(p, P); if (!mejor || d < mejor.d) mejor = { si, d }; });
    if (!mejor) return false;
    if (!c.cerrado && (dist(P, c.pts[0]) < 1e-6 || dist(P, c.pts[c.pts.length - 1]) < 1e-6)) return false;
    const gU = guardarUndo, sn = snack;
    try { guardarUndo = () => {}; snack = () => {}; return cortarEn(ci, mejor.si, P); } finally { guardarUndo = gU; snack = sn; }
}
function recortarEn(q) {
    const r = calcularRecorte(q);
    if (!r) { snack('Acerca el cursor al trozo de contorno que quieras quitar'); return; }
    if (r.error) { snack(r.error); return; }
    if (textoBloqueado(r.ci)) return;
    guardarUndo();
    const n0 = contornos.length;
    // abrir/partir por el corte siguiente y después por el anterior; el trozo que contiene el clic, fuera
    if (r.sig) cortarSilencioso(r.ci, r.sig.P);
    const cand = () => contornos.map((c, i) => i).filter(i => i >= r.ci && i <= r.ci + (contornos.length - n0));
    if (r.ant) { const i = cand().map(i => ({ i, d:distAContorno(r.p, contornos[i]) })).filter(o => distAContorno(r.ant.P, contornos[o.i]) < 1e-5).sort((a, b) => a.d - b.d)[0]; if (i) cortarSilencioso(i.i, r.ant.P); }
    const piezas = cand();
    const quitar = piezas.map(i => ({ i, d:distAContorno(r.p, contornos[i]) })).sort((a, b) => a.d - b.d)[0];
    if (!quitar || quitar.d > 1e-4) { deshacer(); snack('No se ha podido recortar ese trozo'); return; }
    contornos.splice(quitar.i, 1);
    seleccionarUno(-1); refrescar();
    snack('Trozo recortado · sigue haciendo clic en los trozos que sobren · Esc: terminar');
}
function distAContorno(p, c) {
    let d = Infinity; tramos(c).forEach(t => { const g = geoTramo(t), q = g.L ? cercanoEnSegRecta(p, t.p1, t.p2) : cercanoEnArco(p, g.c, g.r, g.a1, g.th); d = Math.min(d, dist(p, q)); }); return d;
}

// ── Alargar: el extremo de un trazo abierto más cercano al clic se prolonga (recta o arco) hasta el primer contorno o auxiliar ──
function calcularAlargue(q) {
    const tol = 14 / view.z; let mejor = null;
    contornos.forEach((c, ci) => { if (c.cerrado || c.pts.length < 2 || c.texto || bloqueado(ci)) return;
        const ts = tramos(c);
        [[0, 'ini'], [ts.length - 1, 'fin']].forEach(([k, lado]) => { const t = ts[k], g = geoTramo(t), p = g.L ? cercanoEnSegRecta(q, t.p1, t.p2) : cercanoEnArco(q, g.c, g.r, g.a1, g.th), d = dist(p, q);
            if (d > tol) return; const E = lado === 'fin' ? t.p2 : t.p1, dE = dist(q, E);
            if (!mejor || d < mejor.d - 1e-9 || (Math.abs(d - mejor.d) < 1e-9 && dE < mejor.dE)) mejor = { ci, k, lado, g, d, dE }; });
        if (ts.length === 1 && mejor && mejor.ci === ci) { const t = ts[0]; mejor.lado = dist(q, t.p2) < dist(q, t.p1) ? 'fin' : 'ini'; }
    });
    if (!mejor) return null;
    const c = contornos[mejor.ci], g = mejor.g, bordes = bordesDeCorte(mejor.ci, true, mejor.k);
    const E = mejor.lado === 'fin' ? g.p2 : g.p1;
    let hit = null;
    if (g.L) {
        const d = norm(mejor.lado === 'fin' ? sub(g.p2, g.p1) : sub(g.p1, g.p2)), R = { recta:true, p:E, d };
        bordes.forEach(b => cortesSoportes(R, b.sop).forEach(P => { const s = dot(sub(P, E), d); if (s <= 1e-6) return; if (b.g && fraccionEn(b.g, P) === null) return; if (!hit || s < hit.s) hit = { s, P }; }));
        if (!hit) return { ci:mejor.ci, error:'Esa recta, prolongada, no llega a ningún contorno ni auxiliar' };
        return { ci:mejor.ci, k:mejor.k, lado:mejor.lado, L:true, E, P:hit.P, largo:hit.s };
    }
    const sg = Math.sign(g.th), C = { recta:false, c:g.c, r:g.r }, angE = Math.atan2(E.y - g.c.y, E.x - g.c.x), libre = TAU - Math.abs(g.th);
    bordes.forEach(b => cortesSoportes(C, b.sop).forEach(P => { if (b.g && fraccionEn(b.g, P) === null) return;
        const aP = Math.atan2(P.y - g.c.y, P.x - g.c.x), adv = mejor.lado === 'fin' ? wrap(sg * (aP - angE)) : wrap(-sg * (aP - angE));
        if (adv <= 1e-7 || adv >= libre - 1e-7) return; if (!hit || adv < hit.adv) hit = { adv, P }; }));
    if (!hit) return { ci:mejor.ci, error:'Ese arco, prolongado, no llega a ningún contorno ni auxiliar' };
    return { ci:mejor.ci, k:mejor.k, lado:mejor.lado, L:false, E, P:hit.P, g, adv:hit.adv, largo:hit.adv * g.r };
}
function alargarEn(q) {
    const r = calcularAlargue(q);
    if (!r) { snack('Acerca el cursor al extremo de un trazo abierto (recta o arco)'); return; }
    if (r.error) { snack(r.error); return; }
    guardarUndo();
    const c = contornos[r.ci], n = c.pts.length;
    if (r.L) { if (r.lado === 'fin') c.pts[n - 1] = { ...r.P }; else c.pts[0] = { ...r.P }; }
    else { const th = r.g.th + Math.sign(r.g.th) * r.adv; c.b[r.k] = Math.tan(th / 4); if (r.lado === 'fin') c.pts[n - 1] = { ...r.P }; else c.pts[0] = { ...r.P }; }
    delete c.forma;
    refrescar();
    snack(`Alargado ${fmt(r.largo, 3)} mm hasta X${fmt(r.P.x, 3)} Y${fmt(r.P.y, 3)} · sigue con otros extremos · Esc: terminar`);
}
// vista previa de recortar y alargar
function dibujarPreviaRA(q) {
    ctx.save(); ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    const linea = (pts, col, w, disc) => { ctx.strokeStyle = col; ctx.lineWidth = w; ctx.lineCap = 'round'; ctx.setLineDash(disc ? [7, 5] : []); ctx.beginPath(); pts.forEach((p, i) => { const s = aPantalla(p); if (i) ctx.lineTo(s.x, s.y); else ctx.moveTo(s.x, s.y); }); ctx.stroke(); };
    const rotulo = (p, t, col) => { const s = aPantalla(p); ctx.setLineDash([]); ctx.fillStyle = col; ctx.font = '12px Segoe UI, Arial'; ctx.fillText(t, s.x + 12, s.y - 10); };
    if (herramienta === 'recortar') {
        const r = calcularRecorte(q);
        if (r && !r.error) { linea(trozoRecorte(r), 'rgba(224,54,140,.7)', 6, false); [r.ant, r.sig].forEach(x => { if (!x) return; const s = aPantalla(x.P); ctx.setLineDash([]); ctx.strokeStyle = '#e0368c'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(s.x, s.y, 5, 0, TAU); ctx.stroke(); }); rotulo(q, '✂ quitar este trozo', '#e0368c'); }
        else if (r && r.error) rotulo(q, '⚠ ' + r.error.split(':')[0], '#c0392b');
    } else if (herramienta === 'alargar') {
        const r = calcularAlargue(q);
        if (r && !r.error) {
            let pts; if (r.L) pts = [r.E, r.P]; else { const a0 = Math.atan2(r.E.y - r.g.c.y, r.E.x - r.g.c.x), sg = Math.sign(r.g.th) * (r.lado === 'fin' ? 1 : -1), n = Math.max(4, Math.ceil(r.adv * 18 / Math.PI)); pts = []; for (let i = 0; i <= n; i++) { const a = a0 + sg * r.adv * i / n; pts.push(add(r.g.c, { x:r.g.r * Math.cos(a), y:r.g.r * Math.sin(a) })); } }
            linea(pts, '#16a085', 2.5, true); const s = aPantalla(r.P); ctx.setLineDash([]); ctx.strokeStyle = '#16a085'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(s.x, s.y, 5, 0, TAU); ctx.stroke();
            rotulo(r.P, `↦ +${fmt(r.largo, 2)} mm`, '#16a085');
        } else if (r && r.error) rotulo(q, '⚠ ' + r.error, '#c0392b');
    }
    ctx.restore();
}
