// ════════════════════════════════════════════════
//  🧩 EJERCICIO ALEATORIO
//  Piezas hechas con las formas del Calcador (rectángulo, polígono, estrella, círculo, coliso) y sus
//  interiores, dentro de un tamaño máximo, con cotas en múltiplos de un paso y sitio para la fresa.
//  Cada ejercicio sale de una semilla: la misma semilla con los mismos parámetros da la misma pieza.
// ════════════════════════════════════════════════
const GEN_FORMAS = { rectangulo:'Rectángulo', escalonada:'Escalonada', poligono:'Polígono', estrella:'Estrella', circulo:'Círculo', ranura:'Coliso' };
const GEN_FORMAS_INT = Object.fromEntries(Object.entries(GEN_FORMAS).filter(([k]) => k !== 'escalonada'));
const GEN_CFG0 = { nivel:'libre', serieN:25, ancho:250, alto:200, ocupar:60, pMin:1, pMax:1, ext:['rectangulo', 'escalonada', 'poligono', 'circulo', 'ranura'], iMin:1, iMax:3,
                   int:['circulo', 'rectangulo', 'ranura'], paso:5, girar:false, fresa:6, pared:6,
                   pEsq:30, esq:['r', 'c', 'ch'], pLado:15, lado:['fuera', 'dentro'], modInt:true };
const GEN_ESQ = { r:'Redondeada', c:'Hacia dentro', ch:'Chaflán' }, GEN_LADO = { fuera:'Arco abombado', dentro:'Arco hundido' };
let cfgGen = JSON.parse(JSON.stringify(GEN_CFG0));
try { const g = JSON.parse(localStorage.getItem('calcador_generador') || 'null'); if (g && typeof g === 'object') cfgGen = Object.assign(cfgGen, g); } catch (e) {}
let genUltimo = null;          // { semilla, cfg } del ejercicio generado que está abierto (viaja en el JSON)
let genBase = 0;               // primera semilla de las propuestas que se ven
function genAleatorio(semilla) {   // mulberry32
    let a = semilla >>> 0;
    const r = () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
    r.entre = (lo, hi) => lo + (hi - lo) * r();
    r.entero = (lo, hi) => lo + Math.floor(r() * (hi - lo + 1));
    r.uno = l => l[Math.floor(r() * l.length)];
    return r;
}
// ── Geometría para las comprobaciones (sobre los contornos muestreados) ──
function genDistSegPunto(p, a, b) {
    const v = sub(b, a), L2 = dot(v, v); let t = L2 > 1e-18 ? dot(sub(p, a), v) / L2 : 0; t = Math.max(0, Math.min(1, t));
    return dist(p, add(a, mulv(v, t)));
}
// Distancia entre dos contornos cerrados (muestreados): 0 si sus bordes se cruzan
function genDistPoligonos(A, B) {
    let m = Infinity;
    const o = (p, q, r) => (q.x - p.x) * (r.y - p.y) - (q.y - p.y) * (r.x - p.x);
    for (let i = 0; i < A.length; i++) {
        const a1 = A[i], a2 = A[(i + 1) % A.length];
        const ax0 = Math.min(a1.x, a2.x), ax1 = Math.max(a1.x, a2.x), ay0 = Math.min(a1.y, a2.y), ay1 = Math.max(a1.y, a2.y);
        for (let j = 0; j < B.length; j++) {
            const b1 = B[j], b2 = B[(j + 1) % B.length];
            if (Math.max(b1.x, b2.x) >= ax0 && Math.min(b1.x, b2.x) <= ax1 && Math.max(b1.y, b2.y) >= ay0 && Math.min(b1.y, b2.y) <= ay1) {
                const d1 = o(b1, b2, a1), d2 = o(b1, b2, a2), d3 = o(a1, a2, b1), d4 = o(a1, a2, b2);
                if (((d1 > 0) !== (d2 > 0) || !d1 || !d2) && ((d3 > 0) !== (d4 > 0) || !d3 || !d4)) return 0;
            }
            const d = Math.min(genDistSegPunto(a1, b1, b2), genDistSegPunto(a2, b1, b2), genDistSegPunto(b1, a1, a2), genDistSegPunto(b2, a1, a2));
            if (d < m) m = d;
        }
    }
    return m;
}
function genMuestras(c) { const m = muestrearContorno(c); return m.length > 2 && dist(m[0], m[m.length - 1]) < 1e-9 ? m.slice(0, -1) : m; }
// Contorno de una receta, desplazado
// La forma escalonada: un rectángulo con muescas rectangulares en algunas esquinas y quizá una ranura en un lado
// (piezas en L, en T, en U…). No es una forma del Calcador: queda como contorno normal (formaGen solo la usa el generador).
function genEscalonada(f) {
    const { W, H } = f, m = f.muescas, P = [], add2 = (x, y) => P.push({ x:f.c.x + x, y:f.c.y + y });
    const [bl, br, tr, tl] = m, rb = f.ranuras.abajo, rt = f.ranuras.arriba;
    add2(bl ? bl.a : 0, 0);
    if (rb) { add2(rb.x, 0); add2(rb.x, rb.t); add2(rb.x + rb.s, rb.t); add2(rb.x + rb.s, 0); }
    if (br) { add2(W - br.a, 0); add2(W - br.a, br.b); add2(W, br.b); } else add2(W, 0);
    if (tr) { add2(W, H - tr.b); add2(W - tr.a, H - tr.b); add2(W - tr.a, H); } else add2(W, H);
    if (rt) { add2(rt.x + rt.s, H); add2(rt.x + rt.s, H - rt.t); add2(rt.x, H - rt.t); add2(rt.x, H); }
    if (tl) { add2(tl.a, H); add2(tl.a, H - tl.b); add2(0, H - tl.b); } else add2(0, H);
    if (bl) { add2(0, bl.b); add2(bl.a, bl.b); } else if (P.length && (P[0].x !== f.c.x || P[0].y !== f.c.y)) add2(0, 0);
    // sin puntos repetidos
    const Q = P.filter((p, i) => dist(p, P[(i + 1) % P.length]) > 1e-9);
    return { pts:Q, b:new Array(Q.length).fill(0), cerrado:true, tipo:'auto' };
}
const genGenerar = f => f.tipo === 'escalonada' ? genEscalonada(f) : generarForma(f);
function genContorno(f) { const c = genGenerar(f); if (f.tipo === 'escalonada') c.formaGen = f; else c.forma = f; c.tipo = 'auto'; return c; }
function genMover(f, d) { const n = JSON.parse(JSON.stringify(f)); n.c = add(n.c, d); return n; }
// ── Una forma del tipo t que quepa en una caja de w × h (con su esquina inferior izquierda en 0,0), en múltiplos de q ──
function genForma(t, w, h, q, rnd, girar, minimo, fr) {
    fr = Math.max(0, Math.min(1, fr || 0));
    const Q = v => Math.floor(v / q + 1e-9) * q, rot = girar ? Math.round(rnd.entre(0, 12)) * Math.PI / 12 : 0;
    const enCaja = f => { const c = genGenerar(f); if (!c) return null; const bb = bboxPts(muestrearContorno(c));
        // se lleva la caja de la forma a la esquina 0,0, en múltiplos de q (el centro sigue en la rejilla si estaba en ella)
        const d = { x: Math.ceil((-bb.x0) / q - 1e-9) * q, y: Math.ceil((-bb.y0) / q - 1e-9) * q };
        const g = genMover(f, d); const bb2 = { x1: bb.x1 + d.x, y1: bb.y1 + d.y };
        return bb2.x1 <= w + 1e-9 && bb2.y1 <= h + 1e-9 ? g : null; };
    const prueba = hacer => { for (let k = 0; k < 12; k++) { const f = hacer(k); if (f === null) return null; const g = f && enCaja(f); if (g) return g; } return null; };
    const mn = Math.max(minimo, q), E = (lo, hi) => rnd.entre(Math.max(lo, fr * hi), hi);   // de fr·hi a hi (y nunca menos que lo)
    if (t === 'rectangulo') {
        if (!girar) { const W = Q(E(mn, w)), H = Q(E(mn, h)); if (W < mn || H < mn) return null;
            return { tipo:'rectangulo', c:{ x:W / 2, y:H / 2 }, w:W, h:H, rot:0, esq:[0, 1, 2, 3].map(() => ({ t:'v', r:0 })) }; }
        return prueba(k => { const s = 1 - k * 0.07, W = Q(E(mn, w) * s), H = Q(E(mn, h) * s); if (W < mn || H < mn) return null;
            return { tipo:'rectangulo', c:{ x:0, y:0 }, w:W, h:H, rot, esq:[0, 1, 2, 3].map(() => ({ t:'v', r:0 })) }; });
    }
    if (t === 'escalonada') {
        const W = Q(E(mn, w)), H = Q(E(mn, h)); if (W < mn || H < mn) return null;
        const muesca = () => ({ a:Q(rnd.entre(Math.max(q, W * 0.15), W * 0.4)), b:Q(rnd.entre(Math.max(q, H * 0.15), H * 0.4)) });
        const m = [0, 1, 2, 3].map(() => rnd() < 0.5 ? muesca() : null);
        if (!m.some(Boolean)) m[rnd.entero(0, 3)] = muesca();
        m.forEach((x, i) => { if (x && (x.a < q || x.b < q)) m[i] = null; });
        // cada lado conserva al menos dos pasos de recta
        const cabe = (u, v, L) => (u ? u : 0) + (v ? v : 0) <= L - 2 * q;
        if (!cabe(m[0] && m[0].a, m[1] && m[1].a, W)) m[1] = null; if (!cabe(m[3] && m[3].a, m[2] && m[2].a, W)) m[2] = null;
        if (!cabe(m[0] && m[0].b, m[3] && m[3].b, H)) m[3] = null; if (!cabe(m[1] && m[1].b, m[2] && m[2].b, H)) m[2] = null;
        const ranuras = {};
        [['abajo', 0, 1], ['arriba', 3, 2]].forEach(([lado, i0, i1]) => {
            if (rnd() >= 0.35) return;
            const x0 = (m[i0] ? m[i0].a : 0) + 2 * q, x1 = W - (m[i1] ? m[i1].a : 0) - 2 * q;
            const s = Q(rnd.entre(Math.max(q, W * 0.15), W * 0.35)), t = Q(rnd.entre(Math.max(q, H * 0.12), H * 0.3));
            if (s < q || t < q || x1 - x0 < s) return;
            const otra = lado === 'arriba' ? ranuras.abajo : null;
            if (otra && otra.t + t > H - 2 * q) return;
            ranuras[lado] = { x:Q(rnd.entre(x0, x1 - s)), s, t };
            if (ranuras[lado].x < x0 - 1e-9) ranuras[lado].x += q;
            if (ranuras[lado].x + s > x1 + 1e-9) delete ranuras[lado];
        });
        // las ranuras no pueden llegar a las muescas de su lado opuesto
        const ok = !(ranuras.abajo && ((m[3] && ranuras.abajo.t >= H - m[3].b - q && ranuras.abajo.x < m[3].a + q) || (m[2] && ranuras.abajo.t >= H - m[2].b - q && ranuras.abajo.x + ranuras.abajo.s > W - m[2].a - q)))
                && !(ranuras.arriba && ((m[0] && ranuras.arriba.t >= H - m[0].b - q && ranuras.arriba.x < m[0].a + q) || (m[1] && ranuras.arriba.t >= H - m[1].b - q && ranuras.arriba.x + ranuras.arriba.s > W - m[1].a - q)));
        if (!ok) { delete ranuras.abajo; delete ranuras.arriba; }
        return { tipo:'escalonada', c:{ x:0, y:0 }, W, H, muescas:m, ranuras };
    }
    if (t === 'circulo') { const r = Q(E(mn, Math.min(w, h)) / 2); if (2 * r < mn) return null; return { tipo:'circulo', c:{ x:r, y:r }, r, rot:0 }; }
    if (t === 'ranura') {
        // coliso: dos semicírculos de radio r unidos por rectas; horizontal o vertical (o girado)
        const vert = !girar && rnd() < 0.35, lw = vert ? h : w, lh = vert ? w : h;
        const r = Q(rnd.entre(mn / 2, Math.min(lh / 2, lw / 4)));
        if (2 * r < mn) return null;
        const L = Math.floor((E(2 * r + Math.max(2 * r, q), lw) - 2 * r) / (2 * q)) * 2 * q;
        if (L < q) return null;
        if (!girar) return vert ? { tipo:'ranura', c:{ x:r, y:r + L / 2 }, L, w:2 * r, rot:Math.PI / 2 } : { tipo:'ranura', c:{ x:r + L / 2, y:r }, L, w:2 * r, rot:0 };
        return prueba(k => ({ tipo:'ranura', c:{ x:0, y:0 }, L:Math.max(q, L - k * 2 * q), w:2 * r, rot }));
    }
    if (t === 'poligono') {
        // la apotema (la mitad de la medida entre caras) en múltiplos de q: así el lado de abajo cae en la rejilla
        const N = rnd.entero(3, 8), A0 = Math.min(w, h) / 2 * rnd.entre(Math.max(0.5, fr), 1.05);
        return prueba(k => { const A = Q(A0 * (1 - k * 0.07)); if (2 * A < mn) return null;
            return { tipo:'poligono', c:{ x:0, y:0 }, N, R:A / Math.cos(Math.PI / N), rot:(girar ? rot : 0) - Math.PI / 2 + Math.PI / N }; });
    }
    if (t === 'estrella') {
        const N = rnd.entero(4, 7), Re0 = Math.min(w, h) / 2 * rnd.entre(Math.max(0.6, fr), 1.1), fi = rnd.entre(0.42, 0.6);
        return prueba(k => { const Re = Q(Re0 * (1 - k * 0.07)), Ri = Math.max(q, Q(Re * fi)); if (2 * Ri < mn || Re <= Ri) return null;
            return { tipo:'estrella', c:{ x:0, y:0 }, N, Re, Ri, rot:(girar ? rot : 0) + Math.PI / 2 }; });
    }
    return null;
}
// ── Fase 2: esquinas (redondeada, hacia dentro, chaflán) y lados en arco (abombado, hundido) ──
// Usan su propio generador aleatorio (rndM): con los modificadores a 0 %, cada número da la misma pieza que antes.
function genTrasladar(c, d) {
    const n = { pts:c.pts.map(p => add(p, d)), b:c.b.slice(), cerrado:true, tipo:'auto' };
    if (c.forma) n.forma = genMover(c.forma, d);
    if (c.grupo) n.grupo = c.grupo;
    return n;
}
// Arcos que la fresa recorre por su lado cóncavo (centro en el lado de la fresa): radio de al menos un diámetro
function genArcosOK(c, esExt, D) {
    const M = genMuestras(c);
    return tramos(c).every(t => { if (!t.b) return true; const a = arcoDeBulge(t.p1, t.p2, t.b); if (!a) return true;
        const centroDentro = puntoEnPoligono(a.c, M), ladoFresa = esExt ? !centroDentro : centroDentro;
        return !ladoFresa || a.r >= D - 1e-6; });
}
// Un lado recto de A a B, como arco de radio múltiplo de q (entre unos 40° y 120° de arco); signo +1 abombado (hacia la derecha del avance)
function genBulgeLado(A, B, haciaDerecha, rndM, q, D) {
    const L = dist(A, B); if (L < 2 * q) return 0;
    const Rmin = Math.max(L / (2 * Math.sin(Math.PI / 3)), D), Rmax = L / (2 * Math.sin(Math.PI / 9));
    const R = Math.ceil(rndM.entre(Rmin, Math.max(Rmin, Rmax)) / q - 1e-9) * q;
    if (R < L / 2 + 1e-9) return 0;
    const th = 2 * Math.asin(L / (2 * R));
    return (haciaDerecha ? 1 : -1) * Math.tan(th / 4);
}
function genModificar(c, esExt, cfg, rndM, q, D) {
    const pEsq = (cfg.pEsq || 0) / 100, pLado = (cfg.pLado || 0) / 100, tiposE = cfg.esq || [], tiposL = cfg.lado || [];
    if ((!pEsq || !tiposE.length) && (!pLado || !tiposL.length)) return c;
    const f = c.forma || c.formaGen, rmin = Math.max(q, Math.ceil(D / q - 1e-9) * q);      // radios de al menos un diámetro de fresa
    if (!f || !['rectangulo', 'poligono', 'estrella', 'escalonada'].includes(f.tipo) || c.b.some(b => b)) return c;
    const o = Math.sign(areaFirmada(c.pts)) || 1;
    // las esquinas: en el rectángulo, con su receta (sigue siendo editable); en polígonos y estrellas, a mano
    let base = c, vivas;
    if (f.tipo === 'rectangulo') {
        const lim = Math.min(f.w, f.h) / 2, esq = [0, 1, 2, 3].map(() => {
            if (rndM() >= pEsq || !tiposE.length) return { t:'v', r:0 };
            const t = rndM.uno(tiposE), mx = Math.floor(Math.min(lim * 0.8, Math.min(f.w, f.h) * 0.3) / q) * q, mn = t === 'ch' ? q : rmin;
            if (mx < mn) return { t:'v', r:0 };
            return { t, r:Math.round(rndM.entre(mn, mx) / q) * q };
        });
        const nf = JSON.parse(JSON.stringify(f)); nf.esq = esq;
        base = genContorno(nf); vivas = esq.map(e => e.t === 'v');
    } else {
        const n = c.pts.length, P = c.pts, pts = [], b = [], recorte = new Array(n).fill(0), modo = new Array(n).fill(null);
        const lados = P.map((p, i) => dist(p, P[(i + 1) % n]));
        for (let i = 0; i < n; i++) {
            if (rndM() >= pEsq || !tiposE.length) continue;
            const V = P[i], A = P[(i + n - 1) % n], B = P[(i + 1) % n], e1 = norm(sub(V, A)), e2 = norm(sub(B, V));
            const giro = cross(e1, e2), phi = Math.acos(Math.max(-1, Math.min(1, dot(e1, e2)))), convexa = giro * o > 0;
            const t = rndM.uno(tiposE.filter(x => x !== 'c' || convexa)); if (!t) continue;
            const r = Math.round(rndM.entre(t === 'ch' ? q : rmin, Math.max(t === 'ch' ? q : rmin, Math.min(lados[(i + n - 1) % n], lados[i]) * 0.3)) / q) * q;
            const d = t === 'r' ? r * Math.tan(phi / 2) : r;
            if (!(d > 0)) continue;
            modo[i] = { t, r, d, e1, e2, phi, giro }; recorte[i] = d;
        }
        // cada lado conserva al menos q de recta
        for (let i = 0; i < n; i++) { const j = (i + 1) % n; if (lados[i] - recorte[i] - recorte[j] < q - 1e-9) { if (modo[j]) { modo[j] = null; recorte[j] = 0; } if (lados[i] - recorte[i] - recorte[j] < q - 1e-9 && modo[i]) { modo[i] = null; recorte[i] = 0; } } }
        for (let i = 0; i < n; i++) {
            const m = modo[i], V = P[i];
            if (!m) { pts.push(V); b.push(0); continue; }
            const A = sub(V, mulv(m.e1, m.d)), B = add(V, mulv(m.e2, m.d));
            const alfa = Math.PI - m.phi;                                    // ángulo interior (esquina convexa)
            pts.push(A); b.push(m.t === 'ch' ? 0 : m.t === 'r' ? Math.sign(m.giro) * Math.tan(m.phi / 4) : -Math.sign(m.giro) * Math.tan(alfa / 4));
            pts.push(B); b.push(0);
        }
        base = { pts, b, cerrado:true, tipo:'auto' }; vivas = null;
        base._vivo = P.map((p, i) => !modo[i]);
    }
    // los lados en arco: solo los que van de esquina viva a esquina viva
    const vert = f.tipo === 'rectangulo' ? generarForma({ ...f, esq:[0, 1, 2, 3].map(() => ({ t:'v', r:0 })) }).pts : c.pts;
    const vivo = f.tipo === 'rectangulo' ? vivas : base._vivo; delete base._vivo;
    const indice = p => vert.findIndex(v => dist(v, p) < 1e-6);
    const R = { pts:base.pts.slice(), b:base.b.slice(), cerrado:true, tipo:'auto' }, n = R.pts.length;
    let lados = 0;
    if (pLado && tiposL.length) for (let i = 0; i < n; i++) {
        const A = R.pts[i], B = R.pts[(i + 1) % n], ia = indice(A), ib = indice(B);
        if (ia < 0 || ib < 0 || R.b[i] || !vivo[ia] || !vivo[ib] || rndM() >= pLado) continue;
        const t = rndM.uno(tiposL), bl = genBulgeLado(A, B, (t === 'fuera') === (o > 0), rndM, q, D);
        if (bl) { R.b[i] = bl; lados++; }
    }
    const cambiado = lados || vivo.some(v => !v);
    if (!cambiado) return c;
    const out = lados ? R : base;          // el rectángulo con solo esquinas conserva su receta (base.forma); lo demás va sin receta
    if (out.pts.length < 3 || seCruza(out) || !contornoValido(out) || !genArcosOK(out, esExt, D)) return c;
    return out;
}
// ── Un ejercicio completo ──
function generarEjercicio(semilla, cfg) {
    const rnd = genAleatorio(semilla), rndM = genAleatorio((semilla * 2654435761) ^ 0x5bd1e995), q = Math.max(0.5, +cfg.paso || 1), D = Math.max(0.1, +cfg.fresa || 6);
    const pared = Math.max(+cfg.pared || 0, 1), sep = D + 4;                     // entre piezas: la fresa y un margen
    const W = cfg.ancho, H = cfg.alto, ocupar = Math.max(0.2, Math.min(1, (cfg.ocupar || 60) / 100));
    const nP = rnd.entero(Math.max(1, cfg.pMin), Math.max(cfg.pMin, cfg.pMax));
    const extT = cfg.ext.length ? cfg.ext : ['rectangulo'], intT = cfg.int.length ? cfg.int : [];
    // reparto en celdas: columnas y filas según la proporción del espacio
    const cols = Math.max(1, Math.min(nP, Math.round(Math.sqrt(nP * W / H)) || 1)), filas = Math.ceil(nP / cols);
    const cw = Math.floor((W - (cols - 1) * sep) / cols / q) * q, ch = Math.floor((H - (filas - 1) * sep) / filas / q) * q;
    const out = [], avisos = []; let nInt = 0, faltan = 0;
    const minHueco = Math.max(2 * D, 2 * q, 8);                                  // un hueco, al menos dos diámetros de fresa
    for (let p = 0; p < nP; p++) {
        const col = p % cols, fila = Math.floor(p / cols);
        const x0 = Math.floor(col * (cw + sep) / q) * q, y0 = Math.floor(fila * (ch + sep) / q) * q;
        let mejor = null;
        for (let intento = 0; intento < 8 && !(mejor && mejor.ints.length >= mejor.pedidos); intento++) {
            const t = rnd.uno(extT);
            const f0 = genForma(t, cw, ch, q, rnd, cfg.girar, Math.max(30, 3 * minHueco), ocupar);
            if (!f0) continue;
            let ext = genContorno(genMover(f0, { x:x0, y:y0 }));
            for (let k = 0; k < 6; k++) { const m = genModificar(ext, true, cfg, rndM, q, D); const bm = bboxPts(genMuestras(m));
                if (bm.x0 >= x0 - 1e-6 && bm.y0 >= y0 - 1e-6 && bm.x1 <= x0 + cw + 1e-6 && bm.y1 <= y0 + ch + 1e-6) { ext = m; break; } }   // lo abombado, sin salirse de su sitio
            const E = genMuestras(ext), bb = bboxPts(E);
            const pedidos = intT.length ? rnd.entero(Math.max(0, cfg.iMin), Math.max(cfg.iMin, cfg.iMax)) : 0, ints = [];
            for (let k = 0; k < 120 && ints.length < pedidos; k++) {
                const ti = rnd.uno(intT), lim = Math.min(bb.x1 - bb.x0, bb.y1 - bb.y0) * rnd.entre(0.22, 0.5);
                const fi = genForma(ti, lim, lim * rnd.entre(0.6, 1.3), q, rnd, cfg.girar, minHueco, 0.5); if (!fi) continue;
                const bi = bboxPts(muestrearContorno(genGenerar(fi)));
                const dx = Math.floor(rnd.entre(bb.x0 + pared, bb.x1 - pared - (bi.x1 - bi.x0)) / q) * q - Math.floor(bi.x0 / q) * q;
                const dy = Math.floor(rnd.entre(bb.y0 + pared, bb.y1 - pared - (bi.y1 - bi.y0)) / q) * q - Math.floor(bi.y0 / q) * q;
                if (!isFinite(dx) || !isFinite(dy)) continue;
                let hc = genContorno(genMover(fi, { x:dx, y:dy }));
                if (cfg.modInt !== false) hc = genModificar(hc, false, cfg, rndM, q, D);
                const Hm = genMuestras(hc);
                if (!Hm.every(pt => puntoEnPoligono(pt, E))) continue;                       // dentro de la pieza
                if (genDistPoligonos(Hm, E) < pared - 1e-6) continue;                       // pared con el borde
                if (ints.some(o => genDistPoligonos(Hm, o.m) < pared - 1e-6 || puntoEnPoligono(Hm[0], o.m) || puntoEnPoligono(o.m[0], Hm))) continue;
                ints.push({ c:hc, m:Hm });
            }
            if (!mejor || ints.length > mejor.ints.length) mejor = { ext, ints, pedidos };
        }
        if (!mejor) { avisos.push(`La pieza ${p + 1} no cabe con estos parámetros`); continue; }
        if (mejor.ints.length < mejor.pedidos) faltan += mejor.pedidos - mejor.ints.length;
        const g = mejor.ints.length ? nuevoGrupo() : null;
        [mejor.ext].concat(mejor.ints.map(o => o.c)).forEach(c => { if (g) c.grupo = g; out.push(c); });
        nInt += mejor.ints.length;
    }
    if (faltan) avisos.push(`${faltan} interior${faltan === 1 ? '' : 'es'} no cabe${faltan === 1 ? '' : 'n'} con la pared mínima`);
    // todo el conjunto, con su esquina inferior izquierda en el cero pieza
    const todas = [].concat(...out.map(genMuestras)), bb = todas.length ? bboxPts(todas) : { x0:0, y0:0, x1:0, y1:0 };
    const d = { x: -Math.floor(bb.x0 / q + 1e-9) * q, y: -Math.floor(bb.y0 / q + 1e-9) * q };
    const cs = out.map(c => genTrasladar(c, d));
    return { contornos:cs, piezas:cs.length - nInt, interiores:nInt, w:bb.x1 - bb.x0, h:bb.y1 - bb.y0, avisos };
}
// ── Fase 3: niveles de dificultad (la progresión de clase) ──
const GEN_NIVELES = {
    libre:{ t:'Libre: lo que marques' },
    rectas:{ t:'1 · Solo rectas horizontales y verticales', p:{ ext:['rectangulo', 'escalonada'], int:['rectangulo'], pEsq:0, pLado:0, girar:false } },
    inclinadas:{ t:'2 · Rectas inclinadas (chaflanes, por proyecciones)', p:{ ext:['rectangulo', 'escalonada'], int:['rectangulo'], pEsq:45, esq:['ch'], pLado:0, girar:false, modInt:true } },
    tangentes:{ t:'3 · Arcos con el centro en la rejilla (I J enteros)', p:{ ext:['rectangulo', 'escalonada', 'circulo', 'ranura'], int:['rectangulo', 'circulo', 'ranura'], pEsq:45, esq:['r', 'c', 'ch'], pLado:0, girar:false, modInt:true } },
    ij:{ t:'4 · Arcos que piden calcular I J (y polígonos, con polares)', p:{ ext:['rectangulo', 'escalonada', 'poligono', 'circulo', 'ranura'], int:['rectangulo', 'circulo', 'ranura', 'poligono'], pEsq:40, esq:['r', 'c', 'ch'], pLado:35, lado:['fuera', 'dentro'], girar:false, modInt:true } },
};
function genCoincideNivel(n) {
    const N = GEN_NIVELES[n]; if (!N || !N.p) return false;
    return Object.entries(N.p).every(([k, v]) => Array.isArray(v) ? JSON.stringify([...(cfgGen[k] || [])].sort()) === JSON.stringify([...v].sort()) : cfgGen[k] === v);
}
function elegirNivel(n) {
    const N = GEN_NIVELES[n]; cfgGen.nivel = N ? n : 'libre';
    if (N && N.p) Object.assign(cfgGen, JSON.parse(JSON.stringify(N.p)));
    genGuardarCfg(); pintarCfgGen(); pintarPropuestas();
}
// ── Fase 3: una serie de ejercicios para la clase (los números siguientes al primero que se ve) ──
async function guardarSerieBib(imprimir) {
    const N = Math.max(1, Math.min(60, Math.round(+document.getElementById('genSerieN').value || cfgGen.serieN || 25)));
    cfgGen.serieN = N; genGuardarCfg();
    await bibCargar();
    const nivel = cfgGen.nivel !== 'libre' && GEN_NIVELES[cfgGen.nivel] ? ' - nivel ' + GEN_NIVELES[cfgGen.nivel].t.split(' · ')[0] : '';
    const carpeta = `Aleatorios/Serie ${genBase}${nivel}`, ids = [];
    const antes = { gen:genUltimo, ver:cfgCotas.ver };
    try {
        cfgCotas.ver = true;
        for (let k = 0; k < N; k++) {
            const s = genBase + k, r = generarEjercicio(s, cfgGen); if (!r.contornos.length) continue;
            genUltimo = { semilla:s, cfg:JSON.parse(JSON.stringify(cfgGen)) };
            r.contornos.forEach(c => { c.uid = nuevoUid(); });
            const datos = datosDeEstado({ contornos:r.contornos, aux:[] }, { titulo:`Ejercicio aleatorio Nº ${s}`, num:String(k + 1) }, `Ejercicio aleatorio ${s}`);
            if (!datos) continue;
            const e = entradaDe(datos, `${carpeta}/${String(k + 1).padStart(2, '0')} - Nº ${s}.json`, `${String(k + 1).padStart(2, '0')} - Nº ${s}.json`);
            await bibGuardarEntrada(e); ids.push(e.id);
        }
    } finally { genUltimo = antes.gen; cfgCotas.ver = antes.ver; }
    await bibCargar();
    if (!ids.length) { snack('Con estos parámetros no sale ningún ejercicio'); return; }
    if (imprimir) { cerrarGenerador(); await imprimirLoteBib(ids, imprimir); }
    else snack(`${ids.length} ejercicios guardados en la biblioteca, en la carpeta ${carpeta} (del Nº ${genBase} al ${genBase + N - 1})`);
    return ids;
}
// ── Ventana ──
function genGuardarCfg() { try { localStorage.setItem('calcador_generador', JSON.stringify(cfgGen)); } catch (e) {} }
function abrirGenerador() {
    const g = id => document.getElementById(id);
    if (!g('genFormasExt').children.length) {
        const chips = (caja, clave, dic) => { caja.innerHTML = Object.entries(dic).map(([k, t]) => `<label class="gen-chip"><input type="checkbox" data-k="${k}"> ${t}</label>`).join('');
            caja.querySelectorAll('input').forEach(i => i.onchange = () => { cfgGen[clave] = [...caja.querySelectorAll('input:checked')].map(x => x.dataset.k); cambiarGenerador(); }); };
        chips(g('genFormasExt'), 'ext', GEN_FORMAS); chips(g('genFormasInt'), 'int', GEN_FORMAS_INT);
        g('genNivel').innerHTML = Object.entries(GEN_NIVELES).map(([k, n]) => `<option value="${k}">${n.t}</option>`).join('');
        const chips2 = (caja, clave, dic) => { caja.innerHTML = Object.entries(dic).map(([k, t]) => `<label class="gen-chip"><input type="checkbox" data-k="${k}"> ${t}</label>`).join('');
            caja.querySelectorAll('input').forEach(i => i.onchange = () => { cfgGen[clave] = [...caja.querySelectorAll('input:checked')].map(x => x.dataset.k); cambiarGenerador(); }); };
        chips2(g('genEsqTipos'), 'esq', GEN_ESQ); chips2(g('genLadoTipos'), 'lado', GEN_LADO);
    }
    if (!genUltimo && typeof cfgFresa !== 'undefined' && cfgFresa.d > 0) cfgGen.fresa = cfgFresa.d;
    pintarCfgGen();
    g('modalGenerador').classList.add('visible');
    if (!genBase) genBase = 10000 + Math.floor(Math.random() * 89990);
    pintarPropuestas();
}
function cerrarGenerador() { document.getElementById('modalGenerador').classList.remove('visible'); }
function pintarCfgGen() {
    const g = id => document.getElementById(id);
    [['genAncho', 'ancho'], ['genAlto', 'alto'], ['genOcupar', 'ocupar'], ['genPMin', 'pMin'], ['genPMax', 'pMax'], ['genIMin', 'iMin'], ['genIMax', 'iMax'], ['genPaso', 'paso'], ['genFresa', 'fresa'], ['genPared', 'pared'], ['genPEsq', 'pEsq'], ['genPLado', 'pLado']]
        .forEach(([id, k]) => { g(id).value = cfgGen[k]; });
    g('genGirar').checked = !!cfgGen.girar; g('genModInt').checked = cfgGen.modInt !== false;
    if (cfgGen.nivel !== 'libre' && !genCoincideNivel(cfgGen.nivel)) cfgGen.nivel = 'libre';
    g('genNivel').value = cfgGen.nivel || 'libre'; g('genSerieN').value = cfgGen.serieN || 25;
    const des = g('genSerieDe'); if (des) des.textContent = `Los números del ${genBase} al ${genBase + (cfgGen.serieN || 25) - 1}, con estos parámetros`;
    g('genEsqTipos').querySelectorAll('input').forEach(i => { i.checked = (cfgGen.esq || []).includes(i.dataset.k); });
    g('genLadoTipos').querySelectorAll('input').forEach(i => { i.checked = (cfgGen.lado || []).includes(i.dataset.k); });
    g('genFormasExt').querySelectorAll('input').forEach(i => { i.checked = cfgGen.ext.includes(i.dataset.k); });
    g('genFormasInt').querySelectorAll('input').forEach(i => { i.checked = cfgGen.int.includes(i.dataset.k); });
}
function cambiarGenerador() {
    const g = id => document.getElementById(id), n = (id, lo, hi, def) => { const v = parseFloat(String(g(id).value).replace(',', '.')); return isFinite(v) ? Math.max(lo, Math.min(hi, v)) : def; };
    Object.assign(cfgGen, { ancho:n('genAncho', 40, 2000, 250), alto:n('genAlto', 40, 2000, 200), ocupar:n('genOcupar', 20, 100, 60),
        pMin:Math.round(n('genPMin', 1, 12, 1)), pMax:Math.round(n('genPMax', 1, 12, 1)), iMin:Math.round(n('genIMin', 0, 12, 0)), iMax:Math.round(n('genIMax', 0, 12, 2)),
        paso:+g('genPaso').value || 1, girar:g('genGirar').checked, fresa:n('genFresa', 0.5, 50, 6), pared:n('genPared', 0, 100, 6),
        pEsq:n('genPEsq', 0, 100, 30), pLado:n('genPLado', 0, 100, 15), modInt:g('genModInt').checked });
    if (cfgGen.pMax < cfgGen.pMin) cfgGen.pMax = cfgGen.pMin;
    if (cfgGen.iMax < cfgGen.iMin) cfgGen.iMax = cfgGen.iMin;
    if (cfgGen.nivel !== 'libre' && !genCoincideNivel(cfgGen.nivel)) cfgGen.nivel = 'libre';
    document.getElementById('genNivel').value = cfgGen.nivel;
    genGuardarCfg(); pintarPropuestas();
}
function otrasPropuestas() { genBase = 10000 + Math.floor(Math.random() * 89990); document.getElementById('genSemilla').value = ''; pintarCfgGen(); pintarPropuestas(); }
function verSemilla() { const v = parseInt(document.getElementById('genSemilla').value, 10); if (v > 0) { genBase = v; pintarCfgGen(); pintarPropuestas(); } }
function pintarPropuestas() {
    const caja = document.getElementById('genLista'), aviso = document.getElementById('genAviso');
    aviso.textContent = !cfgGen.ext.length ? 'Marca al menos una forma para las piezas.' : '';
    if (!cfgGen.ext.length) { caja.innerHTML = ''; return; }
    const fichas = [];
    for (let k = 0; k < 6; k++) {
        const s = genBase + k, r = generarEjercicio(s, cfgGen);
        fichas.push(`<div class="var-ficha gen-ficha" data-s="${s}" title="Usar este ejercicio"><div class="var-mini">${svgMini({ calcador:{ contornos:r.contornos } })}</div>
            <div><strong>Nº ${s}</strong><br><span>${r.piezas} pieza${r.piezas === 1 ? '' : 's'} · ${r.interiores} interior${r.interiores === 1 ? '' : 'es'}<br>${fmt(r.w, 1)} × ${fmt(r.h, 1)} mm</span>${r.avisos.length ? `<br><span class="gen-av">⚠ ${r.avisos.join('; ')}</span>` : ''}</div></div>`);
    }
    caja.innerHTML = fichas.join('');
    caja.querySelectorAll('.gen-ficha').forEach(el => el.onclick = () => usarEjercicio(+el.dataset.s));
}
function usarEjercicio(s) {
    const r = generarEjercicio(s, cfgGen);
    if (!r.contornos.length) { snack('Con estos parámetros no sale ninguna pieza'); return; }
    if (contornos.length && !confirm('Se sustituye el dibujo actual por el ejercicio Nº ' + s + ' (puedes deshacer).')) return;
    guardarUndo();
    contornos = r.contornos; aux = []; auxPend = null; fondo = null; sel = -1; selSet = new Set(); cotasAjuste = {}; cotasManuales = []; dib = null; circ = null; ran = null;
    if (typeof requisitosPorDefecto === 'function') requisitosPorDefecto();
    genUltimo = { semilla:s, cfg:JSON.parse(JSON.stringify(cfgGen)) };
    document.getElementById('projectName').value = 'Ejercicio aleatorio ' + s;
    cfgCotas.ver = true; sincronizarControlesCotas();      // es un plano para el alumno: con sus cotas
    asegurarUids(); actualizarPanelFondo(); cerrarGenerador(); refrescar(); encuadrar();
    snack(`Ejercicio Nº ${s}: ${r.piezas} pieza${r.piezas === 1 ? '' : 's'} y ${r.interiores} interior${r.interiores === 1 ? '' : 'es'}, ${fmt(r.w, 1)} × ${fmt(r.h, 1)} mm. Las formas se pueden seguir editando`);
}
