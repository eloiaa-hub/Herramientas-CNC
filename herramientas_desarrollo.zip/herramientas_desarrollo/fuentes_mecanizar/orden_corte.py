"""Calcador: orden de corte elegible en ⚙️ Mecanizar. Por defecto, primero los interiores y después los exteriores
(como se hace en madera: la pieza sigue sujeta al tablero mientras se cortan sus agujeros); se puede volver al orden
anterior (exteriores primero). Las entradas E1, E2… del plano y la tabla de soluciones siguen el mismo orden.
Se guarda en el JSON (cfgMec.orden: 'int' | 'ext').
Uso: python3 orden_corte.py <carpeta de la suite>
"""
import sys, os
P = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', 'calcador.html')
s = open(P, encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    n = s.count(a); assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
    s = s.replace(a, b)
rep("coord:'G90', comp:'G40', estr:'plano', unid:'G71', ancho:true };", "coord:'G90', comp:'G40', estr:'plano', unid:'G71', ancho:true, orden:'int' };")
rep("mecEstr:'estr', mecUnid:'unid' };", "mecEstr:'estr', mecUnid:'unid', mecOrden:'orden' };")
rep("""                <div class="param-line">Unidades <select id="mecUnid">""",
    """                <div class="param-line" title="Qué se corta antes. Interiores primero (lo habitual en madera): los agujeros se cortan con la pieza todavía sujeta al tablero y, al final, el contorno exterior la suelta. Exteriores primero: el orden de las versiones anteriores. Los grabados y las cajeras van siempre antes. Las entradas E1, E2… del plano y la tabla de soluciones siguen este orden">Orden de corte <select id="mecOrden"><option value="int">Interiores primero, después exteriores</option><option value="ext">Exteriores primero, después interiores</option></select></div>
                <div class="param-line">Unidades <select id="mecUnid">""")
rep("""Se mecanizan primero los grabados, después las cajeras, los exteriores y por último los interiores.</div>""",
    """Se mecanizan primero los grabados, después las cajeras y luego los cortes, en el <strong>orden de corte</strong> elegido (por defecto, los interiores antes que los exteriores).</div>""")
rep("estrategia:cfgMec.estr, unidades:cfgMec.unid, nombre:nombreProyecto(),", "estrategia:cfgMec.estr, unidades:cfgMec.unid, orden:cfgMec.orden, nombre:nombreProyecto(),")
# el motor
rep("""        // Orden: grabados (con la pieza aún sujeta), cajeras, cortes exteriores y cortes interiores""",
    """        // Orden: grabados (con la pieza aún sujeta), cajeras y los cortes: interiores y luego exteriores (por defecto,
        // la pieza sigue sujeta mientras se cortan sus agujeros) o, con orden:'ext', exteriores y luego interiores""")
rep("""        const orden0 = [...grabados, ...cajeras, ...exteriores, ...interiores];""",
    """        const intPrimero = P.orden !== 'ext';
        const orden0 = intPrimero ? [...grabados, ...cajeras, ...interiores, ...exteriores] : [...grabados, ...cajeras, ...exteriores, ...interiores];""")
rep("""${grabados.length ? 'grabados primero, después exteriores' : 'se mecanizan exteriores primero'} y luego interiores\\n""",
    """${grabados.length ? 'grabados primero, después ' : 'se mecanizan '}${intPrimero ? 'interiores primero y luego exteriores' : 'exteriores primero y luego interiores'}\\n""")
rep("""//       coord:'G90'|'G91'|'mixta' (G90 en la entrada y el cierre, G91 en el recorrido), comp:'G40'|'G41'|'G42'|'auto' (según el trazado), estrategia:'plano'|'concordancia'|'oposicion',""",
    """//       coord:'G90'|'G91'|'mixta' (G90 en la entrada y el cierre, G91 en el recorrido), comp:'G40'|'G41'|'G42'|'auto' (según el trazado), estrategia:'plano'|'concordancia'|'oposicion',
//       orden:'int' (interiores antes que exteriores, por defecto) | 'ext' (exteriores antes),""")
# entradas E1, E2… del plano y tabla de soluciones: el mismo orden
rep("""function rangoMecanizado(tipo, c) { if (esGrabado(c) || tipo === 'abierto') return -1; return tipo === 'interior' ? 1 : 0; }""",
    """function rangoMecanizado(tipo, c) { if (esGrabado(c) || tipo === 'abierto') return -1; const intPrimero = !(typeof cfgMec === 'object' && cfgMec && cfgMec.orden === 'ext'); return (tipo === 'interior') === intPrimero ? 0 : 1; }""")
rep("""// Grabados (y trazos abiertos) primero, luego cortes exteriores y luego interiores""", """// Grabados (y trazos abiertos) primero, luego los cortes en el orden de ⚙️ Mecanizar (interiores primero, salvo que se elija lo contrario)""")
rep("""⚙️ Mecanizar hace primero los grabados, luego las cajeras, los exteriores y por último los interiores; las entradas E1, E2… siguen ese orden.</p>""",
    """⚙️ Mecanizar hace primero los grabados, luego las cajeras y después los cortes: por defecto, los <strong>interiores antes que los exteriores</strong> (la pieza sigue sujeta mientras se cortan sus agujeros); en ⚙️ Mecanizar, <em>Orden de corte</em>, se puede elegir lo contrario. Con una pieza dentro del hueco de otra (anidado por la forma real), de dentro afuera: la pieza del hueco, el hueco y el exterior. Las entradas E1, E2… del plano y la tabla de soluciones siguen ese orden.</p>""")
rep("function generarMec() {", "// al cambiar el orden de corte, el plano renumera sus entradas E1, E2…\nwindow.addEventListener('load', () => { const el = document.getElementById('mecOrden'); if (el) el.addEventListener('change', () => { cfgMec.orden = el.value; try { refrescar(); } catch (e) {} }); });\nfunction generarMec() {")
# la tabla sin abrir (su lista de contornos aún vacía) vale para todos los contornos, no solo para el primero
rep("const ci = document.getElementById('tbCont').value, prog", "const ci = document.getElementById('tbCont').value || 'todos', prog")

# ── «De dentro afuera»: con piezas metidas en el hueco de otra (Anidador por forma real), primero lo más hondo.
# Nivel de anidamiento de cada contorno cerrado = cuántos contornos cerrados lo contienen. Se corta de mayor a menor
# nivel: la pieza del hueco (y sus agujeros) antes que el hueco que la rodea, y este antes que el exterior.
# En una pieza sola es lo mismo que «interiores primero».
rep("function rangoMecanizado(tipo, c) {", """let memoNiveles = null;
function nivelesAnidamiento() {
    const hg = huellaGeometria();
    if (memoNiveles && memoNiveles.k === hg) return memoNiveles.v;
    const cerr = contornos.map(c => c.cerrado && c.pts.length >= 2 && !c.texto && !c.deTexto && !esCajera(c) && !esIsla(c) && !esGrabado(c) ? muestrearContorno(c) : null);
    const v = contornos.map((c, i) => { if (!cerr[i]) return 0; const q = cerr[i][0]; let n = 0;
        cerr.forEach((pol, j) => { if (j !== i && pol && puntoEnPol(q, pol)) n++; }); return n; });
    memoNiveles = { k:hg, v };
    return v;
}
function rangoMecanizado(tipo, c) {""")
rep("""const intPrimero = !(typeof cfgMec === 'object' && cfgMec && cfgMec.orden === 'ext'); return (tipo === 'interior') === intPrimero ? 0 : 1; }""",
    """const intPrimero = !(typeof cfgMec === 'object' && cfgMec && cfgMec.orden === 'ext'); if (!intPrimero) return tipo === 'interior' ? 1 : 0; const i = contornos.indexOf(c); return i < 0 ? (tipo === 'interior' ? 0 : 1) : 100 - (nivelesAnidamiento()[i] || 0); }""")
rep("""            tramos: tramos(c).map(q => ({ p1:{ x:q.p1.x, y:q.p1.y }, p2:{ x:q.p2.x, y:q.p2.y }, b:q.b || 0 })), ci: contornos.indexOf(c) };""",
    """            tramos: tramos(c).map(q => ({ p1:{ x:q.p1.x, y:q.p1.y }, p2:{ x:q.p2.x, y:q.p2.y }, b:q.b || 0 })), ci: contornos.indexOf(c), nivel: nivelesAnidamiento()[contornos.indexOf(c)] || 0 };""")
rep("""        const orden0 = intPrimero ? [...grabados, ...cajeras, ...interiores, ...exteriores] : [...grabados, ...cajeras, ...exteriores, ...interiores];""",
    """        // de dentro afuera: por nivel de anidamiento, de mayor a menor (en una pieza sola: los interiores y luego el exterior)
        const porNivel = cortes.map((t, k) => ({ t, k, n: isFinite(+t.nivel) ? +t.nivel : (t.tipo === 'interior' ? 1 : 0) })).sort((a, b) => b.n - a.n || a.k - b.k).map(o => o.t);
        const orden0 = intPrimero ? [...grabados, ...cajeras, ...porNivel] : [...grabados, ...cajeras, ...exteriores, ...interiores];""")
open(P, 'w', encoding='utf-8').write(s)
print('Calcador: orden de corte elegible (interiores primero):', P)
