// ── 💬 Explicar la línea marcada y 📍 posición absoluta en las líneas en G91 ──
// explicarPrograma(texto, moves) recorre el programa con el mismo estado modal que el intérprete
// (G90/G91, G0…G3, ciclos, unidades) y deja, para cada línea, qué hace cada palabra en castellano
// y, con los movimientos ya interpretados (gcodeMoves), de dónde a dónde va la fresa.
const EXPL_G = {
    0: 'movimiento rápido, sin cortar: la máquina va a su máxima velocidad.',
    1: 'recta cortando, a la velocidad de avance F.',
    2: 'arco en sentido horario (como las agujas del reloj), cortando.',
    3: 'arco en sentido antihorario (al revés que las agujas del reloj), cortando.',
    4: 'pausa: la máquina espera sin moverse el tiempo que indica P (o X).',
    15: 'anula las coordenadas polares: X e Y vuelven a ser cartesianas.',
    16: 'coordenadas polares: X es el radio e Y el ángulo en grados, desde el cero pieza.',
    17: 'plano de trabajo XY (el de la planta). Es el habitual y en él se hacen los arcos.',
    18: 'plano de trabajo XZ (no se simula: los arcos se dibujan en XY).',
    19: 'plano de trabajo YZ (no se simula: los arcos se dibujan en XY).',
    20: 'medidas en pulgadas (1 pulgada = 25,4 mm).',
    21: 'medidas en milímetros.',
    28: 'vuelta al punto de referencia de la máquina (depende del control; el simulador no mueve la fresa).',
    30: 'vuelta a un segundo punto de referencia (no se simula).',
    40: 'sin compensación de radio: el centro de la fresa pasa por las coordenadas escritas.',
    41: 'compensación de radio a la izquierda: la fresa va desplazada su radio a la izquierda del sentido de avance.',
    42: 'compensación de radio a la derecha: la fresa va desplazada su radio a la derecha del sentido de avance.',
    43: 'activa la corrección de longitud de la herramienta.',
    44: 'activa la corrección de longitud de la herramienta (en negativo).',
    49: 'anula la corrección de longitud de la herramienta.',
    53: 'esta línea se mide desde el cero de la máquina, no desde el cero pieza.',
    61: 'parada exacta: la máquina frena del todo en cada esquina.',
    64: 'mecanizado continuo: no frena del todo en las esquinas (las redondea un poco).',
    70: 'medidas en pulgadas (controles antiguos).',
    71: 'medidas en milímetros (controles antiguos y TpaCAD).',
    73: 'ciclo de taladrado con rotura de viruta: baja de Q en Q retrocediendo un poco cada vez.',
    80: 'anula el ciclo de taladrado.',
    81: 'ciclo de taladrado simple: en cada X Y baja en rápido hasta R, taladra hasta Z y sale en rápido.',
    82: 'ciclo de taladrado con pausa en el fondo (P), para dejar el fondo limpio.',
    83: 'ciclo de taladrado con descarga de viruta: baja de Q en Q y sube hasta R entre una bajada y otra.',
    85: 'ciclo de escariado: entra y sale cortando, a la velocidad F.',
    86: 'ciclo de taladrado que para el husillo en el fondo y sale en rápido.',
    89: 'ciclo de escariado con pausa en el fondo.',
    90: 'coordenadas absolutas: cada X Y Z es un punto medido desde el cero pieza.',
    91: 'coordenadas incrementales: cada X Y Z es lo que se mueve la fresa desde donde está.',
    94: 'avance en milímetros por minuto.',
    95: 'avance en milímetros por vuelta.',
    98: 'al acabar cada taladro, vuelve al plano inicial (la altura desde la que empezó el ciclo).',
    99: 'al acabar cada taladro, vuelve solo hasta el plano R (más rápido entre taladros cercanos).'
};
for (let g = 54; g <= 59; g++) EXPL_G[g] = 'usa el cero pieza número ' + (g - 53) + ' guardado en la máquina.';
const EXPL_M = {
    0: 'parada: el programa espera a que el operario pulse marcha.',
    1: 'parada opcional (solo si está activada en la máquina).',
    2: 'fin del programa.',
    3: 'arranca el husillo en sentido horario, a las vueltas de S.',
    4: 'arranca el husillo en sentido antihorario.',
    5: 'para el husillo.',
    6: 'cambio de herramienta: la máquina coge la fresa de la T.',
    8: 'abre el refrigerante.',
    9: 'cierra el refrigerante.',
    30: 'fin del programa (y vuelve al principio).'
};
const fmtE = v => String(+(+v).toFixed(3));
const ptE = (x, y, z) => 'X' + fmtE(x) + ' Y' + fmtE(y) + (z === undefined ? '' : ' Z' + fmtE(z));
function alturaE(z) {
    if (Math.abs(z) < 1e-9) return 'a la altura de la superficie de la pieza (Z0)';
    return z < 0 ? fmtE(-z) + ' mm por debajo de la superficie, dentro del material' : fmtE(z) + ' mm por encima de la superficie';
}

function explicarPrograma(texto, moves) {
    const movsPorLinea = {};
    (moves || []).forEach(m => { (movsPorLinea[m.linea] = movsPorLinea[m.linea] || []).push(m); });
    let absoluto = true, movimiento = null, ciclo = null, unidad = 1, polar = false, hayMov = false, fin = null, compPendiente = null;
    return texto.split(/\r?\n/).map((linea, idx) => {
        const n = idx + 1, f = [];      // f: { cod, txt }
        const ex = { frases: f, incr: false, abs: null, resultado: null, notas: [] };
        const com = (linea.match(/\(([^)]*)\)/g) || []).map(c => c.slice(1, -1).trim()).concat(linea.includes(';') ? [linea.slice(linea.indexOf(';') + 1).replace(/\([^)]*\)/g, '').trim()] : []).filter(Boolean);
        let l = linea.replace(/\(.*?\)/g, '').split(';')[0].trim();
        if (!l) {
            if (com.length) f.push({ cod: '', txt: 'Línea de comentario: la máquina no la ejecuta. Sirve para explicar el programa a quien lo lee.' });
            else f.push({ cod: '', txt: 'Línea vacía: la máquina no hace nada.' });
            return ex;
        }
        if (l.startsWith('%')) { f.push({ cod: '%', txt: 'marca de principio o de final del archivo.' }); return ex; }
        if (fin) ex.notas.push('Va después del fin de programa (' + fin + '): la máquina no la ejecuta.');
        l = l.replace(/(\d),(\d)/g, '$1.$2').replace(/([A-Za-z])\s+(?=[-+.\d])/g, '$1').replace(/([-+])\s+(?=[.\d])/g, '$1');
        const palabras = (l.match(/[A-Za-z][-+]?(?:[0-9]+\.?[0-9]*|\.[0-9]+)/g) || []).map(p => ({ L: p[0].toUpperCase(), v: parseFloat(p.slice(1)), t: p.toUpperCase() }));
        const letras = {}; palabras.forEach(p => { if (isFinite(p.v)) letras[p.L] = p.v; });
        const gs = palabras.filter(p => p.L === 'G').map(p => Math.round(p.v));
        const hayXYZ = ('X' in letras) || ('Y' in letras) || ('Z' in letras);
        const movsL = movsPorLinea[n] || [];
        // G70/G71 con X Y Z antes del primer movimiento: medidas del tablero (TpaCAD)
        const medidas = (gs.includes(70) || gs.includes(71)) && !gs.some(g => g >= 0 && g <= 3) && !ciclo && !hayMov && movimiento === null && hayXYZ;
        const absAntes = absoluto, movAntes = movimiento;
        palabras.forEach(p => {
            if (p.L === 'N') f.push({ cod: p.t, txt: 'número de línea (bloque). Solo sirve para numerar.' });
            else if (p.L === 'O') f.push({ cod: p.t, txt: 'número del programa.' });
            else if (p.L === 'G') {
                const g = Math.round(p.v);
                if (medidas && (g === 70 || g === 71)) {
                    f.push({ cod: p.t, txt: 'medidas en ' + (g === 71 ? 'milímetros' : 'pulgadas') + '. Con X Y Z y antes de moverse, como en TpaCAD, son las medidas del tablero: no es un movimiento.' });
                    return;
                }
                f.push({ cod: p.t, txt: EXPL_G[g] ? EXPL_G[g].charAt(0).toUpperCase() + EXPL_G[g].slice(1) : 'código que el simulador no conoce: se ignora.' });
                if (g === 90) absoluto = true; else if (g === 91) absoluto = false;
                else if (g === 20 || g === 70) unidad = 25.4; else if (g === 21 || g === 71) unidad = 1;
                else if (g === 16) polar = true; else if (g === 15) polar = false;
                else if (g >= 0 && g <= 3) { movimiento = g; ciclo = null; }
                else if (g === 80) { ciclo = null; movimiento = null; }
                else if ([73, 81, 82, 83, 85, 86, 89].includes(g)) ciclo = g;
            }
            else if (p.L === 'T') f.push({ cod: p.t, txt: 'herramienta número ' + fmtE(p.v) + (/M0?6(?![0-9])/i.test(l) ? ' (el M06 la pone en el cabezal).' : '.') });
            else if (p.L === 'S') f.push({ cod: p.t, txt: 'el husillo gira a ' + fmtE(p.v) + ' vueltas por minuto (rpm).' });
            else if (p.L === 'F') f.push({ cod: p.t, txt: 'velocidad de avance: ' + fmtE(p.v) + (unidad === 1 ? ' mm' : ' pulgadas') + ' por minuto. Vale para las líneas siguientes hasta que se cambie.' });
            else if (p.L === 'M') {
                const m = Math.round(p.v);
                f.push({ cod: p.t, txt: EXPL_M[m] ? EXPL_M[m].charAt(0).toUpperCase() + EXPL_M[m].slice(1) : 'función auxiliar de la máquina (el simulador no hace nada con ella).' });
                if ((m === 30 || m === 2) && !fin) fin = 'M' + String(m).padStart(2, '0') + ' en la línea ' + n;
            }
            else if (p.L === 'D') f.push({ cod: p.t, txt: 'número del corrector de radio de la herramienta.' });
            else if (p.L === 'H') f.push({ cod: p.t, txt: 'número del corrector de longitud de la herramienta.' });
            else if (p.L === 'P' && gs.includes(4)) f.push({ cod: p.t, txt: 'tiempo de la pausa (en segundos o en milésimas, según el control).' });
            else if (p.L === 'P' && ciclo) f.push({ cod: p.t, txt: 'tiempo de la pausa en el fondo del taladro.' });
            else if (p.L === 'Q' && ciclo) f.push({ cod: p.t, txt: 'profundidad de cada bajada: taladra de ' + fmtE(Math.abs(p.v)) + ' en ' + fmtE(Math.abs(p.v)) + ' mm.' });
            else if (p.L === 'R' && ciclo) f.push({ cod: p.t, txt: 'plano de aproximación: hasta ' + (absoluto ? 'Z' + fmtE(p.v) : fmtE(p.v) + ' mm desde el plano inicial') + ' baja en rápido y desde ahí empieza a taladrar.' });
            else if ('ABC'.includes(p.L)) f.push({ cod: p.t, txt: 'eje giratorio (no se simula).' });
        });
        const g4142 = gs.filter(g => g === 41 || g === 42).pop();
        if (g4142 && !('X' in letras) && !('Y' in letras)) { compPendiente = g4142; ex.notas.push('La compensación empieza en el siguiente movimiento en X o Y (el de entrada).'); }
        if (gs.includes(40)) compPendiente = null;
        if (medidas) { f.push({ cod: ['X', 'Y', 'Z'].filter(k => k in letras).map(k => k + fmtE(letras[k])).join(' '), txt: 'largo (X), ancho (Y) y grosor (Z) del tablero. El simulador pone el material con estas medidas.' }); return ex; }
        if (!hayXYZ) return ex;
        if (!movsL.length && !ciclo) return ex;
        hayMov = true;
        ex.incr = !absoluto;
        const m0 = movsL[0], mU = movsL[movsL.length - 1];
        const ejes = ['X', 'Y', 'Z'].filter(k => k in letras);
        const desc = ejes.map(k => k + fmtE(letras[k])).join(' ');
        if (!gs.some(g => (g >= 0 && g <= 3) || [73, 81, 82, 83, 85, 86, 89].includes(g))) {
            if (ciclo) f.push({ cod: '', txt: 'Sin G de movimiento y con el ciclo G' + ciclo + ' activo: hace otro taladro igual en este punto.' });
            else if (movAntes === null) f.push({ cod: '', txt: 'Sin G de movimiento y sin ninguno antes: el simulador lo toma como G0 (rápido).' });
            else f.push({ cod: '', txt: 'Sin G de movimiento: sigue valiendo el último, G' + movAntes + ' (' + ['rápido', 'recta', 'arco horario', 'arco antihorario'][movAntes] + ').' });
        }
        if (!absoluto && !gs.includes(91)) f.push({ cod: '', txt: 'Sigue en G91: cada número es lo que se mueve la fresa, no el punto al que va.' });
        if (ciclo) {
            if (!movsL.length) return ex;
            const zFondo = Math.min(...movsL.map(m => m.z)), mC = movsL.find(m => m.tipo === 'corte'), zR = mC ? mC.fromZ : mU.z;
            f.push({ cod: desc, txt: 'el punto del taladro' + ('Z' in letras ? ' y su profundidad' : '') + '.' });
            ex.resultado = 'Taladra en ' + ptE(mU.x, mU.y) + ': va en rápido hasta encima, baja en rápido hasta Z' + fmtE(zR) + ', taladra hasta Z' + fmtE(zFondo) + ' (' + alturaE(zFondo) + ') y sale hasta Z' + fmtE(mU.z) + '.';
            if (!absoluto) ex.abs = ptE(mU.x, mU.y);
            return ex;
        }
        const zIni = m0.fromZ;
        if (polar) f.push({ cod: desc, txt: 'en polares: radio ' + ('X' in letras ? fmtE(letras.X) : '(el mismo)') + ' y ángulo ' + ('Y' in letras ? fmtE(letras.Y) + '°' : '(el mismo)') + '.' });
        else if (absoluto) {
            const xy = ejes.filter(k => k !== 'Z');
            if (xy.length) f.push({ cod: xy.map(k => k + fmtE(letras[k])).join(' '), txt: 'va al punto ' + xy.map(k => k + fmtE(letras[k])).join(' ') + ', medido desde el cero pieza.' });
            if ('Z' in letras) {
                const z = letras.Z * unidad;
                f.push({ cod: 'Z' + fmtE(letras.Z), txt: (Math.abs(z - zIni) < 1e-9 ? 'se queda ' : z < zIni ? 'baja hasta quedar ' : 'sube hasta quedar ') + alturaE(z) + '.' });
            }
        } else {
            const dir = { X: ['hacia la derecha', 'hacia la izquierda'], Y: ['hacia arriba (en la planta)', 'hacia abajo (en la planta)'], Z: ['sube', 'baja'] };
            ejes.forEach(k => {
                const v = letras[k];
                if (Math.abs(v) < 1e-9) f.push({ cod: k + '0', txt: 'no se mueve en ' + k + '.' });
                else if (k === 'Z') f.push({ cod: k + fmtE(v), txt: (v > 0 ? 'sube ' : 'baja ') + fmtE(Math.abs(v)) + ' mm desde donde está.' });
                else f.push({ cod: k + fmtE(v), txt: 'se mueve ' + fmtE(Math.abs(v)) + ' mm ' + dir[k][v > 0 ? 0 : 1] + '.' });
            });
        }
        // Arcos: centro, radio y grados que recorre
        if (m0.arcoSinCentro) ex.notas.push('Al arco le falta el centro (I J) o el radio (R): el simulador lo hace como una recta.');
        else if (m0.arco) {
            let e = null; try { e = entidadDeMovimiento(m0); } catch (err) {}
            if ('I' in letras || 'J' in letras) {
                const I = letras.I || 0, J = letras.J || 0;
                f.push({ cod: 'I' + fmtE(I) + ' J' + fmtE(J), txt: 'dónde está el centro del arco, contado desde el punto de partida (X' + fmtE(m0.fromX) + ' Y' + fmtE(m0.fromY) + '): ' +
                    fmtE(m0.fromX) + (I < 0 ? ' − ' : ' + ') + fmtE(Math.abs(I)) + ' = ' + fmtE(m0.fromX + I * unidad) + ' en X y ' + fmtE(m0.fromY) + (J < 0 ? ' − ' : ' + ') + fmtE(Math.abs(J)) + ' = ' + fmtE(m0.fromY + J * unidad) + ' en Y. Se cuenta así también en G90.' });
            } else if ('R' in letras) {
                f.push({ cod: 'R' + fmtE(letras.R), txt: 'radio del arco: ' + fmtE(Math.abs(letras.R)) + ' mm. ' + (letras.R >= 0 ? 'R positivo: de los dos arcos posibles, el corto (180° o menos).' : 'R negativo: de los dos arcos posibles, el largo (más de 180°).') });
            }
            if (e) {
                const grados = Math.abs(e.d) * 180 / Math.PI;
                const completo = Math.abs(m0.x - m0.fromX) < 1e-6 && Math.abs(m0.y - m0.fromY) < 1e-6;
                ex.notas.push((completo ? 'Círculo completo' : 'Arco') + ' de radio ' + fmtE(e.R) + ' con el centro en ' + ptE(e.cx, e.cy) + (completo ? '.' : ': recorre ' + fmtE(grados) + '°.'));
                if (completo) ex.notas.push('Un círculo entero en una sola línea no lo aceptan todos los controles: es más seguro hacerlo en dos semicírculos.');
            }
        }
        const tipo = movsL.some(m => m.tipo === 'corte') ? 'cortando' : 'en rápido';
        const ini = ptE(m0.fromX, m0.fromY, m0.fromZ), finP = ptE(mU.x, mU.y, mU.z);
        ex.resultado = ini === finP ? 'La fresa no cambia de sitio: sigue en ' + finP + '.' : 'La fresa va ' + tipo + ' de ' + ini + ' a ' + finP + '.';
        if (!absoluto && !polar) {
            const fin3 = { X: mU.x, Y: mU.y, Z: mU.z };
            ex.sumas = ejes.map(k => { const d = letras[k] * unidad, a = fin3[k] - d; return k + ': ' + fmtE(a) + (d < 0 ? ' − ' : ' + ') + fmtE(Math.abs(d)) + ' = ' + fmtE(fin3[k]); });
            ex.abs = ejes.map(k => k + fmtE(fin3[k])).join(' ');
        }
        if (compPendiente && (('X' in letras) || ('Y' in letras)) && !g4142) { ex.notas.push('Es el movimiento de entrada de la compensación G' + compPendiente + ': la fresa se va colocando a un lado del contorno mientras se mueve.'); compPendiente = null; }
        if (g4142 && (('X' in letras) || ('Y' in letras))) ex.notas.push('Es el movimiento de entrada de la compensación: la fresa se va colocando a un lado del contorno mientras se mueve.');
        if (gs.includes(40) && movsL.some(m => m.comp === 40)) ex.notas.push('Es el movimiento de salida de la compensación: la fresa vuelve a ir con su centro por el punto escrito.');
        return ex;
    });
}

let explicaciones = [], ultimaRevision = [];
let verExplicacion = true, verAbsolutas = true;
try { verExplicacion = localStorage.getItem('sim3d_explicar') !== '0'; verAbsolutas = localStorage.getItem('sim3d_absG91') !== '0'; } catch (e) {}

// 📍 Al lado de cada línea en G91, el punto absoluto en el que queda la fresa
function anotarAbsolutas() {
    // Con líneas en G91, el panel de código se ensancha (si es estrecho) para que se vea la posición absoluta
    if (verAbsolutas && explicaciones.some(e => e && e.abs)) {
        const panel = document.getElementById('panelCodigo'), w = Math.min(440, window.innerWidth * 0.45);
        if (panel && !panel.classList.contains('oculto') && panel.getBoundingClientRect().width < w - 1) { panel.style.width = w + 'px'; if (typeof onResizeViewport === 'function') onResizeViewport(); }
    }
    lineasCodigoEls.forEach((el, n) => {
        if (!el) return;
        const viejo = el.querySelector('.abs-g91'); if (viejo) viejo.remove();
        const e = explicaciones[n - 1];
        if (!verAbsolutas || !e || !e.abs) return;
        const s = document.createElement('span');
        s.className = 'abs-g91';
        s.textContent = '→ ' + e.abs + '  ';
        s.title = 'En G91 cada número es lo que se mueve la fresa. Aquí queda, en absolutas (desde el cero pieza), en ' + e.abs;
        const txt = el.querySelector('.txt'), com = txt && txt.querySelector('.t-com');
        if (com) txt.insertBefore(s, com); else (txt || el).appendChild(s);
    });
}

function actualizarExplicacion(n) {
    const caja = document.getElementById('panelExplicar');
    if (!caja) return;
    caja.classList.toggle('oculto', !verExplicacion || editando);
    if (!verExplicacion) return;
    const cuerpo = document.getElementById('cuerpoExplicar'), cab = document.getElementById('cabExplicar');
    const e = n ? explicaciones[n - 1] : null;
    if (!e) { cab.textContent = '💬 Qué hace cada línea'; cuerpo.innerHTML = '<p class="ex-vacio">Haz clic en una línea o avanza paso a paso (▶|) y aquí verás qué hace, explicado palabra por palabra.</p>'; return; }
    const lineaTxt = (textoPrograma.split(/\r?\n/)[n - 1] || '').trim();
    cab.textContent = '💬 Línea ' + n;
    let h = '<div class="ex-codigo">' + colorearLinea(lineaTxt) + '</div><ul>';
    e.frases.forEach(fr => { h += '<li>' + (fr.cod ? '<b>' + escaparHtml(fr.cod) + '</b> ' : '') + escaparHtml(fr.txt.charAt(0).toUpperCase() + fr.txt.slice(1)) + '</li>'; });
    h += '</ul>';
    if (e.sumas && e.sumas.length) h += '<div class="ex-sumas" title="En G91 se suma lo que se mueve a donde estaba la fresa"><b>📍 Dónde queda (en absolutas):</b> ' + e.sumas.map(escaparHtml).join(' · ') + '</div>';
    if (e.resultado) h += '<div class="ex-res">' + escaparHtml(e.resultado) + '</div>';
    e.notas.forEach(t => { h += '<div class="ex-nota">' + escaparHtml(t) + '</div>'; });
    ultimaRevision.filter(r => r.linea === n).forEach(r => { h += '<div class="ex-rev ' + r.nivel + '">' + (r.nivel === 'error' ? '⛔ ' : '⚠️ ') + escaparHtml(r.msg) + '</div>'; });
    cuerpo.innerHTML = h;
}

function toggleExplicar() {
    verExplicacion = !verExplicacion;
    try { localStorage.setItem('sim3d_explicar', verExplicacion ? '1' : '0'); } catch (e) {}
    document.getElementById('btnExplicar').classList.toggle('activo', verExplicacion);
    actualizarExplicacion(lineaResaltada);
}
function toggleAbsolutas() {
    verAbsolutas = !verAbsolutas;
    try { localStorage.setItem('sim3d_absG91', verAbsolutas ? '1' : '0'); } catch (e) {}
    document.getElementById('btnAbsolutas').classList.toggle('activo', verAbsolutas);
    anotarAbsolutas();
}
