// ── Informe de entrega: código de comprobación (común al Simulador y al Calcador / Corrector) ──
// SHA-256 sin bibliotecas (el navegador solo da crypto.subtle en contextos seguros, y con file:// no siempre)
function sha256Hex(texto) {
    const rr = (v, n) => (v >>> n) | (v << (32 - n));
    const H = [], K = []; let primos = 0;
    for (let c = 2; primos < 64; c++) {
        let es = true; for (let d = 2; d * d <= c; d++) if (c % d === 0) { es = false; break; }
        if (!es) continue;
        if (primos < 8) H[primos] = (Math.pow(c, 1 / 2) * 4294967296) | 0;
        K[primos++] = (Math.pow(c, 1 / 3) * 4294967296) | 0;
    }
    const m = new TextEncoder().encode(String(texto)), L = m.length, n = ((L + 9 + 63) >> 6) << 6;
    const b = new Uint8Array(n); b.set(m); b[L] = 0x80;
    const bits = L * 8; b[n - 4] = bits >>> 24; b[n - 3] = bits >>> 16; b[n - 2] = bits >>> 8; b[n - 1] = bits; b[n - 5] = Math.floor(bits / 4294967296);
    const w = new Int32Array(64);
    for (let o = 0; o < n; o += 64) {
        for (let i = 0; i < 16; i++) w[i] = (b[o + 4 * i] << 24) | (b[o + 4 * i + 1] << 16) | (b[o + 4 * i + 2] << 8) | b[o + 4 * i + 3];
        for (let i = 16; i < 64; i++) {
            const s0 = rr(w[i - 15], 7) ^ rr(w[i - 15], 18) ^ (w[i - 15] >>> 3), s1 = rr(w[i - 2], 17) ^ rr(w[i - 2], 19) ^ (w[i - 2] >>> 10);
            w[i] = (w[i - 16] + s0 + w[i - 7] + s1) | 0;
        }
        let [a, bb, c, d, e, f, g, h] = H;
        for (let i = 0; i < 64; i++) {
            const t1 = (h + (rr(e, 6) ^ rr(e, 11) ^ rr(e, 25)) + ((e & f) ^ (~e & g)) + K[i] + w[i]) | 0;
            const t2 = ((rr(a, 2) ^ rr(a, 13) ^ rr(a, 22)) + ((a & bb) ^ (a & c) ^ (bb & c))) | 0;
            h = g; g = f; f = e; e = (d + t1) | 0; d = c; c = bb; bb = a; a = (t1 + t2) | 0;
        }
        H[0] = (H[0] + a) | 0; H[1] = (H[1] + bb) | 0; H[2] = (H[2] + c) | 0; H[3] = (H[3] + d) | 0;
        H[4] = (H[4] + e) | 0; H[5] = (H[5] + f) | 0; H[6] = (H[6] + g) | 0; H[7] = (H[7] + h) | 0;
    }
    return H.map(v => (v >>> 0).toString(16).padStart(8, '0')).join('');
}
// El programa se compara sin tener en cuenta los finales de línea ni los espacios del final
const normalizarPrograma = t => String(t || '').replace(/\r\n?/g, '\n').split('\n').map(l => l.replace(/\s+$/, '')).join('\n').replace(/\n+$/, '');
// Código de comprobación: resume el programa y lo que dice el informe. Si se cambia algo (el programa, el nombre,
// la fecha o el resultado), el código ya no coincide. Lo calculan igual el Simulador (al crear el informe) y el
// Corrector (al leerlo).
function codigoInforme(d) {
    const base = JSON.stringify([d.v || 1, d.alumno || '', d.grupo || '', d.ejercicio || '', d.archivo || '', d.fecha || '',
        sha256Hex(normalizarPrograma(d.programa)), d.errores | 0, d.avisos | 0, d.plano ? [d.plano.pc, d.plano.mal] : null, 'SuiteCNC']);
    return sha256Hex(base).slice(0, 12).toUpperCase().replace(/(.{4})(?=.)/g, '$1-');
}
const huellaPrograma = t => sha256Hex(normalizarPrograma(t)).slice(0, 8).toUpperCase();
// Datos que el Simulador guarda dentro del PDF (/SuiteCNC en la información del documento, en base64)
function leerInformePDF(bytes) {
    let s = ''; const u = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
    for (let i = 0; i < u.length; i += 32768) s += String.fromCharCode.apply(null, u.subarray(i, i + 32768));
    const m = /\/SuiteCNC\s*\(([A-Za-z0-9+/=\s]+)\)/.exec(s); if (!m) return null;
    try {
        const bin = atob(m[1].replace(/\s+/g, '')), b = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) b[i] = bin.charCodeAt(i);
        const d = JSON.parse(new TextDecoder('utf-8').decode(b));
        if (!d || typeof d.programa !== 'string') return null;
        d.valido = codigoInforme(d) === d.codigo;
        return d;
    } catch (e) { return null; }
}
