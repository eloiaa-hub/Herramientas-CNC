// ── 📝 Cuestionario para Aules (Moodle XML) ──────────────────────────────────────────────────────────
// Preguntas sobre el ejercicio abierto (coordenadas G90, G91 y polares, centro I J, radio R, G2/G3, G41/G42), cada
// una en varias variantes de la pieza (las de 🎲 Variantes): en Aules, una «pregunta aleatoria» de cada subcategoría
// da a cada alumno una variante distinta. Las respuestas salen de la misma tabla de coordenadas que la solución.
const cuestCfg = { n:4, tol:'0.01', g90:2, g91:2, polar:1, ij:1, r:0, g2g3:1, comp:1 };
let cuestGen = null;
const CUEST_TIPOS = [
    ['g90', 'Coordenadas absolutas (G90) de un punto'], ['g91', 'Coordenadas incrementales (G91) de un punto'], ['polar', 'Coordenadas polares (radio y ángulo) de un punto'],
    ['ij', 'Centro de un arco: I y J'], ['r', 'Radio R de un arco (con signo)'], ['g2g3', '¿G2 o G3? (sentido de un arco)'], ['comp', '¿G41 o G42? (compensación de un contorno)']];
// La tabla de coordenadas (la de 📋 Solución) en el modo pedido, sin tocar lo que el profesor tiene elegido en ella
function tablaCuest(prog, arco) {
    const ids = ['tbCont', 'tbProg', 'tbArco', 'tbOrigen', 'tbDec', 'tbAbs'], g = id => document.getElementById(id);
    const antes = ids.map(id => g(id).type === 'checkbox' ? g(id).checked : g(id).value), opc = g('tbCont').innerHTML, ov = tablaOverrides;
    try {
        g('tbCont').innerHTML = '<option value="todos">Todos</option>'; g('tbCont').value = 'todos';
        g('tbProg').value = prog; g('tbArco').value = arco; g('tbOrigen').value = 'dibujo'; g('tbDec').value = '3'; g('tbAbs').checked = false; tablaOverrides = new Map();
        return datosTabla();
    } finally {
        g('tbCont').innerHTML = opc; tablaOverrides = ov;
        ids.forEach((id, k) => { if (g(id).type === 'checkbox') g(id).checked = antes[k]; else g(id).value = antes[k]; });
    }
}
// Puntos (P1, P2…), arcos (A1, A2…) y contornos del estado actual, con sus soluciones
function modeloCuest() {
    const tipos = tiposResueltos(), d90 = tablaCuest('g90', 'ij'), d91 = tablaCuest('g91', 'ij'), dPol = tablaCuest('polar', 'r'), dR = tablaCuest('g90', 'r');
    const puntos = [], arcos = [], conts = [];
    d90.grupos.forEach((g, gi) => {
        const c = contornos[g.ci]; if (c.texto || c.deTexto) return;
        const ts = tramos(c), pt = k => k === 0 ? c.pts[0] : ts[k - 1].p2, nIni = puntos.length;
        let pAnt = null;
        g.filas.forEach((r, k) => {
            const cierre = c.cerrado && k > 0 && k === g.filas.length - 1 && Math.hypot(pt(k).x - c.pts[0].x, pt(k).y - c.pts[0].y) < 1e-6;
            const r91 = d91.grupos[gi].filas[k], rP = dPol.grupos[gi].filas[k], rR = dR.grupos[gi].filas[k];
            let P;
            if (cierre) P = puntos[nIni];
            else { P = { n:puntos.length + 1, p:pt(k), abs:{ x:+r.x, y:+r.y }, pol:{ r:+rP.x, a:+rP.y }, ci:g.ci, k }; puntos.push(P); }
            if (k > 0) {
                if (r91.modo === 'G91' && !cierre) P.rel = { x:+r91.x, y:+r91.y, desde:pAnt };
                if (r.mov === 'G2' || r.mov === 'G3') {
                    const t = ts[k - 1], a = arcoDeBulge(t.p1, t.p2, t.b);
                    arcos.push({ n:arcos.length + 1, mov:r.mov, i:+r.i, j:+r.j, r:+rR.r, desde:pAnt, hasta:P, medio:{ x:a.c.x + a.r * Math.cos(a.a1 + a.theta / 2), y:a.c.y + a.r * Math.sin(a.a1 + a.theta / 2) }, c:a.c, radio:a.r, grande:Math.abs(a.theta) > Math.PI + 1e-9, ci:g.ci });
                }
            }
            pAnt = P;
        });
        if (c.cerrado && ts.length) {
            const pol = muestrearContorno(c); let A = 0; for (let i = 0, j = pol.length - 1; i < pol.length; j = i++) A += (pol[j].x + pol[i].x) * (pol[j].y - pol[i].y);
            const ccw = A < 0, tipo = tipos[g.ci] === 'interior' ? 'interior' : 'exterior';   // (A con este orden de productos: negativa = antihorario)
            conts.push({ ci:g.ci, tipo, ccw, debe: tipo === 'interior' ? (ccw ? 41 : 42) : (ccw ? 42 : 41), entrada:puntos[nIni], p0:c.pts[0], t0:ts[0] });
        }
    });
    return { puntos, arcos, conts };
}
// Qué puntos, arcos y contornos se preguntan (los mismos en todas las variantes: la pieza es la misma)
function elegirCuest(M) {
    const reparte = (lista, n) => { if (n <= 0 || !lista.length) return []; if (n >= lista.length) return lista.slice(); const out = []; for (let i = 0; i < n; i++) out.push(lista[Math.floor((i + 0.5) * lista.length / n)]); return [...new Set(out)]; };
    const nz = v => Math.abs(v) > 1e-9;
    const pref = (l, f) => { const a = l.filter(f); return a.length >= 1 ? a : l; };
    return {
        g90: reparte(pref(M.puntos.filter(p => p.n > 1), p => nz(p.abs.x) && nz(p.abs.y)), cuestCfg.g90).map(p => p.n),
        g91: reparte(pref(M.puntos.filter(p => p.rel), p => nz(p.rel.x) && nz(p.rel.y)), cuestCfg.g91).map(p => p.n),
        polar: reparte(pref(M.puntos.filter(p => p.pol.r > 1e-6), p => Math.abs(p.pol.a % 90) > 1e-6), cuestCfg.polar).map(p => p.n),
        ij: reparte(pref(M.arcos, a => nz(a.i) && nz(a.j)), cuestCfg.ij).map(a => a.n),
        r: reparte(pref(M.arcos, a => a.grande), cuestCfg.r).map(a => a.n),
        g2g3: reparte(M.arcos, cuestCfg.g2g3).map(a => a.n),
        comp: reparte(M.conts.filter(c => c.tipo === 'exterior').concat(M.conts.filter(c => c.tipo === 'interior')).sort((a, b) => (a.tipo === b.tipo ? 0 : a.tipo === 'exterior' ? -1 : 1)), cuestCfg.comp).map(c => c.ci)
    };
}
// El plano (con sus cotas) y, encima, el cero pieza, los puntos, los arcos y el sentido de cada contorno
function svgCuest(M) {
    const chkC = document.getElementById('chkCotasSVG'), chkO = document.getElementById('chkOrigen'), aC = chkC.checked, aO = chkO.checked;
    let svg;
    try { chkC.checked = true; chkO.checked = false; svg = exportarSVG(true, true) || ''; } finally { chkC.checked = aC; chkO.checked = aO; }
    const vb = /viewBox="([-\d.]+) ([-\d.]+) ([\d.]+) ([\d.]+)"/.exec(svg); if (!vb) return svg;
    let [x0, y0, w, h] = vb.slice(1).map(Number);
    const f = v => (+v).toFixed(3), tam = Math.max(w, h), fs = Math.max(2.4, Math.min(9, tam / 34)), S = p => ({ x:p.x, y:-p.y });
    const bbP = bboxPts(M.puntos.map(p => p.p)), cx = (bbP.x0 + bbP.x1) / 2, cy = (bbP.y0 + bbP.y1) / 2;
    let g = `  <g id="CUESTIONARIO" font-family="Arial, Helvetica, sans-serif" font-weight="bold">\n`;
    const extra = [];
    const etiqueta = (p, t, col, dir) => { const L = Math.hypot(dir.x, dir.y) || 1, q = { x:p.x + dir.x / L * fs * 1.05, y:p.y + dir.y / L * fs * 1.05 }, s = S(q);
        extra.push({ x:q.x - fs, y:q.y - fs }, { x:q.x + fs, y:q.y + fs });
        return `    <text x="${f(s.x)}" y="${f(s.y)}" font-size="${f(fs)}" fill="${col}" stroke="#ffffff" stroke-width="${f(fs * 0.22)}" paint-order="stroke" text-anchor="middle" dominant-baseline="central">${t}</text>\n`; };
    // sentido de cada contorno cerrado: una flecha en la mitad de su primer tramo
    M.conts.forEach(c => { const t = c.t0; let p, tg;
        if (!t.b) { p = { x:(t.p1.x + t.p2.x) / 2, y:(t.p1.y + t.p2.y) / 2 }; const L = Math.hypot(t.p2.x - t.p1.x, t.p2.y - t.p1.y) || 1; tg = { x:(t.p2.x - t.p1.x) / L, y:(t.p2.y - t.p1.y) / L }; }
        else { const a = arcoDeBulge(t.p1, t.p2, t.b), am = a.a1 + a.theta / 2, s = Math.sign(a.theta); p = { x:a.c.x + a.r * Math.cos(am), y:a.c.y + a.r * Math.sin(am) }; tg = { x:-Math.sin(am) * s, y:Math.cos(am) * s }; }
        const n = { x:-tg.y, y:tg.x }, L = fs * 0.9, b = { x:p.x - tg.x * L, y:p.y - tg.y * L }, pts = [p, { x:b.x + n.x * L * 0.45, y:b.y + n.y * L * 0.45 }, { x:b.x - n.x * L * 0.45, y:b.y - n.y * L * 0.45 }].map(S);
        g += `    <polygon points="${pts.map(q => f(q.x) + ',' + f(q.y)).join(' ')}" fill="#7b1fa2"/>\n`; });
    M.arcos.forEach(a => { const d = { x:a.medio.x - a.c.x, y:a.medio.y - a.c.y }; g += etiqueta(a.medio, 'A' + a.n, '#b35a10', d); });
    M.puntos.forEach(P => { const s = S(P.p), d = { x:P.p.x - cx, y:P.p.y - cy };
        g += `    <circle cx="${f(s.x)}" cy="${f(s.y)}" r="${f(fs * 0.17)}" fill="#c62828"/>\n` + etiqueta(P.p, 'P' + P.n, '#c62828', Math.hypot(d.x, d.y) > 1e-9 ? d : { x:1, y:1 }); });
    // cero pieza (X0 Y0)
    const r0 = fs * 0.55; extra.push({ x:-r0 * 2, y:-r0 * 2 }, { x:r0 * 2, y:r0 * 2 });
    g += `    <g stroke="#111" stroke-width="${f(fs * 0.08)}"><circle cx="0" cy="0" r="${f(r0)}" fill="#fff"/><path d="M0 0 L${f(r0)} 0 A${f(r0)} ${f(r0)} 0 0 0 0 ${f(-r0)} Z M0 0 L${f(-r0)} 0 A${f(r0)} ${f(r0)} 0 0 0 0 ${f(r0)} Z" fill="#111"/><line x1="${f(-r0 * 1.7)}" y1="0" x2="${f(r0 * 1.7)}" y2="0"/><line x1="0" y1="${f(-r0 * 1.7)}" x2="0" y2="${f(r0 * 1.7)}"/></g>\n`;
    g += `    <text x="${f(r0 * 1.2)}" y="${f(r0 * 2.1)}" font-size="${f(fs * 0.8)}" fill="#111" stroke="#fff" stroke-width="${f(fs * 0.2)}" paint-order="stroke">X0 Y0</text>\n  </g>\n`;
    extra.push({ x:r0 * 1.2 + fs * 3, y:-r0 * 2.6 });
    // el dibujo crece para que quepan las etiquetas
    const xs = extra.map(q => q.x), ys = extra.map(q => -q.y), m = fs * 0.4;
    const nx0 = Math.min(x0, Math.min(...xs) - m), ny0 = Math.min(y0, Math.min(...ys) - m), nx1 = Math.max(x0 + w, Math.max(...xs) + m), ny1 = Math.max(y0 + h, Math.max(...ys) + m);
    return svg.replace(vb[0], `viewBox="${f(nx0)} ${f(ny0)} ${f(nx1 - nx0)} ${f(ny1 - ny0)}"`).replace(/width="[\d.]+mm" height="[\d.]+mm"/, `width="${f(nx1 - nx0)}mm" height="${f(ny1 - ny0)}mm"`)
              .replace('</svg>', `  <rect x="${f(nx0)}" y="${f(ny0)}" width="${f(nx1 - nx0)}" height="${f(ny1 - ny0)}" fill="none"/>\n` + g + '</svg>').replace(/(<svg[^>]*>)/, `$1\n  <rect x="${f(nx0)}" y="${f(ny0)}" width="${f(nx1 - nx0)}" height="${f(ny1 - ny0)}" fill="#ffffff"/>`);
}
function pngDeSVG(svg, maxW = 820, maxH = 600) {
    return new Promise((ok, mal) => {
        const vb = /viewBox="[-\d.]+ [-\d.]+ ([\d.]+) ([\d.]+)"/.exec(svg), W = vb ? +vb[1] : 100, H = vb ? +vb[2] : 100, k = Math.min(maxW / W, maxH / H);
        const img = new Image(), url = URL.createObjectURL(new Blob([svg], { type:'image/svg+xml' }));
        img.onload = () => { const cv = document.createElement('canvas'); cv.width = Math.round(W * k); cv.height = Math.round(H * k);
            const g = cv.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, cv.width, cv.height); g.drawImage(img, 0, 0, cv.width, cv.height); URL.revokeObjectURL(url);
            ok({ b64:cv.toDataURL('image/png').split(',')[1], w:cv.width, h:cv.height }); };
        img.onerror = () => { URL.revokeObjectURL(url); mal(new Error('no se ha podido dibujar el plano')); };
        img.src = url;
    });
}
// Las preguntas de una variante (texto, respuestas en formato Cloze y explicación)
function preguntasCuest(M, sel, tol) {
    const fn = v => { const t = (+(+v).toFixed(3)).toString(); return t === '-0' ? '0' : t; };
    const num = (v, t = tol, alt) => `{1:NUMERICAL:=${fn(v)}:${t}${alt !== undefined ? `~=${fn(alt)}:${t}` : ''}}`;
    const out = [], P = n => M.puntos[n - 1], A = n => M.arcos[n - 1];
    const dec = '<p style="font-size:90%;color:#555">Escribe los decimales con punto (por ejemplo, 12.5). Tolerancia: ±' + String(tol).replace('.', ',') + ' mm.</p>';
    sel.g90.forEach(n => { const p = P(n); if (!p) return; out.push({ clave:`P${n} en G90`, txt:`<p>Con el cero pieza X0 Y0 del plano, escribe las coordenadas <b>absolutas (G90)</b> del punto <b>P${n}</b>.</p><p>X = ${num(p.abs.x)} &nbsp; Y = ${num(p.abs.y)}</p>${dec}`,
        sol:`P${n}: X${fn(p.abs.x)} Y${fn(p.abs.y)} (desde el cero pieza).` }); });
    sel.g91.forEach(n => { const p = P(n); if (!p || !p.rel) return; const a = p.rel.desde; out.push({ clave:`P${n} en G91`, txt:`<p>La fresa está en <b>P${a.n}</b> y va a <b>P${n}</b>. Escribe las coordenadas <b>incrementales (G91)</b> de ese movimiento: cuánto se desplaza en X y en Y desde P${a.n}.</p><p>X = ${num(p.rel.x)} &nbsp; Y = ${num(p.rel.y)}</p>${dec}`,
        sol:`P${a.n} = X${fn(a.abs.x)} Y${fn(a.abs.y)} y P${n} = X${fn(p.abs.x)} Y${fn(p.abs.y)}: en G91, X${fn(p.rel.x)} Y${fn(p.rel.y)} (lo que cambia de un punto al otro).` }); });
    sel.polar.forEach(n => { const p = P(n); if (!p) return; const alt = p.pol.a < 0 ? p.pol.a + 360 : undefined, tolA = Math.max(0.05, +tol * 5);
        out.push({ clave:`P${n} en polares`, txt:`<p>Escribe las coordenadas <b>polares (G16)</b> del punto <b>P${n}</b> respecto al cero pieza X0 Y0: el <b>radio</b> (la distancia al cero pieza) y el <b>ángulo</b> en grados, medido desde el eje X positivo y en sentido antihorario.</p><p>Radio (X) = ${num(p.pol.r)} &nbsp; Ángulo (Y) = ${num(p.pol.a, String(+tolA.toFixed(3)), alt)} °</p>${dec}`,
        sol:`P${n} = X${fn(p.abs.x)} Y${fn(p.abs.y)} → radio √(X² + Y²) = ${fn(p.pol.r)} y ángulo ${fn(p.pol.a)}°${alt !== undefined ? ` (o ${fn(alt)}°)` : ''}.` }); });
    sel.ij.forEach(n => { const a = A(n); if (!a) return; out.push({ clave:`Arco A${n}: I J`, txt:`<p>El arco <b>A${n}</b> va de <b>P${a.desde.n}</b> a <b>P${a.hasta.n}</b>. Escribe <b>I</b> y <b>J</b>: dónde está su centro respecto a su punto de inicio, P${a.desde.n} (incremental).</p><p>I = ${num(a.i)} &nbsp; J = ${num(a.j)}</p>${dec}`,
        sol:`Centro del arco: X${fn(a.desde.abs.x + a.i)} Y${fn(a.desde.abs.y + a.j)}; inicio P${a.desde.n} = X${fn(a.desde.abs.x)} Y${fn(a.desde.abs.y)} → I${fn(a.i)} J${fn(a.j)}.` }); });
    sel.r.forEach(n => { const a = A(n); if (!a) return; out.push({ clave:`Arco A${n}: R`, txt:`<p>Para programar el arco <b>A${n}</b> (de P${a.desde.n} a P${a.hasta.n}) con <b>R</b> en lugar de I J, ¿qué valor lleva R? Recuerda: si el arco es de más de 180°, R se escribe en negativo.</p><p>R = ${num(a.r)}</p>${dec}`,
        sol:`Radio ${fn(a.radio)} mm; el arco es de ${a.grande ? 'más' : 'menos'} de 180°, así que R${fn(a.r)}.` }); });
    sel.g2g3.forEach(n => { const a = A(n); if (!a) return; const ok = a.mov === 'G2';
        out.push({ clave:`Arco A${n}: G2 o G3`, txt:`<p>La fresa recorre el arco <b>A${n}</b> de <b>P${a.desde.n}</b> a <b>P${a.hasta.n}</b>. ¿Qué función lo programa?</p><p>{1:MULTICHOICE_V:${ok ? '=' : ''}G2 (horario)#${ok ? '¡Correcto!' : 'No, de P' + a.desde.n + ' a P' + a.hasta.n + ' el arco gira en sentido antihorario.'}~${ok ? '' : '='}G3 (antihorario)#${ok ? 'No, de P' + a.desde.n + ' a P' + a.hasta.n + ' el arco gira en sentido horario.' : '¡Correcto!'}}</p>`,
            sol:`De P${a.desde.n} a P${a.hasta.n}, el arco gira en sentido ${ok ? 'horario: G2' : 'antihorario: G3'}.` }); });
    sel.comp.forEach(ci => { const c = M.conts.find(x => x.ci === ci); if (!c) return; const e = c.entrada.n, ok41 = c.debe === 41;
        const exp = `El contorno es ${c.tipo === 'interior' ? 'interior (un agujero), la fresa va por dentro,' : 'exterior, la fresa va por fuera de la pieza,'} y se recorre en sentido ${c.ccw ? 'antihorario' : 'horario'}, así que la fresa queda a la ${ok41 ? 'izquierda (G41)' : 'derecha (G42)'}.`;
        out.push({ clave:`Contorno de P${e}: G41 o G42`, txt:`<p>Se mecaniza el contorno que empieza en <b>P${e}</b>, en el sentido de la flecha morada, con compensación de radio. ¿Qué función de compensación hay que activar?</p><p>{1:MULTICHOICE_V:${ok41 ? '=' : ''}G41 (fresa a la izquierda del recorrido)#${ok41 ? '¡Correcto!' : 'No. ' + exp}~${ok41 ? '' : '='}G42 (fresa a la derecha del recorrido)#${ok41 ? 'No. ' + exp : '¡Correcto!'}~G40 (sin compensación)#No, G40 anula la compensación.}</p>`,
            sol:exp }); });
    return out;
}
// Todas las variantes: modelo, preguntas y el plano en PNG
async function generarCuest() {
    const vc = { ...varCfg };
    let elegidas;
    try { varCfg.n = Math.max(1, Math.min(8, cuestCfg.n)); varCfg.aOriginal = true; elegidas = cuestCfg.n > 1 ? especificacionesVariantes().elegidas : []; } finally { Object.assign(varCfg, vc); }
    if (!elegidas.length) elegidas = [{ ex:0, ey:0, cero:'mismo', escala:1 }];
    const idem = sp => !sp.ex && !sp.ey && sp.cero === 'mismo' && sp.escala === 1;
    const conEstado = (est, fn) => { if (!est) return fn(); const g = { contornos, aux, cotasManuales, cotasAjuste };
        try { contornos = est.contornos; aux = est.aux; cotasManuales = []; cotasAjuste = {}; memoTipos = null; return fn(); }
        finally { contornos = g.contornos; aux = g.aux; cotasManuales = g.cotasManuales; cotasAjuste = g.cotasAjuste; memoTipos = null; } };
    const tol = String(Math.max(0.001, parseFloat(String(cuestCfg.tol).replace(',', '.')) || 0.01));
    let sel = null; const vars = [];
    for (let i = 0; i < elegidas.length; i++) {
        const sp = elegidas[i], est = idem(sp) ? null : transformarEstado({ contornos:JSON.parse(JSON.stringify(contornos.filter(c => c.pts.length >= 2))), aux:JSON.parse(JSON.stringify(aux)) }, sp);
        const r = conEstado(est, () => { const M = modeloCuest(); return { M, svg:svgCuest(M) }; });
        if (!sel) sel = elegirCuest(r.M);
        vars.push({ letra:String.fromCharCode(65 + i), desc:describirVariante(sp), M:r.M, svg:r.svg, preguntas:preguntasCuest(r.M, sel, tol) });
    }
    for (const v of vars) v.png = await pngDeSVG(v.svg);
    return { vars, sel, tol };
}
function xmlCuest(G) {
    const tit = (cfgHoja.titulo || nombreProyecto()).trim(), num = (cfgHoja.num || '').trim(), base = `${num ? num + ' · ' : ''}${tit}`.replace(/\//g, '-');
    const cdata = t => '<![CDATA[' + String(t).replace(/]]>/g, ']]]]><![CDATA[>') + ']]>', esc = t => String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;');
    let x = '<?xml version="1.0" encoding="UTF-8"?>\n<quiz>\n';
    const claves = G.vars[0].preguntas.map(q => q.clave);
    claves.forEach((clave, qi) => {
        x += `  <question type="category">\n    <category><text>${esc(`$course$/top/Calcador - ${base}/${String(qi + 1).padStart(2, '0')} ${clave}`)}</text></category>\n    <info format="html"><text>${esc(`${clave} · ${G.vars.length} variante${G.vars.length === 1 ? '' : 's'}: en el cuestionario, añade una pregunta aleatoria de esta categoría`)}</text></info>\n  </question>\n`;
        G.vars.forEach(v => { const q = v.preguntas[qi]; if (!q) return; const img = `plano_${v.letra}.png`;
            x += `  <question type="cloze">\n    <name><text>${esc(`${base} · ${clave} · variante ${v.letra}`)}</text></name>\n`
              + `    <questiontext format="html">\n      <text>${cdata(`<p><img src="@@PLUGINFILE@@/${img}" alt="Plano del ejercicio ${esc(tit)}" width="${v.png.w}" height="${v.png.h}" style="max-width:100%;height:auto"></p>${q.txt}`)}</text>\n      <file name="${img}" path="/" encoding="base64">${v.png.b64}</file>\n    </questiontext>\n`
              + `    <generalfeedback format="html">\n      <text>${cdata(`<p>${esc(q.sol)}</p>`)}</text>\n    </generalfeedback>\n    <penalty>0.3333333</penalty>\n    <hidden>0</hidden>\n    <idnumber></idnumber>\n  </question>\n`; });
    });
    return x + '</quiz>\n';
}
async function abrirCuestionario() {
    if (!hayPieza()) { snack('Dibuja o abre un ejercicio primero'); return; }
    const g = id => document.getElementById(id);
    g('cuN').value = cuestCfg.n; g('cuTol').value = cuestCfg.tol;
    g('cuTipos').innerHTML = CUEST_TIPOS.map(([k, t]) => `<label class="param-line var-chk" title="${t}: cuántas preguntas de este tipo (0, ninguna)">${t} <input type="number" min="0" max="6" step="1" value="${cuestCfg[k]}" data-k="${k}" style="width:48px;margin-left:auto" onchange="cambiarCuestionario()"></label>`).join('');
    g('modalCuest').classList.add('visible');
    await pintarCuestionario();
}
function cerrarCuestionario() { document.getElementById('modalCuest').classList.remove('visible'); }
async function cambiarCuestionario() {
    const g = id => document.getElementById(id);
    cuestCfg.n = Math.max(1, Math.min(8, Math.round(+g('cuN').value) || 1)); cuestCfg.tol = g('cuTol').value;
    g('cuTipos').querySelectorAll('input[data-k]').forEach(el => cuestCfg[el.dataset.k] = Math.max(0, Math.min(6, Math.round(+el.value) || 0)));
    await pintarCuestionario();
}
async function pintarCuestionario() {
    const caja = document.getElementById('cuLista'), esc = t => String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;');
    caja.innerHTML = '<p class="ctx-nota">Preparando las preguntas…</p>';
    try { cuestGen = await generarCuest(); } catch (e) { console.warn(e); cuestGen = null; caja.innerHTML = `<p class="ctx-nota">No se han podido preparar: ${esc(e.message)}</p>`; return; }
    const G = cuestGen, v = G.vars[0], nq = v.preguntas.length;
    // la vista previa: la variante A, con las respuestas a la vista
    const ver = t => t.replace(/\{1:NUMERICAL:=([^:}]+):[^}]*\}/g, '<b class="cu-sol">$1</b>').replace(/\{1:MULTICHOICE_V:([^}]*)\}/g, (_, o) => o.split('~').map(x => x.split('#')[0]).map(x => x.startsWith('=') ? `<b class="cu-sol">${x.slice(1)}</b>` : `<span class="cu-no">${x}</span>`).join(' · '));
    caja.innerHTML = !nq ? '<p class="ctx-nota">Con lo elegido no sale ninguna pregunta (¿la pieza no tiene arcos?).</p>'
        : `<div class="cu-cab"><b>${nq} pregunta${nq === 1 ? '' : 's'} × ${G.vars.length} variante${G.vars.length === 1 ? '' : 's'}</b> · ${G.vars.map(x => `<span title="${esc(x.desc)}">${x.letra}</span>`).join(' ')}</div>`
        + `<div class="cu-plano"><img src="data:image/png;base64,${v.png.b64}" alt="Plano de la variante A"><div class="ctx-nota">Variante A · ${esc(v.desc)}</div></div>`
        + v.preguntas.map((q, i) => `<div class="cu-preg"><div class="cu-tit">${i + 1}. ${esc(q.clave)}</div>${ver(q.txt).replace(/<p style="font-size:90%[^<]*<\/p>/, '')}<div class="ctx-nota">💡 ${esc(q.sol)}</div></div>`).join('');
    document.getElementById('cuDescargar').disabled = !nq;
}
async function descargarCuestionario() {
    if (!cuestGen || !cuestGen.vars[0].preguntas.length) { snack('No hay preguntas'); return; }
    const xml = xmlCuest(cuestGen);
    descargar(xml, `${nombreProyecto()} - cuestionario Moodle.xml`, 'application/xml');
    const nq = cuestGen.vars[0].preguntas.length;
    snack(`Cuestionario descargado (${(xml.length / 1048576).toLocaleString('es-ES', { maximumFractionDigits:1 })} MB): ${nq} pregunta(s) en ${cuestGen.vars.length} variante(s). En Aules: Banco de preguntas → Importar → Formato Moodle XML`);
}
