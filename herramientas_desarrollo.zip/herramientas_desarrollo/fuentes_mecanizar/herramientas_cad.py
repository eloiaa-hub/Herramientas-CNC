"""Calcador: alinear y repartir, bloquear contornos, recortar (Y) y alargar (H).
Uso: python3 herramientas_cad.py <carpeta de la suite>   (después de agrupar.py)
"""
import sys, os
AQUI = os.path.dirname(os.path.abspath(__file__))
P = os.path.join(sys.argv[1] if len(sys.argv) > 1 else '.', 'calcador.html')
s = open(P, encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    n = s.count(a); assert n == cnt, f'{n} apariciones (se esperaban {cnt}) de: {a[:100]}'
    s = s.replace(a, b)
JS = open(os.path.join(AQUI, 'herramientas_cad.js'), encoding='utf-8').read()
rep("// ── Cortar un contorno en un punto ──", JS + "\n// ── Cortar un contorno en un punto ──")

# ── bloquear: se guarda en el JSON y el contorno no se coge en el dibujo
rep("""        if (typeof c.grupo === 'string' && c.grupo.length < 80) n.grupo = c.grupo;""",
    """        if (typeof c.grupo === 'string' && c.grupo.length < 80) n.grupo = c.grupo;
        if (c.bloqueado === true) n.bloqueado = true;""")
rep("""        if (c.texto) continue;                 // los puntos de un texto no se pueden coger""",
    """        if (c.bloqueado) continue;             // un contorno bloqueado no se coge en el dibujo
        if (c.texto) continue;                 // los puntos de un texto no se pueden coger""")
rep("""    if (sel >= 0 && contornos[sel] && !contornos[sel].texto) {""", """    if (sel >= 0 && contornos[sel] && !contornos[sel].texto && !contornos[sel].bloqueado) {""")
rep("""    for (const ci of orden) {
        for (const t of tramos(contornos[ci])) {""", """    for (const ci of orden) {
        if (contornos[ci].bloqueado) continue;
        for (const t of tramos(contornos[ci])) {""")
rep("""        if (!c.cerrado) return;
        const m = muestrearContorno(c);
        if (puntoEnPoligono(q, m)) {""", """        if (!c.cerrado || c.bloqueado) return;
        const m = muestrearContorno(c);
        if (puntoEnPoligono(q, m)) {""")
rep("""        if (c.pts.length < 2) return;
        const m = muestrearContorno(c);
        let ok;""", """        if (c.pts.length < 2 || c.bloqueado) return;
        const m = muestrearContorno(c);
        let ok;""")
rep("""seleccionarVarios(contornos.map((_, i) => i), false);""", """seleccionarVarios(contornos.map((_, i) => i).filter(i => !contornos[i].bloqueado), false);""")
rep("""idsGrupo(c.grupo).forEach(j => { selSet.add(j);""", """idsGrupo(c.grupo).forEach(j => { if (contornos[j] && contornos[j].bloqueado && !selSet.has(j)) return; selSet.add(j);""")
rep("""function empujarSeleccion(dx, dy) {
    const ids = seleccionados(); if (!ids.length) return false;""", """function empujarSeleccion(dx, dy) {
    const ids = seleccionados().filter(i => !contornos[i].bloqueado); if (!ids.length) { snack('Lo seleccionado está bloqueado: desbloquéalo para moverlo'); return true; }""")
# en la lista de contornos, con su candado
rep("""            <span class="ct-name">C${i + 1}${esGrabado(c)""", """            <span class="ct-name">${c.bloqueado ? '<span title="Bloqueado: no se coge en el dibujo">🔒</span> ' : ''}C${i + 1}${esGrabado(c)""")
# panel de un contorno
rep("""            <div class="ctx-titulo">Contorno C${sel + 1}</div>""", """            <div class="ctx-titulo">Contorno C${sel + 1}</div>
            ${c.bloqueado ? `<div class="ctx-nota">🔒 <strong>Bloqueado</strong>: no se coge en el dibujo (los imanes sí lo ven).</div><button class="btn-action sec" onclick="bloquearSeleccion(false)" title="Vuelve a poder cogerse y moverse en el dibujo">🔓 Desbloquear</button>`
                          : `<button class="btn-action sec" onclick="bloquearSeleccion(true)" title="Para que no se mueva por error mientras calcas o acotas encima: no se coge en el dibujo (ni con clic, ni con recuadro, ni con Ctrl+A); los imanes sí lo ven. Se desbloquea desde la lista de contornos">🔒 Bloquear</button>`}""")
# panel de varios: alinear, repartir y bloquear
ICO = lambda d: f'<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round">{d}</svg>'
AL = [('izq', 'Alinear a la izquierda', '<path d="M4 3v18"/><rect x="7" y="6" width="11" height="4" rx="1"/><rect x="7" y="14" width="7" height="4" rx="1"/>'),
      ('centroX', 'Centrar en vertical (mismo centro en X)', '<path d="M12 3v18" stroke-dasharray="2 2"/><rect x="5" y="6" width="14" height="4" rx="1"/><rect x="8" y="14" width="8" height="4" rx="1"/>'),
      ('der', 'Alinear a la derecha', '<path d="M20 3v18"/><rect x="6" y="6" width="11" height="4" rx="1"/><rect x="10" y="14" width="7" height="4" rx="1"/>'),
      ('abajo', 'Alinear abajo', '<path d="M3 20h18"/><rect x="6" y="6" width="4" height="11" rx="1"/><rect x="14" y="10" width="4" height="7" rx="1"/>'),
      ('centroY', 'Centrar en horizontal (mismo centro en Y)', '<path d="M3 12h18" stroke-dasharray="2 2"/><rect x="6" y="5" width="4" height="14" rx="1"/><rect x="14" y="8" width="4" height="8" rx="1"/>'),
      ('arriba', 'Alinear arriba', '<path d="M3 4h18"/><rect x="6" y="7" width="4" height="11" rx="1"/><rect x="14" y="7" width="4" height="7" rx="1"/>')]
botones = ''.join(f'<button class="btn-action sec al-b" onclick="alinearSeleccion(\'{k}\')" title="{t}">{ICO(d)}</button>' for k, t, d in AL)
rep("""        <button class="btn-action danger" id="pDelMulti">✕ Borrar selección</button>""",
f"""        <div class="ctx-nota" style="margin-top:4px"><strong>Alinear</strong> las piezas (cada grupo o texto, como una), respecto al conjunto</div>
        <div class="btn-row al-fila">{botones}</div>
        <div class="btn-row rep-fila">
            <button class="btn-action sec" onclick="repartirSeleccion('x')" title="Reparte las piezas en horizontal: la misma separación entre una y otra (la primera y la última no se mueven)">Repartir ↔</button>
            <button class="btn-action sec" onclick="repartirSeleccion('y')" title="Reparte las piezas en vertical: la misma separación entre una y otra (la primera y la última no se mueven)">Repartir ↕</button>
        </div>
        <div class="btn-row">
            <button class="btn-action sec" onclick="bloquearSeleccion(true)" title="No se cogen en el dibujo (ni con clic, ni con recuadro, ni con Ctrl+A); los imanes sí los ven. Se desbloquean desde la lista de contornos">🔒 Bloquear</button>
            ${{ids.some(i => contornos[i].bloqueado) ? `<button class="btn-action sec" onclick="bloquearSeleccion(false)">🔓 Desbloquear</button>` : ''}}
        </div>
        <button class="btn-action danger" id="pDelMulti">✕ Borrar selección</button>""")
rep("""    .mv-inf { font-size:12px; cursor:help; }""", """    .al-fila { flex-wrap: nowrap; gap: 4px; } .al-fila .al-b { flex: 1; padding: 5px 0; min-width: 0; display: flex; justify-content: center; } .rep-fila { flex-wrap: nowrap; gap: 4px; } .rep-fila .btn-action { flex: 1; min-width: 0; padding: 6px 2px; white-space: nowrap; }
    .mv-inf { font-size:12px; cursor:help; }""")
# candado en el dibujo
rep("""    dibujarGruposSel();
    dibujarPrevia(V);""", """    dibujarGruposSel();
    dibujarBloqueados();
    dibujarPrevia(V);""")
rep("""function dibujarGruposSel() {""", """function dibujarBloqueados() {
    if (VISOR) return;
    const ids = contornos.map((c, i) => c.bloqueado && c.pts.length >= 2 ? i : -1).filter(i => i >= 0); if (!ids.length) return;
    ctx.save(); ctx.font = '12px system-ui, sans-serif';
    ids.forEach(i => { const bb = bboxSeleccion([i]), a = aPantalla({ x:bb.x0, y:bb.y1 }); ctx.globalAlpha = 0.85; ctx.fillText('🔒', a.x - 16, a.y - 2); });
    ctx.restore();
}
function dibujarGruposSel() {""")

# ── recortar y alargar: herramientas de la barra
rep("""                <div class="tool-btn" data-h="equidistante" data-tip="Equidistante (Q)">""",
    """                <div class="tool-btn" data-h="recortar" data-tip="Recortar: clic en el trozo que sobra, entre dos cruces con otros contornos o auxiliares (Y)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M3 12h5M16 12h5"/><path d="M8 12h8" stroke-dasharray="2 2" opacity=".55"/><path d="M8 4v16M16 4v16"/><path d="M10.5 9.5l3 5M13.5 9.5l-3 5" stroke="#e0368c"/></svg></div>
                <div class="tool-btn" data-h="alargar" data-tip="Alargar: clic junto al extremo de un trazo abierto; se prolonga hasta el primer contorno o auxiliar (H)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M20 3v18"/><path d="M3 12h7"/><path d="M10 12h8" stroke-dasharray="2.5 2"/><path d="M15 9l3 3-3 3"/></svg></div>
                <div class="tool-btn" data-h="equidistante" data-tip="Equidistante (Q)">""")
rep("""    cortar:  ['CORTAR',""", """    recortar:['RECORTAR', 'Clic en el trozo que sobra: se quita lo que hay entre los dos cruces más cercanos con otros contornos o auxiliares (o hasta el extremo) · Esc: terminar'],
    alargar: ['ALARGAR', 'Clic junto al extremo de un trazo abierto (recta o arco): se prolonga hasta el primer contorno o auxiliar que encuentra · Esc: terminar'],
    cortar:  ['CORTAR',""")
rep("""const ATAJOS = { u:'tangente', j:'cortar',""", """const ATAJOS = { y:'recortar', h:'alargar', u:'tangente', j:'cortar',""")
rep("""        case 'cortar': { const pc = puntoDeCorte(p); if (pc) cortarEn(pc.ci, pc.si, pc.p); else snack('Acerca el cursor a un contorno para cortarlo'); break; }""",
    """        case 'cortar': { const pc = puntoDeCorte(p); if (pc) cortarEn(pc.ci, pc.si, pc.p); else snack('Acerca el cursor a un contorno para cortarlo'); break; }
        case 'recortar': recortarEn(cursorRaw); break;
        case 'alargar': alargarEn(cursorRaw); break;""")
rep("""    if (herramienta === 'cortar') {
        const pc = puntoDeCorte(p);""", """    if (herramienta === 'recortar' || herramienta === 'alargar') dibujarPreviaRA(cursorRaw);
    if (herramienta === 'cortar') {
        const pc = puntoDeCorte(p);""")
rep("""    if (e.key === 'Escape' && trf && !enCampo(e)) { trf = null; render(); return; }""",
    """    if (e.key === 'Escape' && (herramienta === 'recortar' || herramienta === 'alargar')) { setHerramienta('editar'); return; }
    if (e.key === 'Escape' && trf && !enCampo(e)) { trf = null; render(); return; }""")

# ── ayuda (❓)
rep("""            <p><strong>Mover con las flechas</strong>""", """            <p><strong>Alinear y repartir</strong> (panel de la selección, con dos o más piezas): izquierda, centro, derecha, abajo, centro y arriba, respecto al conjunto; <em>Repartir ↔ / ↕</em> deja la misma separación entre las piezas (con tres o más; la primera y la última no se mueven). Cada grupo o texto cuenta como una pieza.</p>
            <p><strong>🔒 Bloquear</strong> (panel del contorno o de la selección): el contorno no se coge en el dibujo (ni con clic, ni con recuadro, ni con Ctrl+A), para que no se mueva por error mientras calcas o acotas encima; los imanes sí lo ven. Se ve con 🔒 en el dibujo y en la lista de contornos; desde la lista se selecciona y se desbloquea.</p>
            <p><strong>Recortar</strong> (<kbd>Y</kbd>): clic en el trozo de un contorno que sobra; se quita lo que hay entre los dos cruces más cercanos con otros contornos o líneas auxiliares (o hasta el extremo del trazo). Antes de hacer clic se ve en rosa lo que se quitará. <strong>Alargar</strong> (<kbd>H</kbd>): clic junto al extremo de un trazo abierto; la recta o el arco se prolonga hasta el primer contorno o auxiliar que encuentra (se ve antes, en verde). Con las dos, <kbd>Esc</kbd> vuelve a Editar.</p>
            <p><strong>Mover con las flechas</strong>""")
open(P, 'w', encoding='utf-8').write(s)
print('Calcador: alinear, repartir, bloquear, recortar y alargar:', P)
