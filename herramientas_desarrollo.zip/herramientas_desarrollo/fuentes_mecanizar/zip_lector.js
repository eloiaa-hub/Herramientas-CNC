// ── Lector de archivos .zip (las entregas que descarga Aules / Moodle), sin bibliotecas ──
// Descomprime con DecompressionStream('deflate-raw') si el navegador lo tiene; si no, con inflarRaw (abajo).
function inflarRaw(src, tam) {
    let pos = 0, buf = 0, nb = 0, out = new Uint8Array(tam > 0 ? tam : Math.max(1024, src.length * 4)), o = 0;
    const crecer = n => { if (o + n <= out.length) return; const x = new Uint8Array(Math.max(out.length * 2, o + n)); x.set(out); out = x; };
    const bits = n => { while (nb < n) { if (pos >= src.length) throw new Error('zip dañado (datos incompletos)'); buf |= src[pos++] << nb; nb += 8; } const v = buf & ((1 << n) - 1); buf >>>= n; nb -= n; return v; };
    const tabla = (lon, n) => { const cnt = new Uint16Array(16), sim = new Uint16Array(n), offs = new Uint16Array(16);
        for (let i = 0; i < n; i++) cnt[lon[i]]++; cnt[0] = 0;
        for (let i = 1; i < 16; i++) offs[i] = offs[i - 1] + cnt[i - 1];
        for (let i = 0; i < n; i++) if (lon[i]) sim[offs[lon[i]]++] = i;
        return { cnt, sim }; };
    const decod = h => { let code = 0, first = 0, idx = 0;
        for (let l = 1; l < 16; l++) { code |= bits(1); const c = h.cnt[l]; if (code - c < first) return h.sim[idx + code - first]; idx += c; first = (first + c) << 1; code <<= 1; }
        throw new Error('zip dañado (código Huffman)'); };
    const LB = [3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258], LE = [0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0];
    const DB = [1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577], DE = [0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13];
    let fijaL = null, fijaD = null, fin = 0;
    while (!fin) {
        fin = bits(1); const tipo = bits(2);
        if (tipo === 0) {
            pos -= nb >> 3; buf = 0; nb = 0; const len = src[pos] | (src[pos + 1] << 8); pos += 4;
            crecer(len); out.set(src.subarray(pos, pos + len), o); o += len; pos += len; continue;
        }
        let hl, hd;
        if (tipo === 1) {
            if (!fijaL) { const l = new Uint8Array(288); l.fill(8, 0, 144); l.fill(9, 144, 256); l.fill(7, 256, 280); l.fill(8, 280, 288); fijaL = tabla(l, 288); fijaD = tabla(new Uint8Array(30).fill(5), 30); }
            hl = fijaL; hd = fijaD;
        } else if (tipo === 2) {
            const nl = bits(5) + 257, nd = bits(5) + 1, nc = bits(4) + 4, ORD = [16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];
            const lc = new Uint8Array(19); for (let i = 0; i < nc; i++) lc[ORD[i]] = bits(3);
            const hc = tabla(lc, 19), lon = new Uint8Array(nl + nd);
            for (let i = 0; i < nl + nd;) {
                const s = decod(hc);
                if (s < 16) lon[i++] = s;
                else { let v = 0, r; if (s === 16) { if (!i) throw new Error('zip dañado'); v = lon[i - 1]; r = 3 + bits(2); } else if (s === 17) r = 3 + bits(3); else r = 11 + bits(7); while (r--) lon[i++] = v; }
            }
            hl = tabla(lon.subarray(0, nl), nl); hd = tabla(lon.subarray(nl), nd);
        } else throw new Error('zip dañado (bloque desconocido)');
        for (;;) {
            const s = decod(hl);
            if (s < 256) { crecer(1); out[o++] = s; }
            else if (s === 256) break;
            else { const k = s - 257, len = LB[k] + bits(LE[k]), dk = decod(hd), dist = DB[dk] + bits(DE[dk]);
                if (dist > o) throw new Error('zip dañado (distancia)');
                crecer(len); for (let i = 0; i < len; i++, o++) out[o] = out[o - dist]; }
        }
    }
    return o === out.length ? out : out.slice(0, o);
}
async function descomprimirZip(datos, tam) {
    if (typeof DecompressionStream === 'function') {
        try { const ab = await new Response(new Blob([datos]).stream().pipeThrough(new DecompressionStream('deflate-raw'))).arrayBuffer(); return new Uint8Array(ab); }
        catch (e) { /* algunos navegadores no aceptan 'deflate-raw': se descomprime a mano */ }
    }
    return inflarRaw(datos, tam);
}
// CP437 (nombres de archivo de los zip antiguos que no dicen que van en UTF-8)
const CP437_ALTO = 'ÇüéâäàåçêëèïîìÄÅÉæÆôöòûùÿÖÜ¢£¥₧ƒáíóúñÑªº¿⌐¬½¼¡«»░▒▓│┤╡╢╖╕╣║╗╝╜╛┐└┴┬├─┼╞╟╚╔╩╦╠═╬╧╨╤╥╙╘╒╓╫╪┘┌█▄▌▐▀αßΓπΣσµτΦΘΩδ∞φε∩≡±≥≤⌠⌡÷≈°∙·√ⁿ²■ ';
function nombreZip(b, utf8) {
    if (!utf8) { try { return new TextDecoder('utf-8', { fatal:true }).decode(b); } catch (e) { return [...b].map(c => c < 128 ? String.fromCharCode(c) : CP437_ALTO[c - 128]).join(''); } }
    return new TextDecoder('utf-8').decode(b);
}
// Devuelve [{ nombre, leer() → Promise<Uint8Array>, tam, cifrado }]
function listarZip(ab) {
    const u = new Uint8Array(ab), dv = new DataView(ab);
    let e = -1; for (let i = u.length - 22; i >= Math.max(0, u.length - 65557); i--) if (dv.getUint32(i, true) === 0x06054b50) { e = i; break; }
    if (e < 0) throw new Error('no es un archivo .zip válido');
    let n = dv.getUint16(e + 10, true), p = dv.getUint32(e + 16, true);
    if (p === 0xffffffff || n === 0xffff) {   // ZIP64 (zips de más de 4 GB o con muchísimos archivos)
        const l = e - 20; if (l < 0 || dv.getUint32(l, true) !== 0x07064b50) throw new Error('zip64 no reconocido');
        const r = Number(dv.getBigUint64(l + 8, true)); n = Number(dv.getBigUint64(r + 32, true)); p = Number(dv.getBigUint64(r + 48, true));
    }
    const out = [];
    for (let k = 0; k < n && p + 46 <= u.length; k++) {
        if (dv.getUint32(p, true) !== 0x02014b50) break;
        const flag = dv.getUint16(p + 8, true), met = dv.getUint16(p + 10, true), ln = dv.getUint16(p + 28, true), lx = dv.getUint16(p + 30, true), lc = dv.getUint16(p + 32, true);
        let cs = dv.getUint32(p + 20, true), us = dv.getUint32(p + 24, true), off = dv.getUint32(p + 42, true);
        const nombre = nombreZip(u.subarray(p + 46, p + 46 + ln), flag & 0x800);
        if (cs === 0xffffffff || us === 0xffffffff || off === 0xffffffff) {   // campo extra ZIP64
            for (let q = p + 46 + ln; q + 4 <= p + 46 + ln + lx;) { const id = dv.getUint16(q, true), sz = dv.getUint16(q + 2, true);
                if (id === 1) { let r = q + 4; if (us === 0xffffffff) { us = Number(dv.getBigUint64(r, true)); r += 8; } if (cs === 0xffffffff) { cs = Number(dv.getBigUint64(r, true)); r += 8; } if (off === 0xffffffff) off = Number(dv.getBigUint64(r, true)); }
                q += 4 + sz; }
        }
        p += 46 + ln + lx + lc;
        if (/\/$/.test(nombre)) continue;
        out.push({ nombre, tam:us, cifrado:!!(flag & 1), leer: async () => {
            if (flag & 1) throw new Error('está cifrado (con contraseña)');
            const ini = off + 30 + dv.getUint16(off + 26, true) + dv.getUint16(off + 28, true), datos = u.subarray(ini, ini + cs);
            if (met === 0) return datos;
            if (met === 8) return descomprimirZip(datos, us);
            throw new Error('método de compresión ' + met + ' no admitido');
        } });
    }
    return out;
}
// Texto de un programa: UTF-8 si lo es; si no, Windows-1252 (los .nc escritos con el Bloc de notas antiguo)
function textoDeBytes(b) { try { return new TextDecoder('utf-8', { fatal:true }).decode(b).replace(/^﻿/, ''); } catch (e) { return new TextDecoder('windows-1252').decode(b); } }
// Texto en línea de Moodle (onlinetext.html): el alumno ha pegado el programa en el cuadro de texto
function textoDeHTML(h) {
    const d = new DOMParser().parseFromString(String(h).replace(/<br\s*\/?>/gi, '\n').replace(/<\/(p|div|li|h\d)>/gi, '\n'), 'text/html');
    return (d.body ? d.body.textContent : '').replace(/ /g, ' ').replace(/\n{3,}/g, '\n\n').trim();
}
// Nombre del alumno a partir de la ruta dentro del zip de Aules / Moodle:
//   «Pérez López, Ana_123456_assignsubmission_file_/pieza.nc»   (descarga en carpetas)
//   «Pérez López, Ana_123456_assignsubmission_file_pieza.nc»    (descarga sin carpetas)
//   «Participante_123456_assignsubmission_file_…»               (calificación anónima)
function alumnoDeRuta(ruta) {
    const partes = ruta.split('/').filter(Boolean);
    for (const t of partes) {
        const m = /^(.*?)_(\d+)_assign(?:submission|feedback)_/i.exec(t);
        if (m) { const n = m[1].trim(); return /^(participant|participante|participant\s*e)$/i.test(n) ? 'Participante ' + m[2] : n; }
    }
    return null;
}
