// Hoja de contactos de candidatos para la biblioteca de inicio: por nivel y etapa, N semillas con su miniatura
// Uso: LANG=C.UTF-8 node candidatos.js [nivel]   → candidatos_<nivel>.png
const path = require('path'), fs = require('fs');
const { lanzar, SUITE } = require('../pruebas/comun.js');
const PLAN = require('./plan.js');
(async () => {
  const b = await lanzar(); const p = await b.newPage({ viewport:{ width:1600, height:1000 } });
  await p.goto('file://' + path.join(SUITE, 'calcador.html')); await p.evaluate(() => localStorage.clear()); await p.reload(); await p.waitForTimeout(800);
  for (const nv of PLAN.niveles.filter(n => !process.argv[2] || n.clave === process.argv[2])) {
    const html = await p.evaluate(([nv, base]) => {
      let out = '';
      nv.etapas.forEach((et0, ie) => { const et = { cfg:et0 };
        const cfg = Object.assign(JSON.parse(JSON.stringify(GEN_CFG0)), JSON.parse(JSON.stringify(GEN_NIVELES[nv.clave].p)), { nivel:nv.clave }, et.cfg);
        out += `<h3>${nv.clave} · etapa ${ie + 1} ${JSON.stringify(et.cfg)}</h3><div class=g>`;
        for (let k = 0; k < 40; k++) {
          const s = nv.base + ie * 100 + k, r = generarEjercicio(s, cfg); if (!r.contornos.length) continue;
          const datos = { calcador:{ contornos:r.contornos } };
          out += `<div class=c><div class=m>${svgMini(datos)}</div><b>${s}</b> ${r.interiores}i ${Math.round(r.w)}×${Math.round(r.h)}</div>`;
        }
        out += '</div>';
      });
      return out;
    }, [nv]);
    const q = await b.newPage({ viewport:{ width:1600, height:1000 } });
    await q.setContent(`<style>body{font:12px sans-serif} .g{display:grid;grid-template-columns:repeat(10,1fr);gap:4px} .c{border:1px solid #ccc;padding:2px} .m svg{width:100%;height:110px}</style>${html}`);
    await q.screenshot({ path: path.join(__dirname, `candidatos_${nv.clave}.png`), fullPage:true }); await q.close();
    console.log('candidatos', nv.clave);
  }
  await b.close();
})();
