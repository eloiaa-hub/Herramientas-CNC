// Página de la biblioteca de inicio (biblioteca_inicio/index.html): funciona en el disco, en GitHub Pages y en Aules,
// donde un enlace a una carpeta no muestra su contenido.
const esc = t => String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const url = r => r.split('/').map(encodeURIComponent).join('/');
const PROG = { g90:'G90', g91:'G91', mix:'Mixta', libre:'Libre' };
const PROG_T = { g90:'En absolutas (G90)', g91:'En incrementales (G91)', mix:'Mixta: G90 para entrar y salir, G91 en el recorrido', libre:'Programación libre' };
const QUE = {
  rectas:'Rectas horizontales y verticales: un rectángulo, piezas escalonadas y, al final, agujeros rectangulares.',
  inclinadas:'Chaflanes, que se calculan por proyecciones.',
  tangentes:'Ranuras, esquinas redondeadas y hacia dentro y agujeros redondos, con el centro de los arcos en la rejilla (I J enteros).',
  ij:'Lados en arco, polígonos y varios agujeros: hay que calcular I J.' };
module.exports = (PLAN, items) => {
  const niveles = PLAN.niveles.map(nv => {
    const its = items.filter(x => x.nv.clave === nv.clave);
    const fichas = its.map(({ k, e, archivo }) => `
        <a class="ej" href="${url(nv.nombre + '/' + archivo)}" download title="Descargar el JSON del ejercicio ${e.num} (se abre en el Calcador)">
          <div class="mini">${e.svg}</div>
          <div class="pie"><b>${k + 1}</b><span class="prog p-${nv.prog[k]}" title="${esc(PROG_T[nv.prog[k]])}">${PROG[nv.prog[k]]}</span></div>
          <small>${Math.round(e.w)} × ${Math.round(e.h)} mm${e.interiores ? ` · ${e.interiores} agujero${e.interiores > 1 ? 's' : ''}` : ''}</small>
        </a>`).join('');
    return `
    <section class="nivel">
      <div class="cab-nivel">
        <div><h2><span class="n">${nv.n}</span>${esc(nv.titulo)}</h2><p>${QUE[nv.clave]}</p></div>
        <div class="acciones">
          <a class="boton" href="${url(nv.nombre + ' - hojas.pdf')}" target="_blank" rel="noopener">📄 Hojas (PDF)</a>
          <a class="boton sec" href="${url(nv.nombre + ' - soluciones.pdf')}" target="_blank" rel="noopener">✅ Soluciones (PDF)</a>
        </div>
      </div>
      <div class="ejs">${fichas}</div>
    </section>`;
  }).join('');
  return `<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Biblioteca de inicio — Suite CNC</title>
<style>
  :root { --acento:#005A9C; --acento-suave:rgba(0,90,156,.10); --fondo:#eef2f6; --panel:#fff; --texto:#1d2733; --texto-sec:#5b6878; --borde:#d7dee7; --sombra:0 6px 22px rgba(20,40,70,.10); --verde:#00897b; --naranja:#c8741a; --morado:#7b4bb7; }
  @media (prefers-color-scheme: dark) { :root { --acento:#5aa9e6; --acento-suave:rgba(90,169,230,.14); --fondo:#14181d; --panel:#1d232a; --texto:#e6ebf0; --texto-sec:#9aa7b5; --borde:#2e3843; --sombra:0 6px 22px rgba(0,0,0,.35); --verde:#4dd0c4; --naranja:#e8a25a; --morado:#b48ce6; } .mini { background:#f4f7fa; } }
  * { box-sizing:border-box; }
  body { margin:0; font-family:'Segoe UI', system-ui, -apple-system, Roboto, Arial, sans-serif; background:var(--fondo); color:var(--texto); line-height:1.5; }
  .envoltura { max-width:1120px; margin:0 auto; padding:28px 16px 40px; }
  header { display:flex; align-items:center; gap:14px; flex-wrap:wrap; }
  .casa { font-size:22px; text-decoration:none; color:var(--texto-sec); }
  h1 { margin:0; font-size:clamp(22px, 3.2vw, 30px); }
  .sub { margin:2px 0 0; color:var(--texto-sec); font-size:15px; }
  .uso { background:var(--panel); border:1px solid var(--borde); border-radius:14px; padding:16px 18px; margin:22px 0 8px; box-shadow:var(--sombra); font-size:14.5px; }
  .uso ol { margin:6px 0 0; padding-left:22px; } .uso li { margin:3px 0; }
  .acciones { display:flex; gap:8px; flex-wrap:wrap; }
  .boton { display:inline-flex; align-items:center; gap:6px; padding:8px 14px; border-radius:8px; background:var(--acento); color:#fff; text-decoration:none; font-weight:600; font-size:14px; }
  .boton.sec { background:transparent; color:var(--acento); border:1px solid var(--acento); }
  .boton:hover { filter:brightness(1.08); }
  .nivel { background:var(--panel); border:1px solid var(--borde); border-radius:14px; padding:18px; margin-top:18px; box-shadow:var(--sombra); }
  .cab-nivel { display:flex; justify-content:space-between; align-items:flex-start; gap:12px; flex-wrap:wrap; margin-bottom:12px; }
  .cab-nivel p { margin:2px 0 0; color:var(--texto-sec); font-size:14px; max-width:620px; }
  h2 { margin:0; font-size:19px; display:flex; align-items:center; gap:10px; }
  h2 .n { display:inline-flex; width:30px; height:30px; border-radius:9px; background:var(--acento-suave); color:var(--acento); align-items:center; justify-content:center; font-size:16px; }
  .ejs { display:grid; grid-template-columns:repeat(auto-fill, minmax(150px, 1fr)); gap:10px; }
  .ej { display:flex; flex-direction:column; gap:3px; padding:8px; border:1px solid var(--borde); border-radius:10px; text-decoration:none; color:var(--texto); transition:border-color .12s, transform .12s; }
  .ej:hover { border-color:var(--acento); transform:translateY(-2px); }
  .mini { height:110px; border-radius:6px; background:#f7f9fb; padding:6px; } .mini svg { width:100%; height:100%; display:block; }
  .pie { display:flex; justify-content:space-between; align-items:center; font-size:14px; }
  .prog { font-size:11px; font-weight:700; padding:1px 8px; border-radius:9px; background:var(--acento-suave); color:var(--acento); }
  .p-g91 { color:var(--verde); background:rgba(0,137,123,.12); } .p-mix { color:var(--naranja); background:rgba(200,116,26,.12); } .p-libre { color:var(--morado); background:rgba(123,75,183,.12); }
  small { color:var(--texto-sec); font-size:12px; }
  footer { margin-top:28px; text-align:center; font-size:12.5px; color:var(--texto-sec); }
</style>
</head>
<body>
<div class="envoltura">
  <header>
    <a class="casa" href="../index.html" title="Portada de las herramientas">⌂</a>
    <div><h1>📚 Biblioteca de inicio</h1><p class="sub">40 ejercicios para el Calcador, en 4 niveles y de menos a más dentro de cada nivel · Suite CNC</p></div>
  </header>
  <div class="uso">
    <b>Cómo se usa</b>
    <ol>
      <li><b>Todos de una vez:</b> descarga <a href="Biblioteca_de_inicio.json" download>Biblioteca_de_inicio.json</a> y, en el Calcador, abre 📚 Biblioteca → «Importar archivos…». Quedan en la carpeta <i>Biblioteca de inicio</i>, con las etiquetas <i>Inicio</i> y <i>Nivel 1</i> … <i>Nivel 4</i>.</li>
      <li><b>Uno a uno:</b> pulsa un ejercicio para descargar su JSON y ábrelo en el Calcador como cualquier proyecto. (Si ya has importado el archivo de todos, no hace falta: saldrían dos veces.)</li>
      <li><b>Para imprimir:</b> cada nivel tiene sus hojas de ejercicio y sus soluciones en PDF.</li>
    </ol>
    <div class="acciones" style="margin-top:10px"><a class="boton" href="Biblioteca_de_inicio.json" download>⬇ Biblioteca_de_inicio.json (los 40)</a><a class="boton sec" href="../calcador.html">Abrir el Calcador</a></div>
  </div>
  ${niveles}
  <footer>La etiqueta de cada ejercicio es la programación que pide: <b>G90</b>, <b>G91</b>, <b>Mixta</b> o <b>Libre</b>. © 2026 Eloi A.A. · Ejercicios con licencia CC BY-SA 4.0.</footer>
</div>
</body>
</html>
`;
};
